"""A realtime session that wraps a [`RealtimeConnection`][pydantic_ai.realtime.codec.RealtimeConnection] with automatic tool execution."""

from __future__ import annotations as _annotations

import asyncio
import dataclasses
import weakref
from collections import OrderedDict, deque
from collections.abc import AsyncGenerator, AsyncIterable, AsyncIterator, Callable, Sequence
from copy import copy
from dataclasses import dataclass, field, replace
from functools import partial
from itertools import takewhile
from time import time_ns
from types import TracebackType
from typing import TYPE_CHECKING, Any, Literal, Never, TypeAlias, TypeVar, assert_never, cast, overload

import anyio
from anyio import Lock
from opentelemetry import context as otel_context
from opentelemetry.context import Context
from typing_extensions import TypeAliasType

from .. import _agent_graph
from .._enqueue import EnqueueContent, PendingMessage, PendingMessagePriority, PendingMessageQueue
from .._genai_prices import fill_response_cost
from .._run_context import context_window_fraction
from .._tool_execution import (
    _reject_unloaded_capability_reveals,  # pyright: ignore[reportPrivateUsage]
    build_tool_return_part,
    cancelled_sub_agent_return,
)
from .._utils import aclose_all, cancel_and_drain, dataclasses_no_defaults_repr, fill_run_metadata
from ..conversation import Conversation
from ..exceptions import (
    ApprovalRequired,
    CallDeferred,
    RunCancelled,
    ToolFailedError,
    ToolRetryError,
    UsageLimitExceeded,
    UserError,
)
from ..messages import (
    INTERRUPTED_TOOL_RETURN_CONTENT,
    BinaryAudio,
    BinaryContent,
    BinaryImage,
    DeferredToolRequestsEvent,
    DeferredToolResultsEvent,
    EnqueuedMessagesEvent,
    FinishReason,
    FunctionToolCallEvent,
    FunctionToolResultEvent,
    ModelMessage,
    ModelRequest,
    ModelRequestPart,
    ModelResponse,
    ModelResponsePart,
    PartDeltaEvent,
    PartEndEvent,
    PartStartEvent,
    RealtimeInputSpeechEndEvent,
    RealtimeInputSpeechStartEvent,
    RealtimeInputTranscriptionErrorEvent,
    RealtimeOutputSpeechEndEvent,
    RealtimeOutputSpeechStartEvent,
    RealtimeResponseInterruptedEvent,
    RealtimeSessionErrorEvent,
    RealtimeSessionReconnectEvent,
    RealtimeTurnCompleteEvent,
    RetryPromptPart,
    SpeechPart,
    SpeechPartDelta,
    SystemPromptPart,
    TextPart,
    TextPartDelta,
    ToolCallPart,
    ToolReturnPart,
    UserContent,
    UserPromptPart,
)
from ..native_tools import SUPPORTED_NATIVE_TOOLS
from ..run import AgentRunResult
from ..tool_manager import ToolManager
from ..usage import RequestUsage, RunUsage, UsageLimits
from ._core import (
    AudioCleared,
    AudioSent,
    Closed,
    CoreInput,
    ExchangeAbandoned,
    InputSent,
    InputWithdrawn,
    Interrupted,
    Owed,
    ReceiveEnded,
    SessionCore,
    ToolCallRefused,
    ToolReturned,
    TranscriptOverdue,
)
from ._instrumentation import (
    SessionInstrumentation,
)
from ._lifecycle import LIFECYCLE_EVENT_TYPES
from ._retained_audio import RetainedAudioBudget
from ._utils import (
    accumulate_transcript,
    fold_part_transcript,
    pcm_to_wav,
    seed_pcm_audio,
    user_transcript_update,
)
from .codec import (
    AudioDelta,
    CancelResponse,
    ClearAudio,
    CommitAudio,
    ConversationCreated,
    ConversationItemCreated,
    CreateResponse,
    InputRejected,
    InputTranscript,
    OutputTranscript,
    RealtimeCodecEvent,
    RealtimeConnection,
    RealtimeInput,
    RealtimeSessionInput,
    ResponseDone,
    SessionUsage,
    TextContext,
    ToolCall,
    ToolCallCancelled,
    ToolResult,
    TruncateOutput,
)
from .model import RealtimeError
from .profiles import DEFAULT_AUDIO_SAMPLE_RATE, RealtimeModelProfile
from .settings import AudioRetention, RealtimeModelSettings

if TYPE_CHECKING:
    from ..messages import AgentStreamEvent
    from ..models import ModelRequestParameters
    from ..models.instrumented import InstrumentationSettings
    from ..tools import DeferredToolRequests, DeferredToolResults
    from .model import RealtimeModel, RealtimeProviderSession

# Session-level events (yielded by `RealtimeSession.__aiter__`).
#
# A session translates the low-level codec events into the shared message/part event vocabulary from
# `pydantic_ai.messages`: `AudioDelta`/`OutputTranscript`/`InputTranscript` become `PartStartEvent` /
# `PartDeltaEvent` / `PartEndEvent` for `SpeechPart`s, and `ToolCall` becomes a
# `ToolCallPart` part (start/end) plus `FunctionToolCallEvent` / `FunctionToolResultEvent` around its
# execution. Some control-plane events pass through unchanged.


RealtimeEvent = TypeAliasType(
    'RealtimeEvent',
    PartStartEvent
    | PartDeltaEvent
    | PartEndEvent
    | FunctionToolCallEvent
    | FunctionToolResultEvent
    | DeferredToolRequestsEvent
    | DeferredToolResultsEvent
    | EnqueuedMessagesEvent
    | RealtimeTurnCompleteEvent
    | RealtimeInputSpeechStartEvent
    | RealtimeResponseInterruptedEvent
    | RealtimeInputSpeechEndEvent
    | RealtimeOutputSpeechStartEvent
    | RealtimeOutputSpeechEndEvent
    | RealtimeInputTranscriptionErrorEvent
    | RealtimeSessionReconnectEvent
    | RealtimeSessionErrorEvent,
)
"""Union of events yielded by [`RealtimeSession`][pydantic_ai.realtime.RealtimeSession].

This is a strict subset of [`AgentStreamEvent`][pydantic_ai.messages.AgentStreamEvent].

Content is streamed as the shared [`PartStartEvent`][pydantic_ai.messages.PartStartEvent] /
[`PartDeltaEvent`][pydantic_ai.messages.PartDeltaEvent] / [`PartEndEvent`][pydantic_ai.messages.PartEndEvent]
events (carrying [`SpeechPart`][pydantic_ai.messages.SpeechPart]s and
other shared message parts, including [`TextPart`][pydantic_ai.messages.TextPart],
[`ToolCallPart`][pydantic_ai.messages.ToolCallPart], and
[`NativeToolReturnPart`][pydantic_ai.messages.NativeToolReturnPart]), tool execution as
[`FunctionToolCallEvent`][pydantic_ai.messages.FunctionToolCallEvent] /
[`FunctionToolResultEvent`][pydantic_ai.messages.FunctionToolResultEvent], deferred calls and their resolution
as [`DeferredToolRequestsEvent`][pydantic_ai.messages.DeferredToolRequestsEvent] /
[`DeferredToolResultsEvent`][pydantic_ai.messages.DeferredToolResultsEvent], enqueued-message delivery
as [`EnqueuedMessagesEvent`][pydantic_ai.messages.EnqueuedMessagesEvent], and the rest as realtime
control-plane events.
"""


@dataclass(frozen=True, repr=False, kw_only=True)
class TranscriptUpdate:
    """One incremental transcript update, carrying everything needed to render it.

    Yielded by [`RealtimeSession.stream_transcripts(delta=True)`][pydantic_ai.realtime.RealtimeSession.stream_transcripts].
    A realtime session is duplex, so both speakers' transcripts stream at the same time and a caption
    UI needs to know not just *what* was said but *which* turn to put it in — otherwise two
    consecutive turns by the same speaker run together.
    """

    index: int
    """Identifies the turn this update belongs to, stable for the life of the session.

    Use it as the key for whatever you render a turn into: every update with the same `index` belongs
    to the same speech part.
    """

    speaker: Literal['user', 'assistant']
    """Who is speaking."""

    delta: str
    """The text this update added, when it added any.

    Empty when the provider *revised* the turn instead of extending it — speech recognition is
    revisable, and a correction can't be expressed as an addition. Render `transcript` and this never
    matters.
    """

    transcript: str
    """The full transcript of this turn so far.

    Render this, keyed on `index`, and captions are correct whatever the provider does: no
    accumulating, no special case for a revision, and a dropped update (if a consumer fell behind)
    self-corrects on the next one.
    """

    __repr__ = dataclasses_no_defaults_repr


class _InFlightResponse:
    """Where a user turn belongs when it began while the model was still answering: after that answer.

    The answer isn't in history yet, so there is no message to anchor to. The placeholder is swapped for
    the response once it is recorded (see `_resolve_in_flight_user_turn_anchors`).
    """


_IN_FLIGHT_RESPONSE = _InFlightResponse()


@dataclass(eq=False)
class _HeldCommit:
    """Where a user turn belongs on a connection that holds its commit back: wherever the commit goes out.

    Input sent while the commit is held reaches the provider first, so the turn's place is only known
    once the connection sends it (see `RealtimeConnection._defers_audio_commit`). Turns recorded before
    then wait here.
    """

    anchor: ModelMessage | _InFlightResponse | None = None
    sent: bool = False
    has_audio: bool = False
    requests: list[ModelRequest] = field(default_factory=list[ModelRequest])


_UserTurnAnchor = ModelMessage | _InFlightResponse | _HeldCommit | None


class _InputSegments:
    """Retained input audio cut at each item's speech-stopped boundary, held until that item's turn is recorded.

    Keeps the total size as segments come and go, and drops an evicted segment rather than emptying it, so
    checking and enforcing `retain_audio_max_seconds` costs the same however many turns are waiting.
    """

    def __init__(self) -> None:
        self._segments: OrderedDict[str, bytes] = OrderedDict()
        # Items whose segment was evicted: their turn records no audio, rather than the rolling buffer's.
        self._evicted: set[str] = set()
        self.byte_count = 0

    def cut(self, item_id: str, segment: bytes) -> None:
        """Keep `segment` for `item_id`, unless it already has one (or had one evicted): the first cut wins."""
        if item_id not in self._segments and item_id not in self._evicted:
            self._segments[item_id] = segment
            self.byte_count += len(segment)

    def take(self, item_id: str) -> bytes | None:
        """Remove and return `item_id`'s segment: `b''` if it was evicted, `None` if it was never cut."""
        if item_id in self._evicted:
            self._evicted.discard(item_id)
            return b''
        segment = self._segments.pop(item_id, None)
        if segment is not None:
            self.byte_count -= len(segment)
        return segment

    def evict_oldest(self) -> int | None:
        """Evict the oldest segment, returning its size, or `None` when there is none."""
        if not self._segments:
            return None
        item_id, segment = self._segments.popitem(last=False)
        self._evicted.add(item_id)
        self.byte_count -= len(segment)
        return len(segment)

    def clear(self) -> None:
        self._segments.clear()
        self._evicted.clear()
        self.byte_count = 0


@dataclass
class _UserTurn:
    part: SpeechPart
    transcript: str
    index: int
    finalized: bool = False
    speech_ended: bool = False
    start_emitted: bool = True


# Realtime providers stream raw PCM audio, but retained history uses a WAV container so the sample
# format is self-describing and portable to classic model adapters. Live `SpeechPartDelta.audio_chunk`
# values remain raw PCM.
_WAV_MEDIA_TYPE = 'audio/wav'
# Marks every span this session emits so the Logfire UI (and any consumer) can recognize realtime
# activity without parsing span names.

# Fallback for a session created without a model's profile (e.g. directly, in tests): assume
# everything is supported so no guard fires. Real sessions receive `model.profile`. Native tools are
# validated up front by `Agent.realtime`, not the session, so this field is inert here.
_FULL_PROFILE = RealtimeModelProfile(
    supports_image_input=True,
    supports_text_output=True,
    supports_manual_turn_control=True,
    supports_interruption=True,
    supports_output_truncation=True,
    supports_session_seeding=True,
    supported_native_tools=SUPPORTED_NATIVE_TOOLS,
    audio_input_sample_rate=DEFAULT_AUDIO_SAMPLE_RATE,
    audio_output_sample_rate=DEFAULT_AUDIO_SAMPLE_RATE,
)

# Providers generate speech several times faster than it plays (OpenAI 6-9x, Gemini 3-4x), so a
# device-paced player routinely has most of a reply queued before it has heard the first seconds of it.
# The audio window is therefore measured in playback time rather than chunks (whose size varies from
# ~40 ms on Gemini to 400 ms on OpenAI) and sized to hold any realistic reply generated ahead of
# playback; drop-oldest is only a memory cap for a view that stopped being consumed. Five minutes of
# 24 kHz PCM16 is about 14 MB. Transcript items are short strings, and dropping one silently corrupts
# the text a user is reading, so they get a deep window for a trivial cost.
_AUDIO_TAP_SECONDS = 300
_MAX_TRUNCATABLE_AUDIO_ITEMS = 32
"""How many recent assistant audio parts a barge-in can still truncate: far more than can be queued for playback."""
# How long a user turn that barged in waits for the response it interrupted to be recorded, so it can
# follow that response in history. The provider's terminal for a cut-off response normally arrives within
# a second of the user starting to speak; past this, the turn is recorded where history stands instead of
# staying out of `all_messages()` for as long as a provider keeps talking.
_BARGE_IN_TURN_HOLD_SECONDS = 5.0
# How long a spoken turn that joined the conversation may hold back history recorded after it while it waits for
# its transcript, with the session core: the turn is never inserted ahead of what was recorded since. Counted from
# when something after it is ready (normally the reply). Transcripts can arrive after the reply and the next turn
# (recorded: push-to-talk on gpt-realtime and gpt-realtime-2.1), so this is generous; past it, the turn is recorded
# with what it has, so a transcript that never comes can't hide the rest of the conversation for good.
_TRANSCRIPT_HOLD_SECONDS = 30.0
#: How long closing waits for the provider to end its session and report the usage it only reports then.
#: Not waited for at all when the session is closing because it was cancelled.
_END_SESSION_TIMEOUT = 2.0
# The byte budget alone would let a stream of tiny deltas queue millions of objects, so the window is
# also capped in chunks: five minutes at 10 ms apiece, well below any provider's real chunk size.
_AUDIO_TAP_MAX_CHUNKS = 30_000
_TRANSCRIPT_TAP_SIZE = 512
_SESSION_DELTA_QUEUE_SIZE = 512
# Structural events are some five per turn against one delta per audio frame, so they are not what
# makes an unread queue large — but they are never superseded the way deltas are, so without their own
# bound a session nothing iterates keeps every one of them for as long as it runs. The same 512 buys a
# late iterator around a hundred turns of structure, comfortably more history than the deltas it keeps.
_SESSION_STRUCTURAL_QUEUE_SIZE = 512
_CoreMode: TypeAlias = Literal['legacy', 'core']
_CORE_MODE: _CoreMode = 'core'
"""Which session core keeps the history, usage, and reply waits of a connection on version 2 of the lifecycle
contract (see `_core.py`).

`'core'` makes the new core authoritative for them; this session still turns the connection's events into the
ones it streams, runs the tools, and owns the spans. `'legacy'` keeps all of it here, as connections on version 1
always do. Private: a way back while the new core settles in.
"""
_TapItem = TypeVar('_TapItem')
_Tap = TypeVar('_Tap')


def _put_tap(queue: asyncio.Queue[_TapItem], item: _TapItem) -> _TapItem | None:
    """Put without blocking the pump, retaining the newest bounded window.

    The queue is sized one over its data window so the completion sentinel always fits. Returns the
    older item that was dropped to make room, or `None` when nothing was dropped.
    """
    dropped: _TapItem | None = None
    if queue.qsize() >= queue.maxsize - 1:
        dropped = queue.get_nowait()
    queue.put_nowait(item)
    return dropped


class _TapView(AsyncIterator[_TapItem]):
    """A `stream_audio()` / `stream_transcripts()` view whose subscription is registered before iteration.

    The generator discards its tap in `finally`, but an async generator that was never started has no
    frame to unwind, so `aclose()` would leave the tap registered for as long as the caller held the
    view. Wrapping it gives `aclose()` a hook, and a view that is simply abandoned is released when
    collected.
    """

    def __init__(
        self,
        iterator: AsyncGenerator[_TapItem, None],
        taps: set[_Tap],
        tap: _Tap,
        on_close: Callable[[], None] | None = None,
    ) -> None:
        self._iterator = iterator
        self._discard = weakref.finalize(self, taps.discard, tap)
        self._finish = weakref.finalize(self, on_close) if on_close is not None else None

    def __aiter__(self) -> AsyncIterator[_TapItem]:
        return self

    async def __anext__(self) -> _TapItem:
        return await self._iterator.__anext__()

    async def aclose(self) -> None:
        self._discard()
        if self._finish is not None:
            self._finish()
        await self._iterator.aclose()


@dataclass(eq=False)
class _AudioTap:
    """One `stream_audio()` subscription, with the accounting `interrupt(played_bytes=...)` needs.

    `subscribed_at_bytes` anchors the tap in the session's emitted-audio coordinates, and
    `dropped_bytes` counts audio removed before the consumer saw it (overflow and barge-in flushes),
    so a device-side playback position can be mapped back into those coordinates.
    """

    queue: asyncio.Queue[bytes | object]
    subscribed_at_bytes: int
    max_buffered_bytes: int
    """How much audio the queue may hold before the oldest chunks are dropped to make room."""
    buffered_bytes: int = 0
    """Audio currently queued for the consumer."""
    dropped_bytes: int = 0
    """Gaps the consumer has already moved past, which its playback position no longer accounts for."""
    pending_dropped_bytes: int = 0
    """Gaps that are still ahead of the consumer: dropped from the queue, but not yet stepped over.

    Drop-oldest discards the chunk that would have been delivered next, so a gap sits ahead of the
    playback position until the consumer takes the chunk beyond it — counting it before then would
    place the position further into the response than the device has actually reached.
    """
    played_bytes: int = 0
    """Chunks the consumer finished with — counted when it resumes the iterator for the next one."""
    progress: asyncio.Event = field(default_factory=asyncio.Event)
    """Set when playback advances or the view ends, waking `wait_for_playback()`."""
    ended: bool = False

    def put(self, chunk: bytes) -> int:
        """Queue a chunk without blocking the pump, dropping the oldest to stay within the byte and chunk budgets.

        The newest chunk is always kept, even on its own over budget. Returns how many chunks were
        dropped; their bytes become a gap ahead of the consumer.
        """
        dropped = 0
        while self.buffered_bytes and (
            self.buffered_bytes + len(chunk) > self.max_buffered_bytes or self.queue.qsize() >= _AUDIO_TAP_MAX_CHUNKS
        ):
            # The sentinel can't be dropped: it is only enqueued once the pump has finished, after
            # which nothing publishes.
            oldest = self.queue.get_nowait()
            assert isinstance(oldest, bytes)
            self.buffered_bytes -= len(oldest)
            self.pending_dropped_bytes += len(oldest)
            dropped += 1
        self.queue.put_nowait(chunk)
        self.buffered_bytes += len(chunk)
        return dropped

    def finish(self) -> None:
        self.ended = True
        self.progress.set()


@dataclass(eq=False)
class _ToolBatch:
    """The tool calls one model response made, which the model answers with a single reply.

    Gemini answers a tool-call frame once it has every result, and the OpenAI-protocol connection asks
    for one response once every call of the calling response has its output, so the session counts one
    reply per tool-calling response, not one per result. The reply is counted when the last result is
    about to go out (a provider may start answering the moment it arrives), or, when every result went
    out before the calling response was complete, once it is.
    """

    calls: set[str] = field(default_factory=set[str])
    """Every call in the batch."""
    running: set[str] = field(default_factory=set[str])
    """Calls still executing."""
    sending: int = 0
    """Results on their way to the wire."""
    closed: bool = False
    """Whether the response making the calls has been finalized, so no further call can join."""
    counted: bool = False
    """Whether the reply that answers the batch has been counted."""
    abandoned: bool = False
    """Whether no reply will come: the provider cancelled one of the calls (a barge-in abandons the
    turn) or lost the conversation they were made in, a tool raised, or a result failed to send."""

    @property
    def reply_due(self) -> bool:
        """Every result is out or on its way and no call can still join, so the reply is still to count."""
        return self.closed and not self.running and not self.counted and not self.abandoned

    @property
    def settled(self) -> bool:
        """No call can still join, run, or put a result on the wire."""
        return self.closed and not self.running and not self.sending


# The `RealtimeEvent` variants that `_translate_event` handles: the full union minus `ToolCall` and
# `SessionUsage`, which `_handle_pump_event` peels off first (they drive tool execution and usage
# accounting before delegating). Splitting the union lets `_translate_event` end in `assert_never`, so
# a new non-pump variant added to `RealtimeEvent` is caught at type-check time — either the call site
# (where the residual no longer fits this alias) or the `assert_never` flags it.
_TranslatableEvent: TypeAlias = (
    AudioDelta
    | OutputTranscript
    | InputTranscript
    | ResponseDone
    | RealtimeInputSpeechStartEvent
    | RealtimeResponseInterruptedEvent
    | RealtimeInputSpeechEndEvent
    | RealtimeOutputSpeechStartEvent
    | RealtimeOutputSpeechEndEvent
    | RealtimeInputTranscriptionErrorEvent
    | RealtimeSessionReconnectEvent
    | PartStartEvent
    | PartEndEvent
    | RealtimeSessionErrorEvent
)
_SettledToolResult: TypeAlias = tuple[ToolReturnPart | RetryPromptPart, str | Sequence[UserContent] | None]


def _tool_result_call_id(message: ModelMessage) -> str | None:
    """The id of the call a history request holds the result for, or `None` if it holds no result.

    An inserted tool result leads its request and may be followed by user content.
    """
    if not isinstance(message, ModelRequest) or not message.parts:
        return None
    result = message.parts[0]
    if not isinstance(result, (ToolReturnPart, RetryPromptPart)) or not all(
        isinstance(part, (ToolReturnPart, RetryPromptPart, UserPromptPart)) for part in message.parts
    ):
        return None
    return result.tool_call_id


def _is_tool_result_request(message: ModelMessage) -> bool:
    """Whether a history request carries an inserted tool result and optional follow-up user content."""
    return _tool_result_call_id(message) is not None


def _build_session_tool_return(
    tool_result: Any, call_part: ToolCallPart, tool_manager: ToolManager[Any]
) -> tuple[ToolReturnPart | RetryPromptPart, str | Sequence[UserContent] | None]:
    """Translate a settled session tool result into its history part, rejecting mid-session reveals."""
    tool_def = tool_manager.get_tool_def(call_part.tool_name)
    result_part, user_content, tools_added = build_tool_return_part(
        tool_result,
        call=call_part,
        tool_kind=tool_def.tool_kind if tool_def else None,
    )
    if tools_added:
        # Mirrors the graph (`_tool_execution._call_tool`), which rejects only a name owned by an
        # unloaded capability and treats every other name — a typo, an already-visible tool — as a
        # silent no-op. Killing the session over any reveal at all was harsher than the graph *and*
        # unreachable-by-design harshness: a session refuses `defer_loading=True` tools and
        # tool-contributing deferred capabilities when it opens, so it holds nothing that a reveal
        # could have surfaced. Nothing is silently lost by dropping the request here.
        _reject_unloaded_capability_reveals(tools_added, tool_manager)
    return result_part, user_content


def _chain_context(error: BaseException, context: BaseException) -> None:
    """Attach `context` at the end of `error`'s context chain, where a traceback shows it first.

    `error.__context__` is usually taken already (a mapped provider error carries the SDK's), so it can't
    just be set.
    """
    seen: set[int] = set()
    tail = error
    while tail.__context__ is not None:
        if tail is context or id(tail) in seen:
            return
        seen.add(id(tail))
        tail = tail.__context__
    if tail is not context:
        tail.__context__ = context


def _unsettled_call_return(call: ToolCallPart, error: BaseException) -> ToolReturnPart:
    """The return a session records when a tool call couldn't settle normally.

    These are cases the graph resolves by ending or isolating the run, which a live conversation
    can't do — so each gets a deliberate local settlement rather than leaving a dangling call.
    """
    if isinstance(error, RunCancelled):
        # Exactly the graph path's settlement (this session's own cancellation arrives as
        # `CancelledError`, which `_run_tool` re-raises untouched) — shared so the two can't drift.
        return cancelled_sub_agent_return(call, error)
    elif isinstance(error, (ApprovalRequired, CallDeferred)):
        # `handle_call` already gave the `HandleDeferredToolCalls` capability handler the chance to
        # resolve the deferral inline (approve, deny, retry, or substitute a result); reaching here
        # means no handler resolved it. The graph's fallback — pausing the run with a
        # `DeferredToolRequests` output — has no realtime analog (a live conversation can't wait for an
        # out-of-band result, and the provider expects an answer on the string-only tool channel).
        reason = 'requires approval' if isinstance(error, ApprovalRequired) else 'runs externally'
        content = f'Error: The {call.tool_name!r} tool {reason} and cannot be completed during a realtime session.'
    else:
        content = 'The tool raised an unhandled error and the session ended.'
    return ToolReturnPart(
        tool_name=call.tool_name,
        content=content,
        tool_call_id=call.tool_call_id,
        outcome='failed',
    )


def _is_user_speech_request(message: ModelMessage) -> bool:
    """Whether a history request is a transcribed (or audio-only) user speech turn."""
    if not isinstance(message, ModelRequest) or not message.parts:
        return False
    return all(isinstance(part, SpeechPart) and part.speaker == 'user' for part in message.parts)


def _pending_message_text(pending: PendingMessage) -> str:
    """Render enqueued messages down to the text a realtime session can deliver.

    Text-only parts join across messages, and a mid-conversation `SystemPromptPart` is delivered as
    `<system>`-tagged user text — the same degradation `Model.prepare_messages` applies for a
    standard run's non-leading system prompts. Anything else can't cross the live input channel.
    """
    error = UserError(
        '`RealtimeSession.enqueue()` and `RunContext.enqueue()` in a realtime session support plain-text prompts and system-prompt '
        'parts only. Multimodal content and model responses cannot be delivered over the live input '
        'channel.'
    )
    texts: list[str] = []
    for message in pending.messages:
        if not isinstance(message, ModelRequest):
            raise error
        for part in message.parts:
            if isinstance(part, UserPromptPart) and isinstance(part.content, str):
                texts.append(part.content)
            elif isinstance(part, SystemPromptPart):
                texts.append(f'<system>{part.content}</system>')
            else:
                raise error
    if not texts:
        raise error
    return '\n\n'.join(texts)


class _RealtimePendingMessages(PendingMessageQueue):
    """A `RunContext.enqueue` queue that validates content and wakes the live session for delivery."""

    def __init__(self) -> None:
        super().__init__()
        self._on_append: Callable[[PendingMessagePriority], None] | None = None

    def bind(self, on_append: Callable[[PendingMessagePriority], None]) -> None:
        self._on_append = on_append

    def append(self, pending: PendingMessage) -> None:
        _pending_message_text(pending)
        super().append(pending)
        if self._on_append is not None:
            self._on_append(pending.priority)

    def has_priority(self, priority: PendingMessagePriority) -> bool:
        with self._lock:
            return any(pending.priority == priority for pending in self)


class RealtimeSession:
    """Wraps a [`RealtimeConnection`][pydantic_ai.realtime.codec.RealtimeConnection], building message history and auto-executing tools.

    The session translates the connection's low-level codec events into the shared message/part event
    vocabulary from [`pydantic_ai.messages`][pydantic_ai.messages] and accumulates ordinary
    [`ModelMessage`][pydantic_ai.messages.ModelMessage] history as the conversation proceeds, so a
    session can hand off to [`Agent.run`][pydantic_ai.agent.AbstractAgent.run] via
    [`all_messages`][pydantic_ai.realtime.RealtimeSession.all_messages]:

    - assistant speech becomes [`PartStartEvent`][pydantic_ai.messages.PartStartEvent] /
      [`PartDeltaEvent`][pydantic_ai.messages.PartDeltaEvent] / [`PartEndEvent`][pydantic_ai.messages.PartEndEvent]
      events carrying a [`SpeechPart`][pydantic_ai.messages.SpeechPart]
      (`speaker='assistant'`), finalized into a [`ModelResponse`][pydantic_ai.messages.ModelResponse]
      at the end of the turn;
    - user speech becomes the same part events with `speaker='user'`, finalized into a
      [`ModelRequest`][pydantic_ai.messages.ModelRequest];
    - a tool call becomes a [`ToolCallPart`][pydantic_ai.messages.ToolCallPart] (start/end) plus a
      [`FunctionToolCallEvent`][pydantic_ai.messages.FunctionToolCallEvent] when execution starts and a
      [`FunctionToolResultEvent`][pydantic_ai.messages.FunctionToolResultEvent] carrying a normalized
      [`ToolReturnPart`][pydantic_ai.messages.ToolReturnPart] or
      [`RetryPromptPart`][pydantic_ai.messages.RetryPromptPart] when it settles.

    Tools always run concurrently with the session. The session keeps streaming events while a tool
    runs, so the model can keep speaking and user speech keeps being processed, then sends the result
    back over the connection once it is ready. This mirrors how a person can keep talking while work
    happens.

    Tool outcomes use the same normalized history shapes as a classic agent run: retries become
    [`RetryPromptPart`][pydantic_ai.messages.RetryPromptPart]s, denials retain their `outcome`, and
    structured returns preserve `content`, `metadata`, and typed `tool_kind` identity. Realtime
    tool-output channels are string-only, so the structured part is rendered only when it is sent.
    OpenAI-protocol connections send additional user content as a follow-up conversation item; Gemini
    includes a text fallback in its tool response. If the provider cancels an in-flight call, the
    session records a synthetic interrupted return for valid history but does not send that abandoned
    result to the provider.

    History is accumulated in the order events are reported. Provider item IDs keep interleaved input
    transcripts associated with their correct user turns; providers without item IDs retain
    arrival-order association. Tool results are the exception: a tool's
    [`FunctionToolResultEvent`][pydantic_ai.messages.FunctionToolResultEvent] streams whenever the tool
    finishes (possibly after later turns), but in [`all_messages()`][pydantic_ai.realtime.RealtimeSession.all_messages]
    its result part is placed directly after the response carrying its call — request-response APIs
    require that adjacency, so the history stays valid for a handoff to a standard
    [`Agent.run`][pydantic_ai.agent.AbstractAgent.run].

    Images and video frames streamed with [`send`][pydantic_ai.realtime.RealtimeSession.send] are
    stored as ordinary user image turns by default. Set `retain_images_every_n` above `1` to sample
    high-rate frame streams, and `retain_images_max` (default `100`) to bound how many stay in
    history — the oldest retained image is evicted first, so a long-running stream can't grow memory
    without limit. Audio kept by `audio_retention` is bounded the same way: `retain_audio_max_seconds`
    (default `1800`, 30 minutes across both speakers) caps how much stays in memory, evicting the
    oldest retained audio first while keeping its transcript.

    When constructing a session directly, use it as an async context manager. The context owns the
    receive pump, background tool tasks, and instrumentation spans; iteration only reads its event
    queue. [`AgentRealtime.session`][pydantic_ai.agent.AgentRealtime.session] enters the session
    before yielding it, so the usual agent API remains a single `async with` block.
    """

    def __init__(
        self,
        connection: RealtimeConnection,
        *,
        model: RealtimeModel | None = None,
        tool_manager: ToolManager[Any],
        instrumentation: InstrumentationSettings | None = None,
        agent_name: str | None = None,
        usage: RunUsage | None = None,
        usage_limits: UsageLimits | None = None,
        audio_retention: AudioRetention = 'transcript_only',
        handle_barge_in: bool = False,
        retain_images_every_n: int = 1,
        retain_images_max: int | None = 100,
        retain_audio_max_seconds: float | None = 1800,
        message_history: Sequence[ModelMessage] | None = None,
        profile: RealtimeModelProfile | None = None,
        owns_media: bool = True,
        provider_session: RealtimeProviderSession | None = None,
        conversation_id: str | None = None,
        run_id: str | None = None,
        instructions: str | None = None,
        metadata: dict[str, Any] | None = None,
        agent_description: str | None = None,
        output_modality: Literal['audio', 'text'] = 'audio',
        model_request_parameters: ModelRequestParameters | None = None,
        model_settings: RealtimeModelSettings | None = None,
        wrap_event_stream: Callable[[AsyncIterable[AgentStreamEvent]], AsyncIterable[AgentStreamEvent]] | None = None,
    ) -> None:
        self._connection = connection
        self._tool_manager = tool_manager
        self._tool_run_step = 0
        self._tool_manager_lock = Lock()
        self._instrumentation = instrumentation
        self._profile = profile if profile is not None else model.profile if model is not None else _FULL_PROFILE
        self._responses_are_requests = self._profile.get('responses_are_requests', True)
        # The latest context-window fraction the provider reported, if it reports one at all.
        self._reported_context_window_used: float | None = None
        # Whether this session owns the audio transport. `False` for a WebRTC sideband session: the
        # browser exchanges audio with the provider directly, and this connection is only the control
        # plane, so the audio methods are unavailable and no audio bytes flow over it (transcripts still
        # build history). Set by the connect path when a `provider_session` is attached.
        self._owns_media = owns_media
        # The WebRTC call a sideband session runs, which `hang_up()` ends; `None` on a session that owns
        # its own connection, where closing it is what ends the call.
        self._model = model
        self._provider_session = provider_session
        self._hang_up_requested = False
        # The teardown's own failed hangup, which the caller that collects it from `close()` has been told.
        self._teardown_hang_up_error: Exception | None = None
        self._hung_up = False
        self._model_name = model.model_name if model is not None else None
        self._provider_name = model.system if model is not None else None
        self._provider_url = model.base_url if model is not None else None
        self._agent_name = agent_name
        self._conversation_id = conversation_id
        self._run_id = run_id
        # The request parameters and settings the session was opened with. Unlike a classic run — where
        # each model request can vary — a realtime session sends these once at connect, so they belong on
        # the session span (set once), not repeated on every per-turn `chat` span. Carrying
        # `model_request_parameters` is what makes the session's configured native tools inspectable.
        self._model_request_parameters = model_request_parameters
        self._model_settings = model_settings
        self._wrap_event_stream = wrap_event_stream
        self._instructions = instructions
        self._metadata = metadata
        self._agent_description = agent_description
        # All OTel span state and construction lives on the helper; the session hands it the static
        # session metadata once and delegates every span operation (see `realtime/_instrumentation.py`).
        self._session_instrumentation = SessionInstrumentation(
            instrumentation,
            agent_name=agent_name,
            agent_description=agent_description,
            model_name=self._model_name,
            provider_name=self._provider_name,
            provider_url=self._provider_url,
            conversation_id=conversation_id,
            run_id=run_id,
            instructions=instructions,
            metadata=metadata,
            model_request_parameters=model_request_parameters,
            model_settings=model_settings,
            output_type='speech' if output_modality == 'audio' else 'text',
        )
        self._usage_limits = usage_limits
        self._audio_retention = audio_retention
        self._audio_budget = RetainedAudioBudget(
            retain_audio_max_seconds,
            input_sample_rate=self.audio_input_sample_rate,
            output_sample_rate=self.audio_output_sample_rate,
        )
        self._retain_input = audio_retention in ('input_audio', 'all') and self._audio_budget.retains_audio
        self._retain_output = audio_retention in ('output_audio', 'all') and self._audio_budget.retains_audio
        self._handle_barge_in = handle_barge_in
        if retain_images_every_n < 1:
            raise UserError('`retain_images_every_n` must be at least 1.')
        self._retain_images_every_n = retain_images_every_n
        if retain_images_max is not None and retain_images_max < 0:
            raise UserError('`retain_images_max` must be at least 0, or `None` for no limit.')
        self._retain_images_max = retain_images_max
        # Retained image requests in arrival order, so the cap can evict the oldest. Identity-based:
        # `_record_sent_request` stores these same objects in the pending list or the history.
        self._retained_image_requests: list[ModelRequest] = []
        self._sent_image_count = 0
        # Every `send()` made on the connection is numbered, the same way the connection numbers the
        # inputs it receives, so an `InputRejected` can name the request whose content the provider
        # refused. Weak, so an image evicted from history by the retention cap isn't kept alive here.
        self._inputs_sent = 0
        self._input_requests: weakref.WeakValueDictionary[int, ModelRequest] = weakref.WeakValueDictionary()
        # Whether the connection transcribes the user's audio. When it doesn't, no `InputTranscript`
        # arrives to finalize a user turn, so its retained audio or content-less placeholder is finalized
        # at the turn boundary (see `_finalize_untranscribed_user`).
        self._input_transcription_enabled = connection.input_transcription_enabled
        self.usage = usage if usage is not None else RunUsage()
        """Cumulative token usage and tool-call counts for the session, updated as events stream in.

        Pass `usage` to [`Agent.realtime`][pydantic_ai.agent.AbstractAgent.realtime] to accumulate
        into a shared [`RunUsage`][pydantic_ai.usage.RunUsage]; otherwise a fresh one is used.
        """
        # `ToolManager` increments `tool_calls` on its context's usage as each call succeeds, and the
        # session is the single authority for `session.usage`, so the two have to be the same object.
        # A caller can pass a `usage` the manager wasn't built with, and rebinding the context properly
        # would mean `for_run_step`, which is async and can't run here.
        if (ctx := self._tool_manager.ctx) is not None:
            ctx.usage = self.usage
        # What the session span reports: only the token usage this session's own responses recorded.
        # `self.usage` can start from a total carried in with `usage=` (or a `Conversation`), and a run
        # a tool starts with `usage=ctx.usage` accumulates into it too; reporting that on the span would
        # count both again against the spans they came from. Credited where `self.usage` records it.
        self._span_usage = RunUsage()

        # History: `_seeded` is the conversation the session was opened with (surfaced by
        # `all_messages` only); `_history` is what happened during this session (surfaced by both).
        self._seeded: list[ModelMessage] = list(message_history or [])
        self._history: list[ModelMessage] = []
        self._replayed_item_ids: set[str] = set()
        self._replayed_tool_call_ids: set[str] = set()

        # In-flight assistant response being assembled. Parts finalize into `_response_parts`, which
        # becomes a `ModelResponse` at the turn boundary (or when a tool call splits the turn).
        self._response_parts: list[ModelResponsePart] = []
        # Native tool parts reconstructed from a turn's provider metadata (web grounding / code
        # execution), buffered as they arrive mid-turn and prepended to the response at finalization so
        # history reads native-tool-activity-then-speech, mirroring the classic `GoogleModel` order.
        self._native_tool_parts: list[ModelResponsePart] = []
        # When the provider's VAD reported the user's current speech segment starting, in OTel's
        # nanosecond clock, so the `user speech` span can be backdated to it (see
        # `_record_user_speech_span`). `None` while nobody is speaking.
        self._user_speech_started_at: int | None = None
        # Whether the provider's own turn detection has already cancelled the response now in
        # flight, because the user spoke over it. A client `CancelResponse` racing the server's own
        # can be applied to the *next* response and silence the reply to the barge-in, so an
        # interruption of a response the server is already stopping sends only the truncation.
        # Latched at speech onset rather than read off the clock: the pump can reach the speech
        # *end* before the app has even dequeued the start it is reacting to, and the fact this
        # guards is a property of the response, not of how long the user kept talking. Released
        # when the next response opens, and by a reconnect that discards the one it referred to.
        self._server_cancelled_the_response_on_speech = False
        # Set once the provider draws its first speech-end boundary. Gemini never does, so its
        # retained input is only ever consumed by a turn, never trimmed at one.
        self._provider_segments_input = False
        self._pending_response_usage = RequestUsage()
        self._response_limit_checked = False
        self._pending_response_requests = 0
        # The requests this session recorded. What it reserves against `request_limit` is released when it
        # records them, while the core counts them into `usage.requests` as their frames arrive, a moment
        # earlier: the projection counts each by this session's clock, so none is counted twice in between.
        self._requests_recorded = 0
        # Whether a response has actually begun, cleared at the exchange boundary that
        # `RealtimeTurnCompleteEvent` marks. A tool-calling turn spans several responses, so the
        # per-response flags above would read as "done" in the gaps. Reads pair with
        # `_pending_response_requests` for the solicited-but-not-started half — see `_reply_outstanding`.
        self._response_active = False
        self._exchange_progress = asyncio.Event()
        self._pending_provider_response_id: str | None = None
        # The provider id carried by the latest content of the response being assembled, for a reply
        # that never gets the terminal that would otherwise name it: one cut off by a dropped connection
        # or by closing the session. Reset at each response boundary.
        self._content_response_id: str | None = None
        self._pending_finish_reason: FinishReason | None = None
        self._pending_provider_details: dict[str, Any] | None = None
        self._pending_interrupted_at_ms: int | None = None
        self._response_finalized_before_terminal = False
        # User requests sent while a response is in flight are held until that response is finalized,
        # so the pump remains the sole writer for that portion of history and a caller cannot splice a
        # request between an assistant response's streamed parts.
        self._pending_sent_requests: list[ModelRequest] = []
        self._active_assistant: SpeechPart | TextPart | None = None
        self._active_assistant_item_id: str | None = None
        self._active_assistant_index = 0
        self._assistant_transcript = ''
        self._output_audio = bytearray()
        # The index and part of each output item whose part ended in the response being assembled, for a
        # transcript of the item that arrives after it ended.
        self._ended_assistant_parts: dict[str, tuple[int, SpeechPart | TextPart]] = {}

        # A realtime session is duplex: the user's part and the model's assemble at the same time, and
        # each response starts a fresh `_response_parts` list. Numbering streamed parts by their
        # position in a message would therefore hand out index 0 to both sides at once, so a consumer
        # couldn't tell whose delta it holds. One monotonic counter per session keeps every streamed
        # part's index unique instead: in realtime, `index` identifies a part in the event stream, not
        # a slot in a message.
        self._next_part_index = 0
        # Connection-supplied native-tool part index -> the session index it was remapped to, so a
        # `PartEndEvent` closes the part its `PartStartEvent` opened. See `_remap_native_part_index`.
        self._native_part_indexes: dict[int, int] = {}

        # In-flight user request being assembled from input-transcript events.
        self._user_turn_active = False
        self._anonymous_user_turns_ended = 0
        # An id-less final can precede its matching speech-end frame, so remember it until audio or a
        # transcription event begins the next turn instead of letting that trailing frame open a blank one.
        self._anonymous_user_turn_finalized = False
        # Set once an anonymous user turn has ended (its transcript finalized, or the model began replying),
        # until a response answering it is recorded. A continuously open microphone keeps sending (silent)
        # audio all the while; that audio is not a new turn, and must not reserve a place in history ahead
        # of the answer it overlaps.
        self._anonymous_user_turn_awaiting_answer = False
        # Insertion order is provider item order. `None` is the single anonymous turn used by
        # providers that do not identify input transcript items.
        self._user_turns: dict[str | None, _UserTurn] = {}
        self._finalized_user_item_ids: set[str] = set()
        # Where in history each user turn belongs, remembered when the turn *starts* — see
        # `_open_user_turn_anchor`. Provider item IDs keep overlapping turns paired with their own
        # anchors; `_pending_anonymous_user_turn_anchors` is only for providers whose events carry no
        # item ID. It is a queue because a transcript can arrive after the next audio turn starts.
        self._pending_anonymous_user_turn_anchors: deque[_UserTurnAnchor] = deque()
        self._pending_user_turn_anchors: dict[str, tuple[_UserTurnAnchor]] = {}
        self._user_turn_anchors: dict[str | None, _UserTurnAnchor] = {}
        # The commit a connection that `_defers_audio_commit` holds, which user turns starting now belong to,
        # and sent ones placed after a response that isn't recorded yet.
        self._held_commit = _HeldCommit()
        self._sent_commit: _HeldCommit | None = None
        self._held_commits_in_flight: list[_HeldCommit] = []
        # User turns held in `_pending_sent_requests` until the response they interrupted is recorded, and
        # the watchdog that records them anyway if it never is (see `_BARGE_IN_TURN_HOLD_SECONDS`).
        self._held_user_turns: list[ModelRequest] = []
        self._held_user_turn_watchdog: asyncio.TimerHandle | None = None
        # With the session core: the timer of each spoken turn waiting for its transcript (see
        # `_TRANSCRIPT_HOLD_SECONDS`).
        self._transcript_watchdogs: dict[str, asyncio.TimerHandle] = {}
        # Whether audio was sent since the last `commit_audio()` or `clear_audio()`: committing an empty
        # buffer is no user turn.
        self._audio_uncommitted = False
        # Retained input audio (`audio_retention='input_audio'`/`'all'`). `_input_audio` is the rolling buffer
        # of audio sent since the last turn boundary; on providers that report a per-item speech-stopped
        # boundary, each segment is cut into `_input_segments` keyed by its input item id, so overlapping
        # turns whose transcripts finalize out of order still attach their own audio (not a later turn's).
        self._input_audio = bytearray()
        self._input_segments = _InputSegments()
        # Where in history the next pass for audio to evict starts: eviction goes oldest first, so the messages
        # before it hold no retained audio any more. A message inserted or removed before it moves it along.
        self._audio_eviction_start = 0

        # The session context is the single owner of the receive pump and background tool tasks.
        # It starts the pump on entry and never tears it down before `close()`: an early `break` can
        # abandon the reader generator without affecting resource lifetime, and `__aexit__` still
        # drains everything before the connection and toolset close.
        self._queue: deque[RealtimeEvent | object] = deque()
        self._queue_event = asyncio.Event()
        self._queue_delta_count = 0
        self._queue_dropped_deltas = 0
        self._queue_structural_count = 0
        self._queue_dropped_structural = 0
        self._queue_changed = object()
        self._tap_finished = object()
        self._audio_taps: set[_AudioTap] = set()
        self._transcript_taps: set[asyncio.Queue[SpeechPart | object]] = set()
        self._transcript_delta_taps: set[asyncio.Queue[TranscriptUpdate | object]] = set()
        self._audio_tap_drops = 0
        self._transcript_tap_drops = 0
        # Emitted-audio coordinates for `interrupt(played_bytes=...)`: cumulative output audio bytes,
        # the offset and part index where the current audio part began, and the index of a part whose
        # remaining audio a barge-in erased (its stragglers are dropped as they arrive).
        self._emitted_audio_bytes = 0
        self._turn_audio_start_bytes = 0
        self._audio_part_index: int | None = None
        self._interrupted_audio_part_index: int | None = None
        # Where each recent assistant audio part begins in the emitted audio, with its provider output
        # item. Generation outruns playback, so the reply being heard is often not the last one
        # generated: a barge-in truncates the item actually playing (and later ones, never heard, at 0).
        self._audio_items: deque[tuple[int, str | None]] = deque(maxlen=_MAX_TRUNCATABLE_AUDIO_ITEMS)
        # Transcript accumulated per streamed part index, so a `TranscriptUpdate` can carry the whole
        # turn so far and a renderer can replace rather than append.
        self._transcript_so_far: dict[int, str] = {}
        self._background_tasks: set[asyncio.Task[None]] = set()
        self._pending_messages = _RealtimePendingMessages()
        self._pending_messages_lock = Lock()
        # Serializes everything we send. Tool results go out from background tasks while the caller may
        # be streaming audio or driving turn control, and a single operation can span several frames:
        # a tool result creates the item and then asks for a response, and `interrupt()` truncates
        # before it cancels. Without this, those sequences interleave — a barge-in's cancel can land on
        # a response that a tool result started in the gap, killing the wrong turn.
        self._send_lock = Lock()
        if self._tool_manager.ctx is not None:
            self._tool_manager.ctx.pending_messages = self._pending_messages
        # In-flight tool tasks keyed by tool call id, so a `ToolCallCancelled` can cancel the specific
        # calls the model abandoned (e.g. on barge-in) without touching the others.
        self._pending_tool_calls: dict[str, tuple[asyncio.Task[None], ToolCallPart]] = {}
        # Tool execution is gated inside each task so the receive pump remains free to deliver audio,
        # transcripts, and cancellations. A barrier snapshots every unfinished predecessor; an ordinary
        # call only waits for the latest barrier. Completion events are released from `_run_tool`'s
        # `finally`, including cancellation and failure paths.
        self._tool_completion_events: set[asyncio.Event] = set()
        self._last_tool_barrier: asyncio.Event | None = None
        # OpenAI-protocol tool results can complete before the response's later `response.done` usage
        # finalizes the calling response. Hold their history requests until the call is present.
        self._pending_tool_returns: list[tuple[ToolCallPart, ModelRequest]] = []
        self._tool_calls_awaiting_usage: set[str] = set()
        # The batch the response being assembled is adding tool calls to, closed when that response is
        # finalized; the batch of every call whose batch hasn't settled; and batches just closed, which
        # the pump checks for a reply still to count. See `_ToolBatch`.
        self._open_tool_batch: _ToolBatch | None = None
        self._tool_call_batches: dict[str, _ToolBatch] = {}
        self._closed_tool_batches: list[_ToolBatch] = []
        # Set while a response the provider said isn't the last of its exchange is held open for the
        # tool call it was stalling for; the finish reason it will be recorded with if something else
        # arrives first. See `_handle_turn_complete`.
        self._deferred_response_finish_reason: FinishReason | None = None
        # `ToolManager` adds a call to `usage.tool_calls` only once it *succeeds*, so calls still
        # running aren't visible there. Reserved when a `ToolCall` passes `_check_tool_call_limit`,
        # released the moment `handle_call` settles (the same event-loop segment that records a
        # success), so a burst of parallel calls can't each clear a limit only one of them fits under.
        self._tool_calls_in_flight = 0
        # `parallel_ordered_events` buffers: call-order index -> the events that call produced.
        self._ordered_tool_events: dict[int, list[RealtimeEvent]] = {}
        self._next_tool_order_index = 0
        self._asap_drain_deferred = False
        self._asap_drain_ready = False
        self._pump_task: asyncio.Task[None] | None = None
        self._pump_error: Exception | None = None
        self._pump_finished = False
        self._receive_ending = False
        self._iterator_active = False
        self._stream_exhausted = False
        self._parked_errors: list[BaseException] = []
        self._delivered_errors: list[BaseException] = []
        self._entered = False
        self._closed = False
        self._closing_error: BaseException | None = None
        self._teardown: asyncio.Task[None] | None = None
        self._close_error: BaseException | None = None
        self._loop: asyncio.AbstractEventLoop | None = None

        self._traceparent_value: str | None = None
        self._result: AgentRunResult[str] | None = None

        # The new core, which keeps history, usage, and reply waits on a connection that identifies its
        # responses, turns, and inputs (see `_CORE_MODE`).
        self._core: SessionCore | None = None
        if _CORE_MODE == 'core' and connection._lifecycle_version == 2:  # pyright: ignore[reportPrivateUsage]
            requested_model = self._model_name
            self._core = SessionCore(
                model_name=lambda: connection.model_name or requested_model,
                provider_name=self._provider_name,
                provider_url=self._provider_url,
                conversation_id=conversation_id,
                run_id=run_id,
                responses_are_requests=self._responses_are_requests,
                input_transcription_enabled=self._input_transcription_enabled,
                retain_input_audio=self._retain_input,
                retain_output_audio=self._retain_output,
                retain_audio_max_seconds=retain_audio_max_seconds,
                input_sample_rate=self.audio_input_sample_rate,
                output_sample_rate=self.audio_output_sample_rate,
                seeded=self._seeded,
                usage=self.usage,
            )

    async def __aenter__(self) -> RealtimeSession:
        if self._entered or self._closed:
            raise UserError('This realtime session cannot be entered more than once.')
        self._entered = True
        self._loop = asyncio.get_running_loop()
        self._pending_messages.bind(self._notify_pending_messages)
        if self._profile.get('supports_session_seeding', False):
            # Offer the conversation for replay, so a provider that keeps no state across sessions can
            # carry the call through a reconnect instead of resuming with amnesia. Gated on seeding
            # support because that is the mechanism, and a no-op where the provider resumes natively.
            self._connection.set_message_history(
                self.all_messages if self._core is None else self._core.replayable_messages
            )
        self._connection._set_audio_commit_listener(self._place_held_commit)  # pyright: ignore[reportPrivateUsage]

        self._session_instrumentation.start_session_span()

        return self

    def _record_user_speech_span(self) -> None:
        """Consume the pending speech onset and record the spoken segment as a `user speech` span."""
        started_at, self._user_speech_started_at = self._user_speech_started_at, None
        self._session_instrumentation.record_user_speech(started_at)

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        self._closing_error = exc_value
        await self.close()

    async def close(self) -> None:
        """Close the session and end its live stream views.

        This method is idempotent. Concurrent callers wait for the same teardown, which continues if
        a caller is cancelled; leaving the session context waits for it to finish. Active
        [`stream_audio()`][pydantic_ai.realtime.RealtimeSession.stream_audio] and
        [`stream_transcripts()`][pydantic_ai.realtime.RealtimeSession.stream_transcripts] iterators
        finish cleanly, with any buffered items discarded. The surrounding model context owns the
        underlying connection, so it remains open until that context exits.

        A tool can call this method through
        [`ctx.realtime_session`][pydantic_ai.tools.RunContext.realtime_session] to end the session. The
        calling tool does not resume, and its call is recorded as interrupted. On a WebRTC sideband this only
        detaches, and the browser's call stays up: use
        [`hang_up()`][pydantic_ai.realtime.RealtimeSession.hang_up] to end it.

        Raises whatever ended the session — a provider hangup, an exceeded `usage_limits`, or a failed
        tool — unless it was already raised by event iteration or an outbound session method.
        """
        if not self._entered:
            return
        if self._teardown is None:
            self._pending_messages.close()
            self._closed = True
            self._finish_taps(discard_pending=True)
            self._release_exchange()
            # A session closed without ever sending, subscribing, or iterating never started one.
            # Cancelled before state is settled below so it can't mutate state mid-settlement; the
            # task is awaited together with the rest afterwards.
            if self._pump_task is not None:
                self._pump_task.cancel()
            if (early_error := self._closing_error or self._pump_error) is not None and (
                chat_span := self._session_instrumentation.chat_span
            ) is not None:
                # The reply this span covers is being torn down by a failure; record it now, before the
                # settlement below finalizes the interrupted response and ends the span cleanly.
                self._session_instrumentation.record_error(chat_span, early_error)
            self._flush_pending_users()
            if (
                self._pending_response_usage != RequestUsage()
                and self._active_assistant is None
                and not self._response_parts
            ):
                # Usage carried forward from an output-less turn boundary that no later response claimed.
                # Better an empty response holding it than silently dropping billed tokens — and, with no
                # reply in flight, nothing here was interrupted, so it isn't settled as such below.
                self._finalize_response(response_occurred=True)
            # Settle whatever the closing session still holds open, exactly as a reconnect settles state
            # the provider lost: open user turns land in history, a reply cut off mid-generation is
            # recorded as interrupted, and every still-running tool call gets a cancelled return. The
            # returned events are discarded — the stream is closing and has no consumer left.
            self._finalize_lost_state()
            self._apply_core(Closed())
            self._teardown = asyncio.create_task(self._finish_teardown())
        elif asyncio.current_task() in self._background_tasks:
            # A tool closing the session is cancelled by the teardown, at the wait below of its own
            # `close()` call. One that swallows that cancellation and calls `close()` again would wait
            # for a teardown that is waiting for it, so there is nothing to wait for from this side.
            return

        # `asyncio.shield` lets a cancelled caller stop waiting while the teardown continues; the
        # shielded scope makes an outer *anyio* cancellation — level-triggered, re-raised at every
        # checkpoint — wait for the teardown instead of abandoning it (see `agent_docs/concurrency.md`).
        with anyio.CancelScope(shield=True):
            await asyncio.shield(self._teardown)
        if (error := self._close_error) is not None:
            self._close_error = None
            raise error

    async def hang_up(self) -> None:
        """End the call, then close the session.

        On a [WebRTC sideband](../realtime/deployment.md#browser-webrtc-server-sideband) session,
        [`close()`][pydantic_ai.realtime.RealtimeSession.close] only detaches this server from the call,
        and the browser stays connected to the provider (and billed) until it hangs up itself. This asks the
        provider to end the call for everyone. On a session that owns its connection, closing it already
        ends the call, so this is the same as `close()`. Either way, the session is closed afterwards, as
        by `close()`.

        A tool can call this method through
        [`ctx.realtime_session`][pydantic_ai.tools.RunContext.realtime_session], as it can `close()`: the
        call is still ended after the tool itself is cancelled by the teardown.

        Raises [`ModelHTTPError`][pydantic_ai.exceptions.ModelHTTPError] or
        [`ModelAPIError`][pydantic_ai.exceptions.ModelAPIError] if the provider refuses to end the call,
        and [`UserError`][pydantic_ai.exceptions.UserError] if the model can't hang up WebRTC calls.
        """
        provider_session, model = self._provider_session, self._model
        if provider_session is None or model is None:
            await self.close()
            return
        # Refused before anything is torn down, so a model that can't hang up leaves the session as it was.
        model._check_hang_up(provider_session)  # pyright: ignore[reportPrivateUsage]
        # The call is ended from the teardown, once the pump has stopped: the provider closes the sideband
        # when the call ends, which the pump would otherwise report as a lost connection.
        self._hang_up_requested = True
        close_error: BaseException | None = None
        try:
            await self.close()
        except BaseException as e:
            close_error = e
            raise
        finally:
            teardown_done = self._teardown is None or self._teardown.done()
            told_of_failure = close_error is not None and close_error is self._teardown_hang_up_error
            if not self._hung_up and teardown_done and not told_of_failure:
                # The call is still up, and this caller hasn't been told why: the session was closed (or
                # never started) before this call, another caller collected the teardown's failed hangup,
                # or one is being retried. Even if closing raised something else, the call must still end.
                try:
                    await self._hang_up_call()
                except Exception as hang_up_error:
                    if close_error is not None:
                        _chain_context(hang_up_error, close_error)
                    raise

    async def _hang_up_call(self) -> None:
        provider_session, model = self._provider_session, self._model
        assert provider_session is not None and model is not None
        await model.hang_up(provider_session)
        # Only once it worked: a hangup that failed leaves the call up, so asking again tries again.
        self._hung_up = True

    async def _finish_teardown(self) -> None:
        # A session closed without ever sending, subscribing, or iterating started no pump, so there
        # may be nothing here but the background tasks.
        pump_tasks = (self._pump_task,) if self._pump_task is not None else ()
        await cancel_and_drain(*self._background_tasks, *pump_tasks, msg='Realtime session exited')
        # A WebRTC sideband doesn't own the provider session: ending it would end the browser's call. A
        # provider that already went away is the connection's to recognize, which it can do for certain.
        # A cancelled session closes promptly instead of waiting on the provider.
        if self._owns_media and not isinstance(self._closing_error, asyncio.CancelledError):
            await self._record_final_usage()
        hang_up_error: Exception | None = None
        if self._hang_up_requested and not self._hung_up:
            try:
                await self._hang_up_call()
            except Exception as e:
                hang_up_error = self._teardown_hang_up_error = e

        # Any open `chat` span was closed by the settlement above (an open span counts as a response
        # in flight), with the error — if any — already recorded on it before settlement.
        error = self._closing_error or self._pump_error
        # Closing mid-utterance is normal (the caller stopped listening), so the `speak` span is closed
        # rather than left open; it isn't an error even when the session ended on one.
        self._session_instrumentation.end_playback_span()
        # A session closed mid-sentence never learns how long that sentence was, so the pending onset
        # is dropped rather than turned into a span ending at teardown.
        self._user_speech_started_at = None

        self._traceparent_value = self._session_instrumentation.end_session_span(
            error,
            usage=self._span_usage,
            messages=self.all_messages(),
            new_message_index=len(self._seeded) if self._seeded else None,
            final_result=self._final_result_text(),
            audio_chunks_dropped=self._audio_tap_drops,
            transcript_items_dropped=self._transcript_tap_drops,
            queue_dropped_deltas=self._queue_dropped_deltas,
            queue_dropped_structural=self._queue_dropped_structural,
        )
        self._loop = None
        self._stop_held_user_turn_watchdog()
        for watchdog in self._transcript_watchdogs.values():
            watchdog.cancel()
        self._transcript_watchdogs.clear()

        # Do not hide the caller's own exception, but make sure every receive-side failure has one
        # delivery point even when iteration stopped early or was never started. Stored rather than
        # raised: `close()` raises it once, for the first caller that finishes waiting on the
        # teardown. Recorded as delivered so no later path delivers it a second time.
        if self._closing_error is None and (error := self._first_undelivered_error()) is not None:
            self._delivered_errors.append(error)
            self._close_error = error
        if hang_up_error is not None:
            # A call left up is what matters most to the caller, so it wins; anything that ended the
            # session first stays attached to it.
            if self._close_error is not None:
                _chain_context(hang_up_error, self._close_error)
            self._close_error = hang_up_error

    async def _record_final_usage(self) -> None:
        """End the provider session, recording the usage it reports only as it ends.

        Runs once nothing reads the connection any more and before the session span reports its usage, so
        what a provider bills at the very end (GPT-Live's last seconds of audio) is counted. Bounded, and
        best-effort: what the provider reported before it stopped answering in time, or before the link
        failed, is recorded, and nothing more.
        """
        recorded = False
        try:
            with anyio.move_on_after(_END_SESSION_TIMEOUT):
                async for report in self._connection._end_session():  # pyright: ignore[reportPrivateUsage]
                    if report.context_window_used is not None:
                        self._reported_context_window_used = report.context_window_used
                    self.usage.incr(report.usage)  # usage-attribution: the session owns its spans
                    if report.response_scoped and not self._responses_are_requests:
                        # A request the model made (GPT-Live's backend finishing as the session closed), held to
                        # the request limits as one reported while the session ran is.
                        self.usage.requests += 1  # usage-attribution: the session owns its spans
                        self._park_exceeded_limit(partial(self._check_final_request, report.usage))
                    self._span_usage.incr(report.usage)  # usage-attribution: what the session span reports
                    recorded = True
        except self._connection.transport_errors:
            pass
        if recorded:
            # The session is closed, so an exceeded limit is parked for `close()` to raise.
            self._check_response_boundary_limits()

    def _queue_put(self, item: RealtimeEvent | object) -> None:
        """Append an item, bounding the queue while no session iterator is active."""
        if isinstance(item, PartDeltaEvent):
            self._queue_delta_count += 1
        elif self._is_structural(item):
            self._queue_structural_count += 1
        self._queue.append(item)
        if not self._iterator_active:
            self._trim_queue()
        self._queue_event.set()

    def _is_structural(self, item: RealtimeEvent | object) -> bool:
        """Whether an item is a droppable non-delta event.

        Excludes the parked exceptions `close()` sweeps for, and the wake-up sentinels whose arrival
        is what makes the iterator re-check for a pump error or for termination — neither is history
        a later reader can do without, and both are rare enough not to be what grows the queue.
        """
        return not isinstance(item, BaseException) and item is not self._queue_changed

    def _trim_queue(self) -> None:
        while self._queue_delta_count > _SESSION_DELTA_QUEUE_SIZE:
            # Deltas make up the bulk of a backed-up queue, so the oldest one is close to the head: the
            # scan and the deque deletion are linear only in what is kept ahead of it, which the
            # structural bound below caps in turn.
            oldest = next(index for index, queued in enumerate(self._queue) if isinstance(queued, PartDeltaEvent))
            del self._queue[oldest]
            self._queue_delta_count -= 1
            self._queue_dropped_deltas += 1
        while self._queue_structural_count > _SESSION_STRUCTURAL_QUEUE_SIZE:
            position = next(
                position
                for position, queued in enumerate(self._queue)
                if not isinstance(queued, PartDeltaEvent) and self._is_structural(queued)
            )
            evicted = self._queue[position]
            del self._queue[position]
            self._queue_structural_count -= 1
            self._queue_dropped_structural += 1
            if isinstance(evicted, PartStartEvent):
                # A part's start always precedes its deltas and its end, so this is the whole part
                # going: drop the rest of it rather than leave deltas a reader cannot attach to
                # anything. Part indexes are unique for the life of the session (`_next_part_index`
                # only ever increments), except that a late transcript streams an ended part again
                # under its index (see `_late_assistant_transcript`): that restart is whole by itself.
                self._drop_queued_part(position, evicted.index)

    def _drop_queued_part(self, position: int, index: int) -> None:
        """Drop the deltas and end queued from `position` on for the part at `index`, up to a restart of it."""
        while position < len(self._queue):
            queued = self._queue[position]
            if isinstance(queued, PartStartEvent) and queued.index == index:
                break
            if not isinstance(queued, (PartDeltaEvent, PartEndEvent)) or queued.index != index:
                position += 1
                continue
            del self._queue[position]
            if isinstance(queued, PartDeltaEvent):
                self._queue_delta_count -= 1
                self._queue_dropped_deltas += 1
            else:
                self._queue_structural_count -= 1
                self._queue_dropped_structural += 1

    def _queue_get_nowait(self) -> RealtimeEvent | object:
        item = self._queue.popleft()
        if isinstance(item, PartDeltaEvent):
            self._queue_delta_count -= 1
        elif self._is_structural(item):
            self._queue_structural_count -= 1
        return item

    async def _queue_get(self) -> RealtimeEvent | object:
        while not self._queue:
            # Nothing can append between the clear and the wait: producers run on this event loop.
            self._queue_event.clear()
            await self._queue_event.wait()
        return self._queue_get_nowait()

    @property
    def closed(self) -> bool:
        """Whether the session has been closed."""
        return self._closed

    @property
    def result(self) -> AgentRunResult[str] | None:
        """The final result once the session context has exited, otherwise `None`."""
        return self._result

    def _build_run_result(self, state: _agent_graph.GraphAgentState) -> AgentRunResult[str]:
        """Settle the session into the same result shape `Agent.run(output_type=str)` returns.

        The output is the model's final text — a session has no other kind of output — and
        `new_message_index` is the seeded/recorded boundary, so `result.new_messages()` and
        `new_messages()` agree. `_output_tool_name` stays `None`: plain text never came from a tool.
        """
        state.message_history = self.all_messages()
        return AgentRunResult(
            self._final_result_text() or '',
            None,
            state,
            len(self._seeded),
            self._traceparent_value,
        )

    @property
    def profile(self) -> RealtimeModelProfile:
        """What the connected model supports, as [`RealtimeModel.profile`][pydantic_ai.realtime.RealtimeModel.profile].

        Available here because the session is what a call actually holds: `agent.realtime()` accepts a
        model *name* and builds the model itself, leaving nothing else to read the profile from. The
        audio sample rates have their own dedicated properties —
        [`audio_input_sample_rate`][pydantic_ai.realtime.RealtimeSession.audio_input_sample_rate] and
        [`audio_output_sample_rate`][pydantic_ai.realtime.RealtimeSession.audio_output_sample_rate] —
        so most code never needs to read the profile directly.
        """
        return self._profile

    @property
    def audio_input_sample_rate(self) -> int:
        """The sample rate, in Hz, of the raw PCM audio this session expects.

        Resample the microphone to this rate before
        [`send_audio`][pydantic_ai.realtime.RealtimeSession.send_audio]: audio sent at the wrong rate
        is heard as a chipmunk (or slow-motion voice) rather than reported as an error.
        """
        return self._profile.get('audio_input_sample_rate', DEFAULT_AUDIO_SAMPLE_RATE)

    @property
    def audio_output_sample_rate(self) -> int:
        """The sample rate, in Hz, of the raw PCM audio [`stream_audio()`][pydantic_ai.realtime.RealtimeSession.stream_audio] yields.

        Play output at this rate; it can differ from
        [`audio_input_sample_rate`][pydantic_ai.realtime.RealtimeSession.audio_input_sample_rate]
        (Gemini Live, for example, listens at 16 kHz and speaks at 24 kHz).
        """
        return self._profile.get('audio_output_sample_rate', DEFAULT_AUDIO_SAMPLE_RATE)

    @property
    def context_window_used(self) -> float | None:
        """Fraction of the model's context window occupied, as of the latest report.

        When the provider reports it (OpenAI GPT-Live), this is the latest value it reported. Otherwise
        it is computed as for a standard run's
        [`RunContext.context_window_used`][pydantic_ai.tools.RunContext.context_window_used]: the latest
        response's [`total_tokens`][pydantic_ai.usage.RequestUsage.total_tokens] over the model's
        [`context_window`][pydantic_ai.realtime.RealtimeModelProfile.context_window].

        The value can go down as the session continues, when the provider compacts or truncates the
        conversation server-side. Returns `None` when the ratio cannot be calculated: when the context
        window or usage is unknown, before the first response, or when the model's response usage
        doesn't measure what the context holds (see
        [`response_usage_covers_context`][pydantic_ai.realtime.RealtimeModelProfile.response_usage_covers_context]).
        """
        if self._reported_context_window_used is not None:
            return self._reported_context_window_used
        if not self._profile.get('response_usage_covers_context', True):
            return None
        return context_window_fraction(self.all_messages(), self._profile.get('context_window'))

    def stream_audio(self) -> AsyncIterator[bytes]:
        """Stream model audio chunks ready for playback.

        The iterator contains only live model audio, in playback order. It never repeats retained
        audio from finalized speech parts. On a WebRTC sideband the browser owns the audio path, so
        this raises [`UserError`][pydantic_ai.exceptions.UserError]; consume the browser's remote media
        track instead.

        The subscription starts when this method is called, so audio the model produces between
        the call and the consumer's first iteration is buffered rather than missed. A view handed
        to `asyncio.create_task` therefore misses nothing while waiting for its first turn on the
        event loop. Models generate speech several times faster than it plays, so each iterator
        buffers up to five minutes of audio: a consumer that plays each chunk before pulling the next
        receives a long reply in full. Past that bound (a consumer that stopped iterating, or never
        started), the oldest chunk is dropped so audio playback cannot stall tool execution, turn
        tracking, or the main event stream; an unconsumed view keeps that bounded buffer until it
        is collected. A device-paced consumer also feeds
        [`played_audio_bytes`][pydantic_ai.realtime.RealtimeSession.played_audio_bytes], and on
        barge-in [`interrupt(played_bytes=...)`][pydantic_ai.realtime.RealtimeSession.interrupt]
        discards buffered chunks the user will never hear, so a playback loop can iterate one
        stream for the whole session. Closing the session discards buffered chunks and ends the
        iterator cleanly. If a tool fails while the event stream has no consumer, this view ends and
        the error is raised when the session closes.
        """
        self._require_media_ownership('stream_audio')
        self._ensure_streamable()
        # The queue itself is unbounded: `_AudioTap.put` bounds it by bytes, and the completion
        # sentinel always fits behind a full buffer without discarding audio or blocking teardown.
        queue: asyncio.Queue[bytes | object] = asyncio.Queue()
        tap = _AudioTap(
            queue=queue,
            subscribed_at_bytes=self._emitted_audio_bytes,
            max_buffered_bytes=_AUDIO_TAP_SECONDS * self.audio_output_sample_rate * 2,
        )
        self._audio_taps.add(tap)
        if self._pump_finished:
            queue.put_nowait(self._tap_finished)
        else:
            self._start_pump()

        async def iterate() -> AsyncGenerator[bytes, None]:
            try:
                while (item := await queue.get()) is not self._tap_finished:
                    assert isinstance(item, bytes)
                    tap.buffered_bytes -= len(item)
                    # Taking this chunk steps over every gap that opened before it, so those now sit
                    # behind the playback position and belong in the mapping.
                    tap.dropped_bytes += tap.pending_dropped_bytes
                    tap.pending_dropped_bytes = 0
                    yield item
                    # Resuming here means the consumer came back for the next chunk. Under the
                    # documented playback pattern — write each chunk to the device before pulling the
                    # next — that is the moment the previous chunk finished playing, which is what
                    # makes `played_audio_bytes` an accurate playback position with no caller counting.
                    tap.played_bytes += len(item)
                    tap.progress.set()
            finally:
                tap.finish()
                self._audio_taps.discard(tap)

        return _TapView(iterate(), self._audio_taps, tap, tap.finish)

    async def wait_for_playback(self) -> None:
        """Wait until the session's single audio view has accounted for all audio emitted so far.

        Call this after a reply finishes generating, before closing the session or opening the
        microphone, so buffered audio is not cut off. Playback advances with the same one-chunk lag
        as [`played_audio_bytes`][pydantic_ai.realtime.RealtimeSession.played_audio_bytes]: a chunk
        counts once the consumer requests the next one. Audio the view never plays counts as accounted for
        rather than played: discarded by a barge-in or by the view's buffer overflowing, or emitted before
        the view subscribed. The wait also ends if the view is closed or abandoned, or the session closes.
        Requires exactly one active
        [`stream_audio()`][pydantic_ai.realtime.RealtimeSession.stream_audio] iterator.
        """
        tap = self._single_audio_tap('`wait_for_playback()`', 'wait for playback from')
        while not self._closed and not tap.ended:
            # Clear before checking so that progress made between the check and the wait still wakes us.
            tap.progress.clear()
            playhead = tap.subscribed_at_bytes + tap.played_bytes + tap.dropped_bytes
            # Once the pump has finished, the only item left in the queue is the completion sentinel.
            buffer_empty = tap.queue.empty() or (self._pump_finished and tap.queue.qsize() == 1)
            if buffer_empty and playhead >= self._emitted_audio_bytes:
                return
            await tap.progress.wait()

    async def wait_for_reply(self) -> None:
        """Wait until the model has finished the reply it owes, if any.

        Returns once the exchange in progress reaches the boundary
        [`RealtimeTurnCompleteEvent`][pydantic_ai.realtime.RealtimeTurnCompleteEvent] marks — after a
        tool-calling turn, that is the answer that follows the tool results, not the response that
        called them. Returns immediately when the model owes nothing, so a reply that finished between
        the [`send()`][pydantic_ai.realtime.RealtimeSession.send] and this call is not waited for twice
        over; it also returns if the session closes, fails (a tool raised, or a usage limit tripped) so
        the reply can no longer come, or the provider refuses the request for the reply (reported as a
        [`RealtimeSessionErrorEvent`][pydantic_ai.realtime.RealtimeSessionErrorEvent]).

        This is the wait `async for event in session` would otherwise be written out to perform, and
        unlike that loop it can run while something else is iterating the session, so a caller that
        only wants the turn boundary does not have to take over the event stream to find it:

        ```python
        from pydantic_ai import Agent

        agent = Agent(instructions='You are a helpful voice assistant.')


        async def main():
            async with agent.realtime('openai:gpt-realtime').session() as session:
                await session.send('Say hello.')
                await session.wait_for_reply()
        ```

        The reply can show up in [`all_messages()`][pydantic_ai.realtime.RealtimeSession.all_messages] later than
        it ends (by up to 30 seconds), where history waits for the transcript of a spoken turn before it (see
        [History](../realtime/history.md#transcription-and-history-edge-cases)).

        Waiting for the model to stop *generating* is not the same as waiting for the speaker to stop
        *playing*: pair it with
        [`wait_for_playback()`][pydantic_ai.realtime.RealtimeSession.wait_for_playback] before opening
        the microphone, so the reply is not cut off and the model does not hear itself.
        """
        self._ensure_streamable()
        self._start_pump()
        # What the model owes at this moment, followed to the end: a reply asked for later is not waited for.
        owed = self._core.wait_tokens() if self._core is not None else None
        while True:
            # Cleared before the check, so a boundary reached between the check and the wait still
            # wakes us rather than leaving this parked until the turn after it.
            self._exchange_progress.clear()
            if owed is not None:
                if self._closed or self._pump_finished or not self._core_still_owes(owed):
                    return
            elif not self._reply_outstanding():
                return
            await self._exchange_progress.wait()

    def _core_still_owes(self, owed: frozenset[Owed]) -> bool:
        assert self._core is not None
        return bool(self._core.still_owed(owed))

    def _release_response_reservation(self) -> None:
        """Give back a reservation for a response that will never arrive, waking any waiter.

        Rolled back by every outbound call that reserved a response and then failed to send it. The
        decrement and the wake belong together: a caller parked in `wait_for_reply()` on that single
        reservation has nothing else coming to wake it.
        """
        self._pending_response_requests -= 1
        self._exchange_progress.set()

    def _reply_outstanding(self) -> bool:
        """Whether the model still owes speech.

        Derived rather than tracked, so no failure path can leave `wait_for_reply()` parked on a reply
        that can no longer arrive: once receiving has ended nothing more will be said, a reservation
        rolled back by a failed send stops counting, and several `respond=True` sends in flight are all
        waited for rather than just the first to reach its boundary.
        """
        if self._closed or self._pump_finished:
            return False
        return self._response_active or bool(self._pending_response_requests)

    def _release_exchange(self) -> None:
        self._response_active = False
        self._exchange_progress.set()

    def _single_audio_tap(self, method: str, purpose: str) -> _AudioTap:
        if len(self._audio_taps) != 1:
            raise UserError(
                f'{method} needs exactly one active `stream_audio()` iterator to {purpose}, '
                f'not {len(self._audio_taps)}; keep your own accounting instead.'
            )
        (tap,) = self._audio_taps
        return tap

    @property
    def played_audio_bytes(self) -> int:
        """The playback position of the session's single [`stream_audio()`][pydantic_ai.realtime.RealtimeSession.stream_audio] consumer, in raw PCM bytes.

        A chunk counts as played once the consumer comes back for the next one, so under the
        documented playback pattern — write each chunk to the device and wait until it is consumed
        before pulling the next — this is the position at the last chunk boundary the device
        reached, the same value a hand-rolled counter incremented after each write would report.
        The chunk being written is not counted until it is done, so barge-in attributes at most one
        chunk less than was really heard, never more. A consumer that instead buffers ahead reads
        too far; count actual device consumption yourself in that case. Made to be passed to
        [`interrupt(played_bytes=...)`][pydantic_ai.realtime.RealtimeSession.interrupt] on
        barge-in. Requires exactly one active `stream_audio()` iterator, like that call.
        """
        return self._single_audio_tap('`played_audio_bytes`', 'report the playback position of').played_bytes

    @overload
    def stream_transcripts(self, *, delta: Literal[False] = False) -> AsyncIterator[SpeechPart]: ...

    @overload
    def stream_transcripts(self, *, delta: Literal[True]) -> AsyncIterator[TranscriptUpdate]: ...

    def stream_transcripts(self, *, delta: bool = False) -> AsyncIterator[SpeechPart | TranscriptUpdate]:
        """Stream speech transcripts for both the user and assistant.

        By default, yields finalized [`SpeechPart`][pydantic_ai.messages.SpeechPart] instances — one
        per completed turn, carrying its `speaker` and full `transcript`. A model output item whose
        transcript grows after its part ended, possibly while a later item is still streaming, is
        yielded again each time it grows, with the transcript so far; `delta=True` carries the
        `index` to replace it by.

        Pass `delta=True` for live captions, which yields
        [`TranscriptUpdate`][pydantic_ai.realtime.TranscriptUpdate]s carrying the new text, the turn's
        full transcript so far, the speaker, and an `index` identifying the turn. Both speakers
        stream at once, so that `index` is what lets a UI keep two turns apart instead of running
        them together. Empty updates and finalized parts without a transcript are omitted.

        Final transcripts and deltas are separate subscriptions, so one never crowds out the other.
        The subscription starts when this method is called, so nothing said between the call and
        the consumer's first iteration is missed. Each iterator buffers up to 512 items; if its
        consumer falls behind (or never starts), the oldest is dropped, because captioning must not
        be able to stall tool execution, turn tracking, or the main event stream. Closing the
        session discards buffered items and ends the iterator cleanly; an unconsumed view otherwise
        keeps its bounded buffer until it is collected.
        If a tool fails while the event stream has no consumer, this view ends and the error is raised
        when the session closes.
        """
        self._ensure_streamable()
        # Each kind gets its own subscription, so a consumer's window is never spent on items it
        # would discard: sharing one queue let a burst of deltas evict the finalized part a
        # `delta=False` consumer was waiting for, and the two speakers' transcripts interleave.
        queue: asyncio.Queue[Any] = asyncio.Queue(maxsize=_TRANSCRIPT_TAP_SIZE + 1)
        taps: set[Any] = self._transcript_delta_taps if delta else self._transcript_taps
        taps.add(queue)
        if self._pump_finished:
            queue.put_nowait(self._tap_finished)
        else:
            self._start_pump()

        async def iterate() -> AsyncGenerator[SpeechPart | TranscriptUpdate, None]:
            try:
                while (item := await queue.get()) is not self._tap_finished:
                    yield item
            finally:
                taps.discard(queue)

        return _TapView(iterate(), taps, queue)

    def all_messages(self) -> list[ModelMessage]:
        """A snapshot of the seeded history plus messages recorded during this session.

        Returns a copy, so the result doesn't change as the session continues. Feed it into
        [`Agent.run(message_history=...)`][pydantic_ai.agent.AbstractAgent.run] to hand the
        conversation off to a standard agent run. Images streamed with `send()` are recorded according
        to `retain_images_every_n`, bounded by `retain_images_max`, and audio retained by
        `audio_retention` is bounded by `retain_audio_max_seconds`.
        """
        if self._core is not None:
            return self._core.all_messages()
        return [*self._seeded, *self._history]

    def _own_messages(self) -> list[ModelMessage]:
        """The history this session itself builds as it streams its events, which has a response by its tool calls.

        What a tool's `RunContext.messages` and a chat span's input show: the core's history (`all_messages()`)
        records a response only once it is over.
        """
        return [*self._seeded, *self._history]

    def new_messages(self) -> list[ModelMessage]:
        """A snapshot of the messages created during this session (excluding the seeded history)."""
        if self._core is not None:
            return self._core.new_messages()
        return list(self._history)

    @property
    def conversation(self) -> Conversation:
        """This session's [`Conversation`][pydantic_ai.conversation.Conversation], ready to hand to a text run.

        The same bundle [`AgentRunResult.conversation`][pydantic_ai.agent.AgentRunResult.conversation]
        produces, so a spoken conversation can be continued by
        [`Agent.run`][pydantic_ai.agent.AbstractAgent.run] and handed back again, carrying its usage
        rather than restarting the budget each time it changes modality.

        A session opened without a `conversation_id` resolves one here the way
        [`Agent.realtime`][pydantic_ai.agent.AbstractAgent.realtime] does up front — continuing the
        conversation its seeded history belongs to, or starting a new one — and keeps it, so every
        bundle taken from the session and every message it records shares one identity to store the
        conversation under.
        """
        if self._conversation_id is None:
            self._conversation_id = _agent_graph.resolve_conversation_id(None, self._seeded)
            # Messages this session recorded before the id existed were stamped with none. Stamp them
            # now, as they would have been had it been resolved up front, so the bundle agrees with
            # its own messages. The seeded history is the caller's, and is left as it was given.
            for message in self._history:
                message.conversation_id = message.conversation_id or self._conversation_id
            if self._core is not None:
                self._core.set_conversation_id(self._conversation_id)
            # The session span was opened before this id existed too, and has to agree for the
            # session to correlate with the text run that continues it.
            self._session_instrumentation.set_conversation_id(self._conversation_id)
        return Conversation(
            messages=self.all_messages(),
            usage=copy(self.usage),
            conversation_id=self._conversation_id,
        )

    def _new_request(self, parts: list[ModelRequestPart]) -> ModelRequest:
        """Create a request carrying the framework-managed session metadata."""
        request = ModelRequest(parts=parts)
        fill_run_metadata(request, run_id=self._run_id, conversation_id=self._conversation_id)
        return request

    async def send(
        self, content: RealtimeSessionInput | Sequence[RealtimeSessionInput], *, respond: bool | None = None
    ) -> None:
        """Feed content into the session.

        A `str` is a complete text turn that the model replies to. Do not follow `send('...')` with
        `create_response()`: that asks for two responses. An image is added as context without
        soliciting a response, while audio is streamed into the input buffer.

        Set `respond=False` to add text or an image as context without soliciting a response. Set
        `respond=True` to solicit a response to text or an image; this requires manual turn control
        for images. `respond=True` cannot be used with audio. For a sequence, an explicit `respond` value
        adds every item except the last as context and applies that value to the last item. With the
        default `respond=None`, each item keeps its usual behavior.

        Accepts the shared message vocabulary: plain text as a `str`, image/audio
        [`BinaryContent`][pydantic_ai.messages.BinaryContent] (including
        [`BinaryImage`][pydantic_ai.messages.BinaryImage] and
        [`BinaryAudio`][pydantic_ai.messages.BinaryAudio]), or a sequence of these inputs, dispatched
        in order. Text and retained images are recorded in session history; audio is recorded later
        through its transcript and/or `audio_retention`. `retain_images_every_n=1` records every image,
        while larger values keep the first image and then one of every `N`; `retain_images_max` bounds
        how many stay recorded, evicting the oldest first. Sending an image is gated on the model
        profile's image-input support and raises `UserError` when it is unsupported.

        `send()` accepts session content only. Turn-control verbs (`CommitAudio`, `ClearAudio`,
        `CreateResponse`, `CancelResponse`, `TruncateOutput`) are driven through the dedicated methods
        (`commit_audio()`, `clear_audio()`, `create_response()`, `interrupt()`), and
        [`ToolResult`][pydantic_ai.realtime.codec.ToolResult] is sent by the session itself as each tool
        completes (see `_execute_tool`) — neither is accepted here.
        """
        self._ensure_can_send()
        if isinstance(content, str):
            await self._send_text(content, respond=respond is not False)
        elif isinstance(content, BinaryContent):
            if content.is_image:
                await self._send_image(content, respond=respond is True)
            else:
                if respond is True and content.media_type in (_WAV_MEDIA_TYPE, 'audio/pcm'):
                    # Audio never solicits a reply on its own (VAD or `commit_audio()` ends the turn), so
                    # `respond=False` is a no-op for it and only `respond=True` is a mistake.
                    raise UserError(
                        '`respond=True` cannot be used with audio sent via `session.send()`: a spoken turn is '
                        'ended by voice activity detection, or by `commit_audio()` and `create_response()`.'
                    )
                await self._send_audio_content(content)
        elif isinstance(content, (bytes, bytearray)):
            # `bytes` is a `Sequence[int]`, so guard it before the sequence branch below — otherwise it
            # iterates into a confusing per-byte error. Raw input audio goes through `send_audio()`.
            raise UserError('Raw audio bytes cannot be sent via `session.send()`; use `session.send_audio(...)`.')
        elif isinstance(content, Sequence):
            if respond is None:
                for item in content:
                    await self.send(item)
            else:
                for index, item in enumerate(content):
                    await self.send(item, respond=respond if index == len(content) - 1 else False)
        else:
            assert_never(content)

    async def _send_text(self, content: str, *, respond: bool) -> ModelRequest:
        if respond:
            self._reserve_response_request()
        request = self._new_request([UserPromptPart(content=content)])
        self._record_sent_request(request)
        try:
            await self._send_frame(content if respond else TextContext(content), request=request)
        except BaseException:
            if respond:
                self._release_response_reservation()
            self._remove_sent_request(request)
            raise
        return request

    def enqueue(
        self,
        *content: EnqueueContent,
        priority: PendingMessagePriority = 'asap',
    ) -> str | None:
        """Enqueue content to be delivered to the model when the session is ready for it.

        Use this from code driving the session. For tools, use
        [`RunContext.enqueue`][pydantic_ai.tools.RunContext.enqueue]. Unlike
        [`send()`][pydantic_ai.realtime.RealtimeSession.send], which is delivered immediately even
        while the model is speaking, enqueued content waits for the appropriate turn boundary and
        triggers a model response when delivered.

        Args:
            *content: One or more [`EnqueueContent`][pydantic_ai.run.EnqueueContent] items. Realtime
                delivery supports text parts and
                [`SystemPromptPart`][pydantic_ai.messages.SystemPromptPart]s, which are joined into
                one user turn. System parts use the `<system>…</system>` convention to indicate that
                the text is not the person speaking; that marks where it came from, not that it should
                be handled silently. The model still gets a turn and decides whether to reply, call a
                tool, or move on. To add context without prompting a turn at all, use
                [`send(..., respond=False)`][pydantic_ai.realtime.RealtimeSession.send]. The delivered
                turn is recorded in history as a
                [`UserPromptPart`][pydantic_ai.messages.UserPromptPart]. Calling with no positional
                arguments is a no-op.
            priority: When to deliver:
                `'asap'` (default) — as soon as no reply is being generated; a reply already in
                    progress is allowed to finish first.
                `'when_idle'` — only once the model is idle: no response is in flight and all
                    `'asap'` items have been delivered.

        Returns:
            The `enqueue_id` of the queued message, or `None` when there was nothing to enqueue.

        Raises:
            UserError: If the session has not been entered or is closed, or the content cannot be
                delivered over the live input channel.
        """
        if not self._entered:
            raise UserError('Enter the realtime session with `async with` before enqueuing content.')
        self._ensure_can_send()
        pending = PendingMessage.from_content(*content, priority=priority)
        if pending is None:
            return None
        self._pending_messages.append(pending)
        return pending.enqueue_id

    async def _send_audio_content(self, content: BinaryContent) -> None:
        if content.media_type == _WAV_MEDIA_TYPE:
            # Retained `SpeechPart.audio` (from `audio_retention`) is a WAV container; unwrap it to
            # raw PCM — matching the seeding path — so a natural round-trip (retain a turn's audio,
            # then `send()` it back) doesn't stream the WAV header into the buffer as noise.
            await self.send_audio(
                seed_pcm_audio(
                    audio=content,
                    provider_name=self._provider_name or 'realtime',
                    sample_rate=self.audio_input_sample_rate,
                )
            )
        elif content.media_type == 'audio/pcm':
            await self.send_audio(content.data)
        else:
            raise UserError(
                f'Unsupported binary media type {content.media_type!r} for `session.send()`. '
                'Send an image, WAV audio, or raw PCM (`audio/pcm`); for a raw PCM byte stream use `send_audio()`.'
            )

    async def _send_image(self, content: BinaryContent, *, respond: bool) -> None:
        """Forward an image and retain it according to the session's sampling and cap policies."""
        self._require_capability('supports_image_input', method='send', feature='image input')
        if self._profile.get('image_input_requires_response', False):
            # The model takes an image only to respond to it (GPT-Live hands it to the backend that
            # runs on it), so asking for a response is the one way to send one, not manual turn-taking.
            if not respond:
                raise UserError(
                    'This realtime model only takes an image to respond to it, so `session.send()` needs '
                    '`respond=True` for an image; it cannot add one as context alone.'
                )
        elif respond:
            self._require_capability('supports_manual_turn_control', method='send', feature='manual turn-taking')
        if respond:
            self._reserve_response_request()
        request: ModelRequest | None = None
        if self._retain_images_max != 0 and self._sent_image_count % self._retain_images_every_n == 0:
            request = self._new_request([UserPromptPart(content=[content])])
            self._record_sent_request(request)
        try:
            # Callers guard on `is_image`, so the narrowed type only re-tags a plain `BinaryContent`.
            image = BinaryContent.narrow_type(content)
            assert isinstance(image, BinaryImage)
            if respond:
                await self._send_frame(image, CreateResponse(), request=request)
            else:
                await self._send_frame(image, request=request)
        except BaseException:
            if respond:
                self._release_response_reservation()
            # `None` when this image wasn't the one retained by the sampling policy: nothing recorded,
            # so nothing to take back.
            if request is not None:
                self._remove_sent_request(request)
            raise
        self._sent_image_count += 1
        # The provider can refuse the image while the send is still in progress, and the refusal then
        # took the request out of history before it got here: retaining it anyway would let a request
        # that isn't in history count against the cap and evict one that is.
        if request is not None and self._is_recorded(request):
            self._retained_image_requests.append(request)
            # `retain_images_every_n` only slows history growth; the cap bounds it, so a long-running
            # frame stream can't grow the host's memory without limit. Providers hold their own
            # (server-side) image context; this only trims the local record.
            while self._retain_images_max is not None and len(self._retained_image_requests) > self._retain_images_max:
                self._evict_image(self._retained_image_requests.pop(0))

    def _record_sent_request(self, request: ModelRequest) -> None:
        """Record a sent request without interleaving it with an in-flight assistant response."""
        if self._response_in_flight:
            self._pending_sent_requests.append(request)
        else:
            self._history.append(request)

    @property
    def _response_output_in_flight(self) -> bool:
        """Whether the model has begun producing a response that isn't recorded yet."""
        return self._active_assistant is not None or bool(self._response_parts or self._native_tool_parts)

    @property
    def _response_in_flight(self) -> bool:
        return bool(
            self._active_assistant is not None
            or self._response_parts
            or self._native_tool_parts
            or self._pending_provider_response_id is not None
            or self._pending_finish_reason is not None
            or self._pending_response_usage != RequestUsage()
            or self._session_instrumentation.chat_span is not None
        )

    def _is_recorded(self, request: ModelRequest) -> bool:
        """Whether a sent request is still in history or waiting to join it. Searched newest first."""
        return any(message is request for message in self._pending_sent_requests) or any(
            message is request for message in reversed(self._history)
        )

    def _evict_image(self, request: ModelRequest) -> None:
        """Drop the oldest retained image from history, to keep within `retain_images_max`."""
        self._remove_sent_request(request)
        evicted = [index for index, sent in self._input_requests.items() if sent is request]
        self._apply_core(InputWithdrawn(input_ids=tuple(evicted)))

    def _remove_sent_request(self, request: ModelRequest) -> None:
        """Remove a recorded request: a failed network send takes it back, the image cap evicts it."""
        for messages in (self._pending_sent_requests, self._history):
            for index, message in enumerate(messages):
                if message is request:
                    messages.pop(index)
                    if messages is self._history and index < self._audio_eviction_start:
                        self._audio_eviction_start -= 1
                    return

    async def send_audio(self, data: bytes | AsyncIterable[bytes]) -> None:
        """Stream mono PCM16 audio to the model: a single chunk, or an async iterable of chunks.

        Given an async iterable — a microphone stream, a WebSocket receive loop — each chunk is
        forwarded as it arrives and the call returns when the iterable is exhausted, so a whole
        capture loop can be one task: `asyncio.create_task(session.send_audio(microphone))`. If the
        session is closed while consuming that iterable, the call returns cleanly at the next chunk
        the source yields. Cancel the task in application code if the source can stall indefinitely.
        Passing a single chunk to a session that is already closed still raises
        [`UserError`][pydantic_ai.exceptions.UserError].

        Resample the audio to
        [`audio_input_sample_rate`][pydantic_ai.realtime.RealtimeSession.audio_input_sample_rate]
        first (24 kHz on the OpenAI-protocol providers, 16 kHz on Gemini):
        raw bytes carry no rate, so the wrong one is heard as a chipmunk rather than reported.

        With a [`reconnect`][pydantic_ai.realtime.RealtimeModelSettings.reconnect] policy, a chunk sent
        while a dropped connection is being re-dialed is discarded rather than raised, so a microphone
        task survives the reconnect. That includes a one-shot clip passed as a single chunk: resend it
        after the
        [`RealtimeSessionReconnectEvent`][pydantic_ai.realtime.RealtimeSessionReconnectEvent] if it matters.
        """
        self._require_media_ownership('send_audio')
        self._ensure_can_send()
        if isinstance(data, AsyncIterable):
            async for chunk in data:
                if self._closed:
                    return
                await self.send_audio(chunk)
            return
        user_turn_was_active = self._user_turn_active
        audio_was_uncommitted = self._audio_uncommitted
        self._held_commit.has_audio = True
        self._open_user_turn_for_audio()
        retained: bytes | None = None
        try:
            # Copied inside the try so a chunk that is not bytes-like (possible since `send_audio` accepts
            # an async iterable of chunks) fails before it goes out and rolls the user-turn state back
            # below, instead of leaving `_user_turn_active` set with nothing buffered or sent.
            if self._retain_input:
                retained = memoryview(data).tobytes()
            self._audio_uncommitted = True
            await self._send_frame(BinaryAudio(data=data, media_type='audio/pcm'))
        except BaseException as e:
            self._user_turn_active = user_turn_was_active
            self._audio_uncommitted = audio_was_uncommitted
            if (
                isinstance(e, RealtimeError)
                and isinstance(e.__cause__, self._connection.transport_errors)
                and self._connection._can_reconnect  # pyright: ignore[reportPrivateUsage]
                and not (self._pump_finished or self._receive_ending)
            ):
                # The link dropped and the connection's reconnect policy is replacing it, with receiving
                # still live to deliver it. A chunk of live audio is worthless once late, so it is dropped
                # rather than raised: the capture loop outlives the reconnect instead of dying on it. Once
                # the reconnect fails, the next chunk raises again.
                return
            raise
        if retained is not None:
            # Buffer the raw input so the finalized user turn can retain it, once it has gone out (with no
            # await since, so still in send order), as the session core takes it: a boundary the pump handled
            # while the chunk was on its way was drawn without it, and a chunk whose send failed belongs to
            # no turn. A per-item speech-stopped boundary later cuts this into that turn's own segment (see
            # `_segment_input_audio`); only the exact split at the boundary is approximate (see
            # `audio_retention`).
            self._input_audio.extend(retained)
            self._bound_retained_audio()

    def _open_user_turn_for_audio(self) -> None:
        """Audio is going out: it opens a user turn, if audio opens turns on this connection and none is open."""
        # Without input transcription, a provider that reports speech boundaries opens each turn itself,
        # at speech start. Audio alone is then no turn: an always-on microphone streams silence between
        # utterances, and taking it for one would record a phantom turn per response and one at close.
        audio_opens_turn = self._input_transcription_enabled or not self._provider_segments_input
        if audio_opens_turn and not self._anonymous_user_turn_awaiting_answer:
            if (turn := self._user_turns.get(None)) is not None and turn.speech_ended:
                for event in self._finalize_user():
                    self._publish_taps(event)
                    self._queue_put(event)
            if not self._user_turn_active:
                # Audio starting is the earliest sign of a user turn, and the only one on a provider that
                # reports no speech boundaries, so it's where the turn's place in history is reserved.
                self._open_user_turn_anchor()
            self._user_turn_active = True

    async def commit_audio(self) -> None:
        """Commit buffered input audio as a user turn (manual turn-taking / push-to-talk)."""
        self._ensure_can_send()
        self._require_media_ownership('commit_audio')
        self._require_capability('supports_manual_turn_control', method='commit_audio', feature='manual turn-taking')
        await self._send_frame(CommitAudio())
        if not self._audio_uncommitted:
            # The provider rejects an empty commit, so there is no user turn to record.
            return
        self._audio_uncommitted = False
        if (
            self._input_transcription_enabled
            and len(self._pending_anonymous_user_turn_anchors) <= self._anonymous_user_turns_ended
        ):
            # The audio was sent while the model was still answering the previous turn, so it reserved no
            # place in history; the committed turn belongs after that answer.
            self._open_user_turn_anchor()
        self._user_turn_active = True
        for event in self._finalize_untranscribed_user():
            self._queue_put(event)
        self._drop_audio_the_core_keeps()

    async def clear_audio(self) -> None:
        """Discard buffered, uncommitted input audio."""
        self._ensure_can_send()
        self._require_media_ownership('clear_audio')
        self._require_capability('supports_manual_turn_control', method='clear_audio', feature='manual turn-taking')
        await self._send_frame(ClearAudio())
        self._apply_core(AudioCleared())
        self._audio_uncommitted = False
        # Drop the locally retained copy too (with `audio_retention='input_audio'`/`'all'`), or the discarded
        # audio would still be attached to the next finalized user turn.
        self._input_audio.clear()
        self._user_turn_active = False

    async def create_response(self) -> None:
        """Ask the model to respond now (manual turn-taking, after `commit_audio`).

        If a response is already in flight, the request is held until it completes and is dropped if
        the user barges in. Returning does not mean the model has started speaking.
        """
        self._ensure_can_send()
        self._require_capability('supports_manual_turn_control', method='create_response', feature='manual turn-taking')
        self._reserve_response_request()
        try:
            await self._send_frame(CreateResponse())
        except BaseException:
            self._release_response_reservation()
            raise

    @overload
    async def interrupt(self, *, played_ms: int | None = None) -> None: ...

    @overload
    async def interrupt(self, *, played_bytes: int) -> bool: ...

    async def interrupt(self, *, played_ms: int | None = None, played_bytes: int | None = None) -> bool | None:
        """Barge-in: cancel the model's in-progress response, optionally truncating its audio first.

        This is server-side only — it stops generation and (when a playback position is given) syncs
        the provider's transcript to what was actually heard. Generation outruns playback, so the reply
        being heard has often finished generating: the provider's copy is still truncated, while the
        reply keeps its full transcript and `complete` state in history, which is append-only.

        With `played_ms`, the caller owns all playback accounting: flushing locally buffered
        playback is the caller's responsibility, and deciding whether to interrupt at all is too.

        With `played_bytes`, the session owns the rest: it attributes the position to the current
        turn (adjusting for audio the stream dropped or that predates the subscription), discards
        buffered audio the user will never hear — chunks already queued, and the cancelled
        response's stragglers as they arrive — then truncates and cancels, returning `True`. The
        cancel is left out while the provider has a speech segment open on a model whose own turn
        detection stops the response being spoken over, where a client cancel racing it can be
        applied to the *next* response; an interruption raised outside a speech segment always
        cancels. On a
        model without output truncation the unheard audio is still flushed and the response
        cancelled; only the provider-side transcript sync is unavailable. When everything emitted
        was already played there is nothing to cut off: a reply that has not reached its first audio
        chunk is cancelled untruncated, since it is about to speak over the user, and otherwise
        nothing is sent and `False` is returned — reporting an interruption anyway would make the
        provider discard part of a completed reply. This form needs exactly one
        [`stream_audio()`][pydantic_ai.realtime.RealtimeSession.stream_audio] iterator, kept for the
        session's lifetime; with several (or none) the position is ambiguous and a
        [`UserError`][pydantic_ai.exceptions.UserError] is raised — keep your own accounting and
        pass `played_ms` instead.

        Args:
            played_ms: Playback position in milliseconds from the start of the model's current audio
                output. When given, the model's output audio and its transcript are truncated to this
                point before the response is cancelled.
            played_bytes: Playback position as the total raw PCM bytes actually played from the
                session's single `stream_audio()` iterator. Mutually exclusive with `played_ms`.
        """
        self._ensure_can_send()
        self._require_capability('supports_interruption', method='interrupt', feature='interruption')
        if played_bytes is not None:
            if played_ms is not None:
                raise UserError('`interrupt()` accepts either `played_ms` or `played_bytes`, not both.')
            return await self._interrupt_at_playback(
                played_bytes, cancel=not self._server_cancelled_the_response_on_speech
            )
        if played_ms is not None and not self._profile.get('supports_output_truncation', False):
            raise UserError(
                'This realtime model does not support output truncation, so `interrupt(played_ms=...)` '
                'is unavailable. Call `interrupt()` without `played_ms` to cancel without truncating.'
            )
        # Truncate before cancelling: cancellation triggers `response.done`, which clears the tracked
        # output item, so a truncate sent afterwards could no-op. Both frames go out under one hold of
        # the send lock, so a tool result completing in between can't start a new response for the
        # cancel to hit instead. The client cancel is skipped while the provider's own turn detection
        # is already cancelling the response spoken over — the same rule as the `played_bytes` path
        # and `handle_barge_in=True` — so it can't land on the *next* response instead.
        frames: list[TruncateOutput | CancelResponse] = []
        if played_ms is not None:
            frames.append(TruncateOutput(audio_end_ms=played_ms))
        if not self._server_cancelled_the_response_on_speech:
            frames.append(CancelResponse())
        if frames:
            await self._send_frame(*frames)
        # Only a response still being generated records the position: a finished one keeps what history
        # recorded, and the position must not land on the next one instead.
        self._pending_interrupted_at_ms = played_ms if self._response_in_flight else None
        self._apply_core(Interrupted(played_ms=played_ms))
        # Mark the barge-in in the trace. When the caller supplied `played_ms` (the ms of output audio
        # actually played before truncating), record it so a reader can see how far the response got before
        # the user cut in; it's dropped when absent (a cancel without truncation).
        self._session_instrumentation.record_lifecycle('interrupt', played_ms=played_ms)

    async def _interrupt_at_playback(self, played_bytes: int, *, cancel: bool = True) -> bool:
        """Map a device playback position onto the current turn, flush unheard audio, and interrupt.

        `cancel=False` skips the client-side `CancelResponse` for a barge-in the provider's own VAD
        is already cancelling: see `_server_cancelled_the_response_on_speech`.
        """
        if played_bytes < 0:
            raise UserError(f'`played_bytes` must be a non-negative playback position, not {played_bytes}.')
        if len(self._audio_taps) != 1:
            raise UserError(
                '`interrupt(played_bytes=...)` needs exactly one active `stream_audio()` iterator to '
                f'attribute the playback position to, not {len(self._audio_taps)}; keep your own '
                'accounting and pass `played_ms` instead.'
            )
        (tap,) = self._audio_taps
        # The device consumed `played_bytes` of what this tap delivered; adding the gaps it has
        # already stepped over (overflow drops, earlier flushes) and what predates the subscription
        # places that position in the session's emitted-audio coordinates. (Flushed audio is erased
        # from the stream, so skipping over it is what keeps this mapping honest across barge-ins.)
        # Gaps still ahead of the consumer are deliberately excluded: see `pending_dropped_bytes`.
        playhead = tap.subscribed_at_bytes + played_bytes + tap.dropped_bytes
        if playhead >= self._emitted_audio_bytes:
            # Everything emitted has been heard, so there is nothing to cut off. A reply that has
            # opened a part but not reached its first audio chunk is still about to speak over the
            # user, though — barging in during the model's think time is ordinary — so cancel it
            # untruncated. Truncating is what would discard part of a reply the user did hear, and
            # once the part has audio the response may simply be over with its `ResponseDone` still
            # in flight, where a cancel can be applied to the *next* response instead.
            if cancel and self._active_assistant is not None and self._audio_part_index != self._active_assistant_index:
                # Audio generated before the provider processed the cancel still arrives for this
                # part, so erase it the same way the unheard-audio path does: the reply was stopped
                # before it spoke, and none of it should reach the playback stream now.
                self._interrupted_audio_part_index = self._active_assistant_index
                await self._send_frame(CancelResponse())
                self._session_instrumentation.record_lifecycle('interrupt', played_ms=None)
                return True
            return False
        # Unheard audio exists: flush what's buffered, and erase the cancelled part's stragglers as
        # they arrive, so the stream carries nothing the barge-in already cut off.
        self._flush_tap(tap)
        self._interrupted_audio_part_index = self._audio_part_index
        if not self._profile.get('supports_output_truncation', False):
            # Best effort on a model without output truncation (xAI): the unheard audio is still
            # flushed and the response cancelled; only the provider-side transcript sync is
            # unavailable.
            if cancel:
                await self._send_frame(CancelResponse())
            self._session_instrumentation.record_lifecycle('interrupt', played_ms=None)
            return True
        # A playhead still inside a previous turn's audio means none of the current turn was heard.
        played_ms = self._bytes_to_ms(playhead - self._turn_audio_start_bytes)
        # Truncate before cancelling, under one hold of the send lock, for the same reasons as above.
        await self._send_frame(*self._truncations_at(playhead), *([CancelResponse()] if cancel else []))
        # Only a response still being generated can record the position: history is append-only, so a
        # finished one keeps what it recorded, and the position must not land on the next one instead.
        self._pending_interrupted_at_ms = played_ms if self._response_in_flight else None
        self._apply_core(Interrupted(played_ms=played_ms))
        self._session_instrumentation.record_lifecycle('interrupt', played_ms=played_ms)
        return True

    def _bytes_to_ms(self, audio_bytes: int) -> int:
        """Milliseconds of output audio in `audio_bytes`; a negative span (a position before it) is 0."""
        return max(0, audio_bytes) * 1000 // (self.audio_output_sample_rate * 2)

    def _truncations_at(self, playhead: int) -> list[TruncateOutput]:
        """Truncate every output item the listener didn't finish hearing at an emitted-audio playhead.

        The item the playhead is inside is cut where playback stopped, and items generated after it,
        never heard, at 0 — even when their replies have finished generating, since generation outruns
        playback. An item the provider gave no id can only be truncated as its current item, the last.
        """
        items = list(self._audio_items)
        ends = [start for start, _ in items[1:]] + [self._emitted_audio_bytes]
        cuts = [
            (item_id, self._bytes_to_ms(playhead - start))
            for (start, item_id), end in zip(items, ends)
            if end > playhead
        ]
        truncations = [
            TruncateOutput(audio_end_ms=played_ms, item_id=item_id) for item_id, played_ms in cuts if item_id
        ]
        if cuts[-1][0] is None:
            truncations.append(TruncateOutput(audio_end_ms=cuts[-1][1]))
        return truncations

    def _flush_tap(self, tap: _AudioTap) -> None:
        """Discard the tap's buffered chunks, counting them as dropped for position mapping."""
        # Nothing queued survives the flush, so the next chunk delivered lands beyond every gap that
        # was still ahead of the consumer as well.
        tap.dropped_bytes += tap.pending_dropped_bytes
        tap.pending_dropped_bytes = 0
        while not tap.queue.empty():
            item = tap.queue.get_nowait()
            if item is self._tap_finished:
                # A barge-in that lands after the pump finished still has buffered audio to discard,
                # but the completion sentinel behind it has to stay so the consumer's iterator ends.
                tap.queue.put_nowait(item)
                break
            assert isinstance(item, bytes)
            tap.dropped_bytes += len(item)
        tap.buffered_bytes = 0
        # Every change to the playback accounting wakes `wait_for_playback()`, so it re-checks against
        # the flushed queue rather than waiting for audio that will never come.
        tap.progress.set()

    async def _auto_barge_in(self, event: RealtimeEvent) -> None:
        """The local half of barge-in, run by the session itself under `handle_barge_in=True`.

        Only acts while exactly one `stream_audio()` iterator is subscribed — the device-paced
        playback setup whose position the session tracks; any other topology keeps the manual
        `interrupt()` flow. Provider differences are absorbed here: a speech start on a truncating
        model gets the full flush-attribute-truncate-cancel treatment; without output truncation
        (xAI) unheard audio is flushed and the response cancelled untruncated; and a
        provider-initiated interruption (Gemini, which reports no speech start) leaves only the
        local flush to do.
        """
        if len(self._audio_taps) != 1:
            return
        (tap,) = self._audio_taps
        if isinstance(event, RealtimeInputSpeechStartEvent):
            if self._profile.get('supports_interruption', False):
                await self._interrupt_at_playback(
                    tap.played_bytes, cancel=not self._server_cancelled_the_response_on_speech
                )
        elif isinstance(event, RealtimeResponseInterruptedEvent):
            self._flush_tap(tap)
            self._interrupted_audio_part_index = self._audio_part_index

    async def _send_frame(
        self, *contents: RealtimeInput, request: ModelRequest | None = None, reply_asked: bool = True
    ) -> None:
        """Send inputs to the provider as one group, serialized against every other outbound frame.

        A single input can expand to several protocol frames (a `ToolResult` creates the conversation
        item and then asks for a response), so the lock is what makes each input indivisible on the
        wire, not just ordered. Passing several inputs extends that indivisibility across them, for
        the cases where an interleaved frame would change what they mean.

        `request` is the history entry recording the first input, taken back if the provider later
        reports that input's content as refused (see `_handle_input_rejected`). `reply_asked=False` says no
        reply will be asked for them, as for a result of a tool batch that will get none.
        """
        self._ensure_not_closed()
        self._start_pump()
        # Only the closed check is re-taken here, not `_ensure_can_send`: a frame already waiting on
        # the lock when a background failure ends receiving is one already underway, not the "next
        # outbound method" that contract speaks of, and it costs a single frame nobody reads on a
        # session that is ending anyway. Re-taking the full guard under the lock would also raise that
        # parked failure out of `_send_tool_result` and the teardown `CancelResponse`, neither of
        # which is a caller that asked to send.
        async with self._send_lock:
            first_input = self._inputs_sent
            try:
                for position, content in enumerate(contents):
                    # Numbered before the call, and whether or not it raises, matching how
                    # `InputRejected.input_index` counts. Registered before the frame goes out, since
                    # the pump can read the refusal while a later input of this group is still sending.
                    input_index = self._inputs_sent
                    self._inputs_sent += 1
                    if position == 0 and request is not None:
                        self._input_requests[input_index] = request
                    self._apply_core(
                        InputSent(
                            input_id=input_index,
                            request=request if position == 0 else None,
                            solicits=reply_asked and isinstance(content, (str, CreateResponse, ToolResult)),
                            tool_call_id=content.tool_call_id if isinstance(content, ToolResult) else None,
                        )
                    )
                    await self._connection.send(content)
                    if isinstance(content, BinaryAudio):
                        # Under the lock, so the core takes audio in the order it goes out; only once it has
                        # gone out, as a turn the provider ended while it was on its way (which the pump can
                        # record meanwhile) was ended without it, and a chunk whose send fails is in no turn.
                        self._apply_core(AudioSent(data=bytes(content.data)))
            except BaseException as e:
                # The caller takes back what it sent, so the core does too.
                self._apply_core(InputWithdrawn(input_ids=tuple(range(first_input, self._inputs_sent))))
                if not isinstance(e, self._connection.transport_errors):
                    raise
                # A send that fails because the link is gone is the same failure the receive side
                # reports; surface it as the same typed error rather than leaking a `websockets` or
                # provider-SDK exception from what looks like an ordinary method call.
                raise RealtimeError(
                    model_name=self._error_model_name,
                    message=f'Realtime connection failed while sending: {e}',
                ) from e

    @property
    def _error_model_name(self) -> str:
        """The model to attribute a provider failure to: the one asked for, else the one served."""
        return self._model_name or self._connection.model_name or 'unknown'

    def _ensure_not_closed(self) -> None:
        if self._closed:
            raise UserError('This realtime session is closed.')

    def _ensure_can_send(self) -> None:
        self._ensure_not_closed()
        if (self._pump_finished or self._receive_ending) and (error := self._first_undelivered_error()) is not None:
            self._raise_delivered(error)
        # Started here rather than in `__aenter__` so a session driven by `send()` alone still notices
        # a receive-side failure, without the pump publishing to taps that do not exist yet. Entering
        # eagerly discarded provider output produced before the caller's first `stream_audio()` or
        # `stream_transcripts()`, which is the order every docs example uses.
        self._start_pump()

    def _error_was_delivered(self, error: BaseException) -> bool:
        return any(delivered is error for delivered in self._delivered_errors)

    def _raise_delivered(self, error: BaseException) -> Never:
        """Raise an error its callers have already checked is undelivered, recording the delivery."""
        self._delivered_errors.append(error)
        raise error

    def _first_undelivered_error(self) -> BaseException | None:
        if self._pump_error is not None and not self._error_was_delivered(self._pump_error):
            return self._pump_error
        for error in self._parked_errors:
            if not isinstance(error, asyncio.CancelledError) and not self._error_was_delivered(error):
                return error
        return None

    def _park_error(self, error: BaseException) -> None:
        """Park a background failure for iteration or close, ending receive-only views if nobody is iterating."""
        self._parked_errors.append(error)
        self._queue_put(error)
        self._apply_core(ExchangeAbandoned())
        if not self._response_limit_checked or any(isinstance(part, ToolCallPart) for part in self._response_parts):
            # A tool that raised, or a usage limit tripped by the request its result would make, stops
            # the model from getting that result, so the exchange waiting on it is over: a caller in
            # `wait_for_reply()` is done waiting for it. Only that exchange: a reply already requested
            # for something else stays owed, and one already streaming ends its exchange itself.
            self._release_exchange()
        if not self._iterator_active and self._pump_task is not None:
            self._receive_ending = True
            self._pump_task.cancel()

    def _require_capability(self, capability: str, *, method: str, feature: str) -> None:
        """Raise a clear `UserError` before sending when the profile doesn't report `capability`."""
        if not self._profile.get(capability, False):
            raise UserError(f'This realtime model does not support {feature}, so `session.{method}()` is unavailable.')

    def _require_media_ownership(self, method: str) -> None:
        """Raise a clear `UserError` when an audio-transport method is used on a session that doesn't own media."""
        if not self._owns_media:
            raise UserError(
                f'This realtime session does not own the audio transport, so `session.{method}()` is unavailable. '
                'The browser exchanges audio with the provider directly over WebRTC; this sideband session only '
                'runs the control plane (instructions, tools, transcripts, history).'
            )

    # --- history assembly -------------------------------------------------------------------------

    def _ensure_active_assistant(self, *, output_text: bool = False, item_id: str | None = None) -> list[RealtimeEvent]:
        """Start an assistant output part if one isn't already in flight.

        `output_text` selects a plain [`TextPart`][pydantic_ai.messages.TextPart] (the model's
        `output_modalities=('text',)` responses) over the default
        [`SpeechPart`][pydantic_ai.messages.SpeechPart] (spoken audio and its transcript).
        """
        active = self._active_assistant
        events: list[RealtimeEvent] = []
        if active is not None:
            active_item_id = self._active_assistant_item_id
            item_changed = active_item_id is not None and item_id is not None and active_item_id != item_id
            modality_changed = output_text != isinstance(active, TextPart)
            if item_changed or modality_changed:
                events.extend(self._finalize_assistant_part())
                active = None
        if active is not None:
            if item_id is not None and self._active_assistant_item_id is None:
                self._active_assistant_item_id = item_id
            return events
        self._ensure_chat_span()
        # A new response is not the one the provider cancelled on speech onset, so interrupting it
        # is once again the client's job.
        self._server_cancelled_the_response_on_speech = False
        part: SpeechPart | TextPart = (
            TextPart(content='') if output_text else SpeechPart(speaker='assistant', transcript='')
        )
        self._active_assistant = part
        self._active_assistant_item_id = item_id
        self._active_assistant_index = self._take_part_index()
        self._assistant_transcript = ''
        events.append(PartStartEvent(index=self._active_assistant_index, part=part))
        return events

    def _take_part_index(self) -> int:
        """Claim the next session-unique index for a part about to start streaming."""
        index = self._next_part_index
        self._next_part_index += 1
        return index

    def _handle_native_part_event(self, event: PartStartEvent | PartEndEvent) -> list[RealtimeEvent]:
        """Forward a connection's native-tool part event under a session-unique index.

        Providers emit native tool activity (grounding, code execution) as ordinary part events,
        numbered from a counter of their own that knows nothing of the indexes the session has already
        handed out to the speech, text, and tool-call parts of the same turn. Since a repeated index
        *replaces* the part at it, forwarding those numbers verbatim would let a grounding part
        overwrite the model's answer for any consumer keyed on the index. Claim a session-unique index
        when the part starts and reuse it for the matching end. A started part is also buffered for the
        assistant response, which the session builds alongside the stream.
        """
        if isinstance(event, PartStartEvent):
            self._ensure_chat_span()
            self._native_tool_parts.append(event.part)
            index = self._native_part_indexes[event.index] = self._take_part_index()
        else:
            # An end with no recorded start closes nothing, so it gets an index of its own rather than
            # the connection's — which is not session-unique and could name a live part.
            index = self._native_part_indexes.pop(event.index, None)
            index = self._take_part_index() if index is None else index
        return [replace(event, index=index)]

    def _handle_assistant_transcript(
        self, text: str, *, output_text: bool = False, item_id: str | None = None
    ) -> list[RealtimeEvent]:
        # An id-less provider cannot associate transcripts with overlapping input items. Its first
        # output frame is therefore the boundary that closes the anonymous user turn before the reply.
        events = self._finalize_anonymous_user_before_output()
        if (late := self._late_assistant_transcript(text, output_text=output_text, item_id=item_id)) is not None:
            return [*events, *late]
        events.extend(self._ensure_active_assistant(output_text=output_text, item_id=item_id))
        active = self._active_assistant
        assert active is not None
        self._assistant_transcript, appended = accumulate_transcript(self._assistant_transcript, text)
        if isinstance(active, TextPart):
            self._active_assistant = replace(active, content=self._assistant_transcript)
            delta: SpeechPartDelta | TextPartDelta = TextPartDelta(content_delta=appended)
        else:
            self._active_assistant = replace(active, transcript=self._assistant_transcript)
            delta = SpeechPartDelta(
                speaker='assistant', transcript_delta=appended, transcript=self._assistant_transcript
            )
        if appended:
            events.append(PartDeltaEvent(index=self._active_assistant_index, delta=delta))
        return events

    def _late_assistant_transcript(
        self, text: str, *, output_text: bool, item_id: str | None
    ) -> list[RealtimeEvent] | None:
        """Fold a transcript into the part its item already ended, or `None` when the item has no ended part.

        A provider can finish an item after a later item's content arrived, so the item's transcript comes late.
        Text the stream already showed only updates the recorded part. New text streams the part again under the
        index it ended with, which a `PartStartEvent` replaces, so the item still streams as one part. The part
        under way keeps streaming around it, as the user's and the model's parts do.
        """
        if item_id is None or item_id == self._active_assistant_item_id:
            return None
        ended = self._ended_assistant_parts.get(item_id)
        if ended is None or output_text != isinstance(ended[1], TextPart):
            return None
        index, part = ended
        if isinstance(part, TextPart):
            updated, appended = fold_part_transcript(part, text)
            restarted: SpeechPart | TextPart = part
            delta: SpeechPartDelta | TextPartDelta = TextPartDelta(content_delta=appended)
        else:
            updated, appended = fold_part_transcript(part, text)
            # Retained audio appears at the part's end, not at its start.
            restarted = replace(part, audio=None)
            delta = SpeechPartDelta(speaker='assistant', transcript_delta=appended, transcript=updated.transcript or '')
        position = next(position for position, existing in enumerate(self._response_parts) if existing is part)
        self._response_parts[position] = updated
        self._ended_assistant_parts[item_id] = (index, updated)
        if not appended:
            return []
        return [
            PartStartEvent(index=index, part=restarted),
            PartDeltaEvent(index=index, delta=delta),
            PartEndEvent(index=index, part=updated),
        ]

    def _handle_assistant_audio(self, data: bytes, *, item_id: str | None = None) -> list[RealtimeEvent]:
        events = self._finalize_anonymous_user_before_output()
        events.extend(self._ensure_active_assistant(item_id=item_id))
        if self._retain_output:
            self._output_audio.extend(data)
            self._bound_retained_audio()
        events.append(
            PartDeltaEvent(
                index=self._active_assistant_index, delta=SpeechPartDelta(speaker='assistant', audio_chunk=data)
            )
        )
        return events

    def _finalize_assistant_part(self) -> list[RealtimeEvent]:
        """End the in-flight assistant part and append it to the current response."""
        if self._active_assistant is None:
            return []
        part = self._active_assistant
        if isinstance(part, SpeechPart):
            if part.transcript == '':
                part = replace(part, transcript=None)
            if self._retain_output and self._output_audio:
                part = replace(part, audio=self._retain_audio(bytes(self._output_audio), output=True))
        index = self._active_assistant_index
        if self._active_assistant_item_id is not None:
            self._ended_assistant_parts[self._active_assistant_item_id] = (index, part)
        self._active_assistant = None
        self._active_assistant_item_id = None
        self._assistant_transcript = ''
        self._output_audio.clear()
        self._response_parts.append(part)
        return [PartEndEvent(index=index, part=part)]

    def _count_recorded_response(self, response: ModelResponse) -> None:
        """Price a response this session records, and count it as a request unless usage reports them."""
        provider_reported_cost = response.usage.cost
        fill_response_cost(response)
        requests = int(self._responses_are_requests)
        self._requests_recorded += requests
        if self._core is not None:
            return  # The core counts it, into this same `RunUsage`.
        if provider_reported_cost is None:
            # Tokens were added as `SessionUsage` events arrived; only add the price calculated
            # at this response boundary. A provider-reported cost arrived in those events too.
            self.usage.incr(RequestUsage(cost=response.usage.cost))  # usage-attribution: the session owns its spans
        self.usage.requests += requests  # usage-attribution: the session owns its spans; `wrap_run` opens none

    def _finalize_response(
        self,
        *,
        provider_response_id: str | None = None,
        finish_reason: FinishReason | None = None,
        provider_details: dict[str, Any] | None = None,
        interrupted: bool = False,
        interrupted_at_ms: int | None = None,
        response_occurred: bool = False,
    ) -> None:
        """Finalize the current assistant response's parts into a `ModelResponse` in history."""
        response: ModelResponse | None = None
        # The chat span's input is the history the response replied to, captured before we append it.
        input_messages = self._own_messages()
        # Native tool parts (web grounding / code execution) lead the response (call+return, then
        # speech), matching the classic `GoogleModel`, which prepends them ahead of the assistant's text.
        parts = [*self._native_tool_parts, *self._response_parts]
        self._ended_assistant_parts.clear()
        if interrupted:
            for index in range(len(parts) - 1, -1, -1):
                if isinstance(part := parts[index], SpeechPart):
                    parts[index] = replace(part, interrupted_at_ms=interrupted_at_ms)
                    break
        # Parts prove a response happened. For an output-less response, only terminal/pending provider
        # metadata (or an interruption) does; a bare logical turn boundary must not invent a response.
        response_occurred = bool(
            response_occurred
            or parts
            or self._pending_provider_response_id is not None
            or self._pending_finish_reason is not None
            or self._pending_response_usage != RequestUsage()
            or self._session_instrumentation.chat_span is not None
        )
        reason = finish_reason or self._pending_finish_reason
        if (
            response_occurred
            and not parts
            and not interrupted
            and provider_details is None
            and reason in (None, 'stop')
            and not self._closed
        ):
            # A boundary that says nothing, in either sense: no output, and no provider detail or
            # abnormal finish reason explaining why. That isn't a response — it's one logical response
            # arriving in two frames. Vertex's `gemini-live-2.5-flash` closes the turn when the tool-call
            # generation ends and again when it has finished speaking, and the first boundary carries only
            # usage; recording it would make one tool round five messages there and four everywhere else.
            # Carry the metadata onto the response that does say something, so a tool round has one shape
            # on every provider. A response truncated by `length` (or any other abnormal reason) is real
            # information about what happened and stays, empty or not; so does anything left pending
            # when the session ends, which the flush in `__aexit__` records rather than lose.
            self._pending_provider_response_id = provider_response_id or self._pending_provider_response_id
            self._pending_finish_reason = reason
            self._session_instrumentation.end_chat_span(input_messages, None)
            self._response_parts = []
            self._native_tool_parts = []
            self._response_limit_checked = False
            return
        if response_occurred:
            response = ModelResponse(
                parts=parts,
                usage=self._pending_response_usage,
                # Prefer the model the server reported actually serving the session (it can differ
                # from the requested id — xAI silently substitutes its default for unknown slugs),
                # mirroring how request-response models stamp the response's reported model.
                model_name=self._connection.model_name or self._model_name,
                provider_name=self._provider_name,
                provider_url=self._provider_url,
                # Details reported with the response's usage (e.g. the model GPT-Live delegated to)
                # underlie those the terminal event reports for the response itself.
                provider_details={**(self._pending_provider_details or {}), **(provider_details or {})} or None,
                provider_response_id=provider_response_id
                or self._pending_provider_response_id
                or self._content_response_id,
                finish_reason=finish_reason or self._pending_finish_reason,
                conversation_id=self._conversation_id,
                state='interrupted' if interrupted else 'complete',
            )
            fill_run_metadata(response, run_id=self._run_id, conversation_id=self._conversation_id)
            self._count_recorded_response(response)
            self._history.append(response)
            self._resolve_in_flight_user_turn_anchors(response)
            if not any(isinstance(part, ToolCallPart) for part in parts):
                # The model has said what it had to say (a tool call means its answer is still to come),
                # so audio from here on can be the user's next turn again.
                self._anonymous_user_turn_awaiting_answer = False
            self._tool_run_step += 1
            self._close_tool_batch()
            for part in parts:
                if isinstance(part, ToolCallPart):
                    self._tool_calls_awaiting_usage.discard(part.tool_call_id)
            if self._pending_tool_returns:
                pending, self._pending_tool_returns = self._pending_tool_returns, []
                for call_part, request in pending:
                    self._insert_tool_return(call_part, request)
                if self._asap_drain_deferred:
                    self._asap_drain_ready = True
        if self._pending_sent_requests:
            self._history.extend(self._pending_sent_requests)
            self._pending_sent_requests = []
            self._stop_held_user_turn_watchdog()
        self._session_instrumentation.end_chat_span(input_messages, response)
        self._drop_audio_the_core_keeps()
        self._response_parts = []
        self._native_tool_parts = []
        self._pending_response_usage = RequestUsage()
        self._pending_provider_response_id = None
        self._content_response_id = None
        self._pending_finish_reason = None
        self._pending_provider_details = None
        self._response_limit_checked = False
        if response is not None:
            self._check_response_boundary_limits()

    def _release_held_user_turns(self) -> None:
        """Record the barge-in user turns still waiting on the response they interrupted, which never came."""
        self._held_user_turn_watchdog = None
        # Still waiting in `_pending_sent_requests`: the response that would have flushed them also ends the hold.
        for request in self._held_user_turns:
            self._remove_sent_request(request)
            self._history.append(request)
        self._held_user_turns = []
        self._drop_audio_the_core_keeps()

    def _stop_held_user_turn_watchdog(self) -> None:
        if self._held_user_turn_watchdog is not None:
            self._held_user_turn_watchdog.cancel()
            self._held_user_turn_watchdog = None
        self._held_user_turns = []

    def _place_held_commit(self) -> None:
        """Place the user turns of the commit the connection is sending now, after everything sent before it.

        That's where the provider has them. Turns that started after this commit belong to the next one.
        """
        held = self._sent_commit = self._held_commit
        self._held_commit = _HeldCommit()
        # Requests sent while a response is being produced go after it, and ahead of the commit going out now.
        held.anchor = self._pending_sent_requests[-1] if self._pending_sent_requests else self._position_here()
        held.sent = True
        if isinstance(held.anchor, _InFlightResponse):
            self._held_commits_in_flight.append(held)
        for request in held.requests:
            self._insert_user_request(held.anchor, request)
        held.requests.clear()

    def _resolve_in_flight_user_turn_anchors(self, response: ModelResponse) -> None:
        """Anchor the user turns that began while `response` was being produced to it, now that it's recorded."""
        for held in self._held_commits_in_flight:
            held.anchor = response
        self._held_commits_in_flight.clear()
        anchors = self._pending_anonymous_user_turn_anchors
        for index, anchor in enumerate(anchors):
            if isinstance(anchor, _InFlightResponse):
                anchors[index] = response
        for item_id, (anchor,) in self._pending_user_turn_anchors.items():
            if isinstance(anchor, _InFlightResponse):
                self._pending_user_turn_anchors[item_id] = (response,)
        for key, anchor in self._user_turn_anchors.items():
            if isinstance(anchor, _InFlightResponse):
                self._user_turn_anchors[key] = response

    def _check_response_boundary_limits(self) -> None:
        """Check the usage limits against a response that has just been finalized.

        A response settled by `close()` is the last thing the session will ever spend, but it is real
        spend: a caller who set a `cost_limit` and hung up mid-reply asked to be told it was passed, and
        the price of that reply is only known here. Skipping the check while closing let an over-budget
        teardown exit cleanly.
        """
        if not self._closed:
            self._check_usage_limits()
            return
        self._park_exceeded_limit(self._check_usage_limits)

    def _park_exceeded_limit(self, check: Callable[[], None]) -> None:
        """Run a usage limit check on a closed session, parking what it raises for `close()` to raise."""
        try:
            check()
        except UsageLimitExceeded as exceeded:
            # Parked rather than raised, so it reaches the caller through the same single delivery point
            # as every other receive-side failure — `close()` takes the first undelivered error, and the
            # caller's own exception still wins. Skipped once a limit has already been delivered: the
            # caller that saw it from iteration must not be told again when teardown re-checks the same
            # budget against the response it just settled.
            if not any(isinstance(delivered, UsageLimitExceeded) for delivered in self._delivered_errors):
                self._park_error(exceeded)

    def _check_final_request(self, usage: RequestUsage) -> None:
        """Check a request reported only as the session closed.

        Against `per_request_input_tokens_limit` and `request_limit`.
        """
        if self._usage_limits is not None:
            self._usage_limits.check_per_request_input_tokens(usage.input_tokens)
        self._check_reported_requests()

    def _check_reported_requests(self) -> None:
        """Check `request_limit` against the requests recorded, for a provider whose responses aren't requests.

        Its requests are only known once the model made them, so the one past the limit is recorded before it ends
        the session.
        """
        if (
            self._usage_limits is not None
            and (request_limit := self._usage_limits.request_limit) is not None
            and self.usage.requests > request_limit
        ):
            raise UsageLimitExceeded(
                f'Exceeded the request_limit of {request_limit} (`usage.requests`={self.usage.requests})'
            )

    def _ensure_chat_span(self) -> None:
        """Begin assembling a response and open its `chat {model}` span if not already open.

        See `SessionInstrumentation.ensure_chat_span` for the span's shape and lifetime.
        """
        self._begin_response()
        self._session_instrumentation.ensure_chat_span()

    def _handle_turn_complete(self, event: ResponseDone) -> list[RealtimeEvent]:
        # Turn boundary for a user turn that wasn't finalized earlier, so history reads user-then-assistant.
        # Gemini emits neither `RealtimeInputSpeechEndEvent` nor a final (`is_final`) input transcript — it streams
        # only partial transcripts — so its user turn is finalized here: `_finalize_user` for a
        # transcript-driven turn, `_finalize_untranscribed_user` otherwise. Both are no-ops
        # when the turn was already finalized (e.g. OpenAI's `is_final` transcript or `commit_audio`).
        events = self._finalize_user()
        events.extend(self._finalize_untranscribed_user())
        if self._retain_input and self._provider_segments_input and self._user_speech_started_at is None:
            # A speech-stopped boundary may be processed while the caller is still sending the tail of
            # its input schedule. That tail accumulates after `_segment_input_audio` clears the rolling
            # buffer and must not become the prefix of the next user turn. The completed response is a
            # safe point to discard it unless the user has already started speaking again (barge-in).
            # Only for a provider that draws speech boundaries at all: Gemini never emits
            # `RealtimeInputSpeechEndEvent`, so its buffer holds the *next* utterance, not a spent tail.
            self._input_audio.clear()
        events.extend(self._finalize_assistant_part())
        already_finalized = bool(
            self._response_finalized_before_terminal
            and not self._response_parts
            and not self._native_tool_parts
            and self._pending_provider_response_id is None
            and self._pending_finish_reason is None
            and self._pending_response_usage == RequestUsage()
        )
        if not already_finalized:
            self._begin_response()
        # Whether the model will speak again: it always responds to a tool's result, so a response that
        # called one, that left one still running, or whose content was already recorded (making this the
        # trailing terminal of a tool-call response, with the answer still to come) is never the last of
        # the exchange. `RealtimeTurnCompleteEvent` waits for the one that is.
        #
        # Not the `_response_finalized_before_terminal` flag itself: the OpenAI protocol *suppresses* a
        # function-call-only `response.done`, so the flag would still be set when the answer's terminal
        # arrives and would swallow the turn boundary for the whole exchange.
        more_expected = bool(
            self._pending_tool_calls
            or already_finalized
            # An interrupted response ends the exchange whatever the provider says is still in flight:
            # the user took the turn, and a boundary that never arrives would leave a caller waiting
            # on one forever. The same exemption defers-or-finalizes below.
            or (event.more_expected and not event.interrupted)
            or any(isinstance(part, ToolCallPart) for part in self._response_parts)
        )
        self._response_finalized_before_terminal = False
        if event.more_expected and not event.interrupted and event.provider_details is None:
            # The provider ended this response but said the exchange isn't over: a background-reasoning
            # model speaks a filler, closes the response, and only then calls the tool it was stalling
            # for. Hold the response open for that one tool call, so the utterance and the call it
            # belongs to land in one `ModelResponse` — the same shape a response whose usage arrives
            # mid-part gets. On Gemini the tool call's own finalization closes the pair, since its frame
            # carries no usage to wait for.
            #
            # Held for the tool call *only*: anything else that arrives first — more speech, a usage
            # report, a user transcript — settles the held response on its own (see
            # `_settle_deferred_response`), so two utterances stay two responses with their own usage,
            # request count, and `chat` span, and a user interjecting mid-stall is recorded after what
            # the model had already said rather than before it.
            #
            # An interrupted response is exempt: the user barged in, so that utterance really is over
            # and belongs in history as its own interrupted response. So is one carrying terminal
            # `provider_details`, which have no pending slot to wait in.
            self._pending_provider_response_id = event.provider_response_id or self._pending_provider_response_id
            self._deferred_response_finish_reason = event.finish_reason or 'stop'
            return events
        self._finalize_response(
            provider_response_id=event.provider_response_id,
            # An interrupted turn (barge-in) isn't an error and has no dedicated `FinishReason`; leave
            # it as the provider reported (usually unset) and let `state='interrupted'` carry the
            # meaning, matching a classic cancelled stream. A clean turn with no reported reason stops.
            finish_reason=event.finish_reason
            or (None if event.interrupted or event.provider_details is not None else 'stop'),
            provider_details=event.provider_details,
            interrupted=event.interrupted,
            interrupted_at_ms=self._pending_interrupted_at_ms,
            response_occurred=bool(
                not already_finalized
                and (
                    event.provider_response_id is not None
                    or event.finish_reason is not None
                    or event.provider_details is not None
                    or event.interrupted
                )
            ),
        )
        self._pending_interrupted_at_ms = None
        if not more_expected:
            events.append(RealtimeTurnCompleteEvent())
            self._release_exchange()
            # Only the exchange boundary is marked: each response is already a `chat` span, so a marker
            # per response would say nothing the trace doesn't show, while the turn boundary — where the
            # model is actually done — has no span of its own.
            # An interrupted boundary says so in its display text: on providers that auto-respond per
            # VAD segment (OpenAI server VAD), a talking user cancels response after response, and a
            # bare "model turn complete" per cancellation reads as turns that never happened.
            self._session_instrumentation.record_lifecycle(
                'model turn complete',
                message='model turn complete (interrupted)' if event.interrupted else None,
                interrupted=event.interrupted or None,
            )
        return events

    def _handle_tool_call_part(self, call_part: ToolCallPart, *, response_usage_follows: bool) -> list[RealtimeEvent]:
        """Fold a tool call into the current response, deferring finalization when its usage follows.

        OpenAI-protocol providers report each call before the `response.done` frame carrying that
        response's usage, so finalization waits for the ensuing `SessionUsage`. Gemini's tool-call
        frame has no per-response usage to wait for; it is finalized immediately with zero usage, while
        the later completed turn keeps the usage Gemini reports for that turn.
        """
        events = self._finalize_anonymous_user_before_output()
        self._ensure_chat_span()
        events.extend(self._finalize_assistant_part())
        index = self._take_part_index()
        events.append(PartStartEvent(index=index, part=call_part))
        events.append(PartEndEvent(index=index, part=call_part))
        self._response_parts.append(call_part)
        if response_usage_follows:
            self._tool_calls_awaiting_usage.add(call_part.tool_call_id)
        else:
            self._finalize_response()
        return events

    def _complete_tool_call(
        self,
        call_part: ToolCallPart,
        result_part: ToolReturnPart | RetryPromptPart,
        content: str | Sequence[UserContent] | None = None,
    ) -> list[RealtimeEvent]:
        request_parts: list[ModelRequestPart] = [result_part]
        if content:
            request_parts.append(UserPromptPart(content=content))
        request = self._new_request(request_parts)
        self._insert_tool_return(call_part, request)
        self._apply_core(ToolReturned(tool_call_id=call_part.tool_call_id, request=request))
        return [FunctionToolResultEvent(part=result_part, content=content)]

    def _insert_tool_return(self, call_part: ToolCallPart, request: ModelRequest) -> None:
        """Insert a tool-return request directly after the response carrying its call.

        A tool can finish after later turns, but request-response APIs demand call/return
        adjacency (OpenAI: a `tool` message must directly follow the assistant message with the call;
        Anthropic: the `tool_result` must open the next user message), so history keeps the canonical
        order even though the `FunctionToolResultEvent` streams in completion order.
        """
        for i in range(len(self._history) - 1, -1, -1):
            message = self._history[i]
            if isinstance(message, ModelResponse) and any(
                isinstance(part, ToolCallPart) and part.tool_call_id == call_part.tool_call_id for part in message.parts
            ):
                call_order = {
                    part.tool_call_id: index
                    for index, part in enumerate(message.parts)
                    if isinstance(part, ToolCallPart)
                }
                position = call_order[call_part.tool_call_id]
                insert_at = i + 1
                while insert_at < len(self._history) and (
                    existing_id := _tool_result_call_id(self._history[insert_at])
                ):
                    # Parallel calls settle in whatever order they finish, so skip past a sibling's
                    # result only while it belongs *before* this one in the response's call order.
                    if call_order.get(existing_id, position) > position:
                        break
                    insert_at += 1
                self._insert_into_history(insert_at, request)
                return
        if call_part.tool_call_id in self._tool_calls_awaiting_usage:
            # OpenAI-protocol tool execution starts before `response.done` supplies usage and finalizes
            # the calling response. Preserve the streamed completion now and insert it once that lands.
            self._pending_tool_returns.append((call_part, request))
        else:
            # The calling response is otherwise finalized before execution begins, so this is an
            # invariant fallback: keep the history complete rather than dropping the tool result.
            self._history.append(request)

    def _handle_input_transcript(
        self, text: str, is_final: bool, *, item_id: str | None = None, cumulative: bool = False
    ) -> list[RealtimeEvent]:
        if item_id is not None:
            # Once an item is closed (finalized or its transcription failed), ignore any stray later event
            # for it — re-creating it would duplicate the turn or resurrect a discarded failed one.
            if item_id in self._finalized_user_item_ids:
                return []
            events: list[RealtimeEvent] = []
            if item_id not in self._user_turns:
                self._user_turn_active = True
                part = SpeechPart(speaker='user', transcript='')
                self._claim_user_turn_anchor(item_id)
                turn = self._user_turns[item_id] = _UserTurn(part, '', self._take_part_index())
                events.append(PartStartEvent(index=turn.index, part=part))
            turn = self._user_turns[item_id]
            if not turn.start_emitted:
                events.append(PartStartEvent(index=turn.index, part=turn.part))
                turn.start_emitted = True
            transcript, delta = user_transcript_update(turn.transcript, text, cumulative=cumulative)
            turn.transcript = transcript
            turn.part = replace(turn.part, transcript=transcript)
            if delta is not None:
                events.append(PartDeltaEvent(index=turn.index, delta=delta))
            if is_final:
                events.extend(self._finalize_user(item_id=item_id))
            return events

        # Consecutive id-less finals can be separate turns with no speech frames between them, so the
        # transcript itself must consume the closed-turn marker rather than being discarded as a duplicate.
        self._anonymous_user_turn_finalized = False
        events: list[RealtimeEvent] = []
        if None not in self._user_turns:
            self._user_turn_active = True
            part = SpeechPart(speaker='user', transcript='')
            self._claim_user_turn_anchor(None)
            turn = self._user_turns[None] = _UserTurn(
                part, '', self._take_part_index(), speech_ended=self._anonymous_user_turns_ended > 0
            )
            if turn.speech_ended:
                self._anonymous_user_turns_ended -= 1
            events.append(PartStartEvent(index=turn.index, part=part))
        turn = self._user_turns[None]
        if not turn.start_emitted:
            events.append(PartStartEvent(index=turn.index, part=turn.part))
            turn.start_emitted = True
        turn.transcript, delta = user_transcript_update(turn.transcript, text, cumulative=cumulative)
        turn.part = replace(turn.part, transcript=turn.transcript)
        if delta is not None:
            events.append(PartDeltaEvent(index=turn.index, delta=delta))
        if is_final:
            events.extend(self._finalize_user())
        return events

    def _finalize_anonymous_user_before_output(self) -> list[RealtimeEvent]:
        """Close an id-less user turn when the model begins replying to it."""
        if not self._input_transcription_enabled:
            return []
        events = self._finalize_user()
        if (
            not events
            and not self._response_output_in_flight
            and len(self._pending_anonymous_user_turn_anchors) > self._anonymous_user_turns_ended
        ):
            # The transcript can lag behind the output that marks its boundary. Remember that the
            # anonymous turn is already over so the next audio segment can close it after it arrives.
            # Only the reply's first output marks that boundary: audio sent while the model answers
            # opens nothing that output could end.
            self._anonymous_user_turns_ended += 1
            self._user_turn_active = False
            self._anonymous_user_turn_awaiting_answer = True
        return events

    def _finalize_user(self, *, item_id: str | None = None) -> list[RealtimeEvent]:
        turn = self._user_turns.get(item_id)
        if turn is None or turn.finalized:
            return []
        part = turn.part
        index = turn.index
        if item_id is not None:
            self._finalized_user_item_ids.add(item_id)
        # Strip surrounding whitespace at finalization: providers whose transcripts arrive as a cumulative
        # or final snapshot (OpenAI/xAI) already reconcile leading-space drift via `_accumulate_transcript`,
        # but a partial-only stream (Gemini) concatenates deltas verbatim and would otherwise keep the
        # leading space its first delta carries. Stripping here aligns the two; it's a no-op when already
        # reconciled, and an all-whitespace (or empty) transcript collapses to `None` (an audio-only turn).
        part = replace(part, transcript=(part.transcript or '').strip() or None)
        if self._retain_input:
            # Prefer this item's own segment (cut at its speech-stopped boundary); it's the correct audio
            # even if a later turn's transcript already finalized. Fall back to the rolling buffer for
            # id-less providers, manual push-to-talk, and boundary-less turns, where it holds this turn's
            # audio — and only clear the shared rolling buffer on that fallback, never when a segment was
            # used (a following turn's audio may already be accumulating there).
            segment = self._input_segments.take(item_id) if item_id is not None else None
            if segment is None:
                segment = bytes(self._input_audio) if self._input_audio else None
                self._input_audio.clear()
            if segment:
                part = replace(part, audio=self._retain_audio(segment, output=False))
        if item_id is None:
            self._anonymous_user_turn_finalized = True
            self._anonymous_user_turn_awaiting_answer = True
            self._record_user_request(None, self._new_request([part]))
            self._user_turns.pop(None)
        else:
            turn.part = part
            turn.finalized = True
            earlier_turns = takewhile(lambda entry: entry[0] != item_id, self._user_turns.items())
            blocked_by_started_turn = any(
                (current.start_emitted or current.speech_ended) and not current.finalized
                for _, current in earlier_turns
            )
            if blocked_by_started_turn:
                self._flush_finalized_user_prefix()
            else:
                self._user_turns.pop(item_id)
                self._record_user_request(item_id, self._new_request([part]))
                self._flush_finalized_user_prefix()
        self._user_turn_active = (
            any(not current.finalized for current in self._user_turns.values())
            or len(self._pending_anonymous_user_turn_anchors) > self._anonymous_user_turns_ended
        )
        end = PartEndEvent(index=index, part=part)
        return [end] if turn.start_emitted else [PartStartEvent(index=index, part=part), end]

    def _open_user_turn_anchor(self, item_id: str | None = None) -> None:
        """Remember where a starting user turn belongs in history, before its transcript arrives.

        Input transcription is asynchronous, and its final event can land after the response the speech
        prompted has already been recorded — Azure and Gemini Live do that routinely, OpenAI and xAI under
        load. Appending on finalize would then file the user's words *after* the answer they caused, and
        after the tool call and return in between; replaying that history reads as the model calling a tool
        unprompted. So the turn's position is taken when it starts (audio begins flowing, or the provider
        reports speech started), and `_record_user_request` inserts there however late the transcript is.

        A turn that starts while the model is still answering (a barge-in) belongs after that answer, which
        isn't in history yet: it's anchored to the in-flight response, resolved once that is recorded.
        """
        anchor = self._user_turn_anchor_here()
        anchors = self._pending_anonymous_user_turn_anchors
        if item_id is None:
            # Audio or a speech-start frame unambiguously opens the next anonymous turn, so later
            # transcript and speech-end frames must no longer be treated as stragglers for the last one.
            self._anonymous_user_turn_finalized = False
            if len(anchors) > self._anonymous_user_turns_ended:
                # An anonymous turn is still open — local audio reserved its place already — so a
                # speech start now is the provider confirming that turn, not a new one: re-anchor it
                # rather than reserving a second place the next turn would then inherit.
                anchors[-1] = self._fresher_anchor(anchors[-1], anchor)
            else:
                anchors.append(anchor)
        else:
            if len(anchors) > self._anonymous_user_turns_ended:
                # The provider named the turn local audio opened: its speech start is the fresher position.
                anchor = self._fresher_anchor(anchors.pop(), anchor)
            self._pending_user_turn_anchors[item_id] = (anchor,)

    @staticmethod
    def _fresher_anchor(reserved: _UserTurnAnchor, here: _UserTurnAnchor) -> _UserTurnAnchor:
        """The place of a turn the provider confirms: where it is now, unless it belongs to a held commit.

        A held commit's turns go wherever the commit does, which a speech start the provider reports after
        the commit went out must not move to the next one.
        """
        return reserved if isinstance(reserved, _HeldCommit) else here

    def _user_turn_anchor_here(self) -> _UserTurnAnchor:
        """Where a user turn starting now belongs: with the held commit, after the response being produced, or else the last message."""
        if self._connection._defers_audio_commit:  # pyright: ignore[reportPrivateUsage]
            if self._held_commit.has_audio or self._sent_commit is None:
                return self._held_commit
            # No audio for the next commit yet, so a turn starting now is the provider reporting on audio
            # that already went out.
            return self._sent_commit
        return self._position_here()

    def _position_here(self) -> ModelMessage | _InFlightResponse | None:
        """After the response being produced, or else the last message."""
        if self._response_output_in_flight:
            return _IN_FLIGHT_RESPONSE
        return self._history[-1] if self._history else None

    def _claim_user_turn_anchor(self, item_id: str | None) -> None:
        """Attach the starting turn's remembered position to the item the transcript identified it as."""
        anchor: _UserTurnAnchor
        anchors = self._pending_anonymous_user_turn_anchors
        if item_id is not None and (pending_anchor := self._pending_user_turn_anchors.pop(item_id, None)):
            (anchor,) = pending_anchor
        elif anchors:
            # With no speech start to name it (push-to-talk reports none), an identified turn is the one
            # the audio sent for it opened.
            anchor = anchors.popleft()
            if item_id is not None and self._anonymous_user_turns_ended:
                self._anonymous_user_turns_ended -= 1
        else:
            # No anchor when the first thing we ever hear about the turn is its transcript (text-only
            # sessions seeded with audio, a provider that reports nothing before it, or audio sent while the
            # model was answering, which reserves no place); the turn starts here instead. On a connection
            # that holds commits, a transcript with no place reserved is for audio already committed.
            anchor = self._position_here()
        self._user_turn_anchors[item_id] = anchor

    def _record_user_request(self, item_id: str | None, request: ModelRequest) -> None:
        """Record a finalized user turn at the position it held when it started."""
        self._insert_user_request(self._user_turn_anchors.pop(item_id), request)

    def _insert_user_request(self, anchor: _UserTurnAnchor, request: ModelRequest) -> None:
        """Record a user turn after `anchor`."""
        if isinstance(anchor, _HeldCommit):
            if not anchor.sent:
                anchor.requests.append(request)
                return
            anchor = anchor.anchor
        pending = self._pending_sent_requests
        for index, message in enumerate(pending):
            if message is anchor:
                # Anchored to a request still waiting behind a response: the turn waits after it.
                index += 1
                while index < len(pending) and _is_user_speech_request(pending[index]):
                    index += 1
                pending.insert(index, request)
                return
        if isinstance(anchor, _InFlightResponse):
            # The response this turn began during is still being produced: the turn follows it, in the
            # same place as a request sent meanwhile, for as long as `_BARGE_IN_TURN_HOLD_SECONDS` allows.
            self._pending_sent_requests.append(request)
            self._held_user_turns.append(request)
            if self._held_user_turn_watchdog is None:
                self._held_user_turn_watchdog = asyncio.get_running_loop().call_later(
                    _BARGE_IN_TURN_HOLD_SECONDS, self._release_held_user_turns
                )
            return
        insert_at = 0
        if anchor is not None:
            for index in range(len(self._history) - 1, -1, -1):
                if self._history[index] is anchor:
                    insert_at = index + 1
                    break
            else:
                # The message a user turn anchored to can be withdrawn (a refused input taken back): keep
                # history complete rather than losing the turn.
                self._history.append(request)
                return
        # Step over what already sits in the anchor's slot: an earlier response's tool returns, which must
        # stay adjacent to their call, and user turns that started at the same point, which were spoken first.
        while insert_at < len(self._history) and (
            _is_tool_result_request(self._history[insert_at]) or _is_user_speech_request(self._history[insert_at])
        ):
            insert_at += 1
        self._insert_into_history(insert_at, request)

    def _insert_into_history(self, index: int, request: ModelRequest) -> None:
        self._history.insert(index, request)
        # A turn recorded where it started can carry retained audio, so the next eviction pass must see it.
        self._audio_eviction_start = min(self._audio_eviction_start, index)

    def _flush_finalized_user_prefix(self) -> None:
        """Record finalized user items in provider order, up to the first item still awaiting its final.

        Item-ID transcripts finalize in any order, but history must keep provider order (call/return
        adjacency etc.), so a finalized item waits in `_user_turns` until every earlier item has
        resolved (finalized or discarded).
        """
        while self._user_turns:
            finalized_id, turn = next(iter(self._user_turns.items()))
            if finalized_id is None or not turn.finalized:
                break
            self._user_turns.pop(finalized_id)
            self._record_user_request(finalized_id, self._new_request([turn.part]))

    def _retain_audio(self, pcm: bytes, *, output: bool) -> BinaryContent:
        """Wrap a turn's retained PCM audio for its `SpeechPart`, counting it against `retain_audio_max_seconds`."""
        sample_rate = self.audio_output_sample_rate if output else self.audio_input_sample_rate
        audio = BinaryContent(data=pcm_to_wav(pcm, sample_rate), media_type=_WAV_MEDIA_TYPE)
        return self._audio_budget.track(audio, len(pcm), output=output)

    def _bound_retained_audio(self) -> None:
        """Evict the oldest retained audio until what the session retains fits `retain_audio_max_seconds`.

        Everything retained counts: audio recorded in history, parts finalized but not recorded yet (in a
        response still in flight, say), segments waiting for their transcript, and the turns being spoken now.
        Audio recorded in history goes first, oldest first, each part keeping its transcript; then the waiting
        segments, oldest first; and only then the turns being spoken now, which keep their most recent audio.
        A part not recorded yet is only evicted once it is. Only the local copy is trimmed: the provider
        received all of it.
        """
        budget = self._audio_budget
        segments = self._input_segments
        excess = budget.excess(
            untracked_input=segments.byte_count + len(self._input_audio),
            untracked_output=len(self._output_audio),
        )
        if excess > 0 and budget.tracked_parts:
            # Resume where the last pass stopped, so each message is passed over about once however many
            # passes there are; a pass that finds nothing (the audio over budget is still on its way into
            # history) leaves it at the end.
            index = self._audio_eviction_start
            while index < len(self._history):
                stripped, freed = budget.strip(self._history[index], excess)
                if freed:
                    self._replace_recorded_message(index, stripped)
                    excess -= freed
                    if excess <= 0:
                        break
                index += 1
            self._audio_eviction_start = index
        while excess > 0 and (evicted := segments.evict_oldest()) is not None:
            excess -= budget.weight(evicted, output=False)
        excess = budget.trim(self._input_audio, excess, output=False)
        budget.trim(self._output_audio, excess, output=True)

    def _drop_audio_the_core_keeps(self) -> None:
        """Let go of the retained audio this session's own record holds, when the core keeps history.

        The core's history is the one `all_messages()` returns, with retained audio bounded by
        `retain_audio_max_seconds`; this session's own record (what tools see as `RunContext.messages`, and chat
        spans as their input) keeps only the transcripts, so the audio isn't held twice. The parts streamed as
        events, and the responses chat spans record, are built before this and keep their audio.
        """
        if self._core is None or not self._audio_budget.tracked_parts:
            return
        index = self._audio_eviction_start
        while index < len(self._history):
            stripped, freed = self._audio_budget.strip(self._history[index])
            if freed:
                self._replace_recorded_message(index, stripped)
            index += 1
        self._audio_eviction_start = index

    def _replace_recorded_message(self, index: int, message: ModelMessage) -> None:
        """Swap a message in history for an updated copy, carrying over the user-turn anchors that point at it.

        A copy, not an in-place edit, so a snapshot already returned by `all_messages()` doesn't change.
        """
        old = self._history[index]
        self._history[index] = message
        for item_id, anchor in self._user_turn_anchors.items():
            if anchor is old:
                self._user_turn_anchors[item_id] = message
        anonymous_anchors = self._pending_anonymous_user_turn_anchors
        for anchor_index, anchor in enumerate(anonymous_anchors):
            if anchor is old:
                anonymous_anchors[anchor_index] = message
        for item_id, (anchor,) in self._pending_user_turn_anchors.items():
            if anchor is old:
                self._pending_user_turn_anchors[item_id] = (message,)
        for held in (self._held_commit, self._sent_commit, *self._held_commits_in_flight):
            if held is not None and held.anchor is old:
                held.anchor = message

    def _segment_input_audio(self, item_id: str | None) -> None:
        """Cut the rolling input-audio buffer into `item_id`'s own segment at its speech-stopped boundary.

        Only applies with transcription enabled and input audio retained: the transcript arrives
        asynchronously (and possibly after a following turn's), so pinning the audio to the item now keeps
        it with the right user turn. `_InputSegments.cut` makes it idempotent if the provider repeats the boundary
        (or also emits a `committed` one): the first segment for an id wins.
        """
        if self._input_transcription_enabled and self._retain_input and item_id and self._input_audio:
            self._input_segments.cut(item_id, bytes(self._input_audio))
            self._input_audio.clear()

    def _finalize_failed_user_item(self, item_id: str | None) -> list[RealtimeEvent]:
        """Finalize a user item whose transcription failed without retaining unreliable partial text."""
        if item_id is None:
            # As with a transcript, an id-less failure can be the first event for the next turn.
            self._anonymous_user_turn_finalized = False
        else:
            # Same guard as `_handle_input_transcript`: once an item is closed, a stray duplicate or
            # late error event must not re-open it and record a second (blank) user turn.
            if item_id in self._finalized_user_item_ids:
                return []
        turn = self._user_turns.get(item_id)
        if turn is None:
            part = SpeechPart(speaker='user')
            turn = self._user_turns[item_id] = _UserTurn(part, '', self._take_part_index(), start_emitted=False)
            self._claim_user_turn_anchor(item_id)
        else:
            turn.part = replace(turn.part, transcript=None)
            turn.transcript = ''
        return self._finalize_user(item_id=item_id)

    def _flush_pending_users(self) -> None:
        """Preserve transcript-bearing user items that never received an explicit final event."""
        if None in self._user_turns:
            self._finalize_user()
        for item_id, turn in list(self._user_turns.items()):
            if item_id is not None and not turn.finalized:
                self._finalize_user(item_id=item_id)
        # Finalizing the last blocked item flushed the whole finalized prefix, so nothing remains.
        assert not self._user_turns, 'every pending user turn should have been recorded'
        self._user_turn_anchors.clear()
        self._pending_anonymous_user_turn_anchors.clear()
        self._anonymous_user_turns_ended = 0
        self._anonymous_user_turn_finalized = False
        self._anonymous_user_turn_awaiting_answer = False
        self._pending_user_turn_anchors.clear()
        # Drop any input-audio segments whose transcript never arrived, so they can't leak across a
        # long-lived session (finalized items already popped their own segment above).
        self._input_segments.clear()

    def _finalize_untranscribed_user(self) -> list[RealtimeEvent]:
        """Finalize a user turn when no transcript will arrive.

        This is called at each user-turn boundary when input transcription is disabled. It records retained
        input audio when available, or a content-less [`SpeechPart`][pydantic_ai.messages.SpeechPart]
        placeholder otherwise, so every turn remains represented in history.

        Gated on transcription being *off*: when it's on we wait for the transcript instead, so an
        (asynchronously delivered) transcript can never race this into a duplicate user turn. A no-op
        when there's an active transcript-driven user part, no user turn is active, or transcription is on.
        """
        if self._input_transcription_enabled:
            return []
        if None in self._user_turns or not self._user_turn_active:
            return []
        audio = self._retain_audio(bytes(self._input_audio), output=False) if self._input_audio else None
        part = SpeechPart(speaker='user', transcript=None, audio=audio)
        self._input_audio.clear()
        self._user_turn_active = False
        request = self._new_request([part])
        if self._connection._defers_audio_commit:  # pyright: ignore[reportPrivateUsage]
            # With the commit its audio went out with, or will.
            self._insert_user_request(self._user_turn_anchor_here(), request)
        else:
            self._history.append(request)
        # No deltas to stream (there's no transcript), so bracket the turn with just start/end so a
        # streaming consumer still sees the user turn boundary.
        index = self._take_part_index()
        return [PartStartEvent(index=index, part=part), PartEndEvent(index=index, part=part)]

    def _is_replayed_item(self, item_id: str | None, tool_call_id: str | None = None) -> bool:
        """Whether a provider-generic resumption replay already exists in local history.

        No built-in connection currently emits `ConversationItemCreated(replayed=True)`.
        """
        return (item_id is not None and item_id in self._replayed_item_ids) or (
            tool_call_id is not None and tool_call_id in self._replayed_tool_call_ids
        )

    def _accept_item(self, item_id: str | None, tool_call_id: str | None = None) -> bool:
        """Return `False` for an item that belongs to a provider's resumption replay burst."""
        return not self._is_replayed_item(item_id, tool_call_id)

    def _handle_reconnected(self, event: RealtimeSessionReconnectEvent) -> list[RealtimeEvent]:
        """Settle any in-flight state the reconnect did not actually carry, and report restoration honestly.

        A connection that resumes in-flight state (Gemini Live, which settles the cut turn in the
        connection itself) reports
        [`reconnect_restores_in_flight_state`][pydantic_ai.realtime.codec.RealtimeConnection.reconnect_restores_in_flight_state],
        so `state_restored=True` holds as reported and there is nothing more to settle. A connection we
        reconnect by replaying local history (OpenAI, Azure OpenAI, xAI) only restores *finalized* turns: the
        response and tool calls that were in flight when the socket dropped are gone, and the fresh
        server-side conversation knows nothing of them. Settle them here exactly as for a fully lost
        session — the partial reply as an interrupted response, running tool calls as cancelled returns —
        so the local history stays coherent and the turn ends (flushing anything queued behind it).
        Report `state_restored=False` whenever a response or tool call was actually in flight, so an app
        can branch on the flag the same way on every provider; a drop with nothing in flight loses
        nothing and stays `True`. Whether the settlement *emitted* events is not the test: an in-flight
        response carried only by pending provider metadata is finalized into history without any.
        """
        if event.state_restored and self._connection.reconnect_restores_in_flight_state:
            return [event]
        lost_in_flight = self._response_in_flight or bool(self._pending_tool_calls)
        events = self._finalize_lost_state()
        if lost_in_flight:
            event = replace(event, state_restored=False)
        if not event.state_restored:
            # The reconnect cut whatever was playing: the in-flight response (if any) is settled as
            # interrupted above, and even a finalized response's audio won't resume on the fresh
            # connection. End the `speak` span so it measures only what was actually audible, rather
            # than running until session close or being merged into the next utterance
            # (`start_playback_span` no-ops while a span is already open). No-op off a sideband.
            self._session_instrumentation.end_playback_span()
        return [*events, event]

    def _finalize_lost_state(self) -> list[RealtimeEvent]:
        """Settle everything still open into history: user turns, an in-flight response, running tools.

        Shared by the reconnect path (the provider lost this state) and `close()` (the session is
        ending with it still open). The partial reply is recorded as interrupted and every running
        tool call gets a cancelled return, so `all_messages()` stays a valid history for an
        `Agent.run(message_history=...)` handoff instead of dropping the tail of the conversation or
        ending on a dangling `ToolCallPart`.
        """
        # The response the provider was cancelling on speech onset is one of the things being
        # settled here, so interrupting whatever comes next is the client's job again.
        self._server_cancelled_the_response_on_speech = False
        # Whatever the model still owed is being settled here rather than spoken, on both the reconnect
        # and the close path, so a `wait_for_reply()` waiting on it is waiting on nothing.
        self._release_exchange()
        # A response held for a tool call was spoken in full, so it is recorded as the complete response
        # it was, ahead of anything below that really was cut short.
        self._settle_deferred_response()
        events = self._finalize_user()
        for item_id, turn in list(self._user_turns.items()):
            if item_id is not None and not turn.finalized:
                events.extend(self._finalize_user(item_id=item_id))
        self._flush_pending_users()
        events.extend(self._finalize_untranscribed_user())
        if self._held_commit.requests:
            # Turns whose commit never went out are recorded as they stand.
            self._place_held_commit()
        self._input_audio.clear()
        # The audio sent so far was just settled as a turn (and a reconnected provider has no buffer holding
        # it), so a `commit_audio()` from here on commits nothing until more audio is sent.
        self._audio_uncommitted = False

        # Tool batches go with the conversation the provider lost: the running calls are cancelled below,
        # and no reply is counted for results it may never have received, even from a tool that swallows
        # its cancellation and returns anyway. Marked before the in-flight response is settled, which
        # would otherwise close its batch and count one.
        for batch in {*self._tool_call_batches.values(), *self._closed_tool_batches}:
            batch.abandoned = True
            # No call can join it any more, so it retires once its running calls are cancelled below.
            batch.closed = True
        self._closed_tool_batches.clear()
        self._open_tool_batch = None
        if self._response_in_flight:
            events.extend(self._finalize_assistant_part())
            self._finalize_response(interrupted=True)
        for tool_call_id, (task, call_part) in list(self._pending_tool_calls.items()):
            self._pending_tool_calls.pop(tool_call_id, None)
            task.cancel()
            cancelled_part = ToolReturnPart(
                tool_name=call_part.tool_name,
                content=INTERRUPTED_TOOL_RETURN_CONTENT,
                tool_call_id=call_part.tool_call_id,
                outcome='interrupted',
            )
            events.extend(self._complete_tool_call(call_part, cancelled_part))
        return events

    def _handle_control_event(
        self,
        event: (
            RealtimeInputSpeechStartEvent
            | RealtimeSessionReconnectEvent
            | RealtimeOutputSpeechStartEvent
            | RealtimeOutputSpeechEndEvent
        ),
    ) -> list[RealtimeEvent]:
        if isinstance(event, RealtimeSessionReconnectEvent):
            return self._handle_reconnected(event)
        # The playback boundary brackets the `speak` span and is otherwise passed straight through.
        if isinstance(event, RealtimeOutputSpeechStartEvent):
            self._session_instrumentation.start_playback_span()
            return [event]
        if isinstance(event, RealtimeOutputSpeechEndEvent):
            self._session_instrumentation.end_playback_span()
            return [event]
        # A reported speech start is a turn boundary even mid-stream, so it re-anchors: with a continuously
        # open microphone the previous turn may not have finalized yet, leaving `_user_turn_active` set.
        self._open_user_turn_anchor(event.item_id)
        self._user_turn_active = True
        self._user_speech_started_at = time_ns()
        # Whatever response was in flight, the provider's own turn detection is cancelling it now.
        self._server_cancelled_the_response_on_speech = self._connection.interrupts_response_on_speech
        return [event]

    def _handle_input_rejected(self, event: InputRejected) -> None:
        """Take back what a send assumed, now that the provider refused it: the same rollback a failed send gets."""
        if event.refused == 'response':
            # Reservations are a count, not tied to a particular response, so the one to release is
            # whichever is still pending. None is when a response the provider started on its own
            # (server VAD) already took it: that response is then what the caller is waiting for.
            if self._pending_response_requests:
                self._release_response_reservation()
        elif (request := self._input_requests.pop(event.input_index, None)) is not None:
            self._remove_sent_request(request)
            self._retained_image_requests = [kept for kept in self._retained_image_requests if kept is not request]

    def _handle_conversation_item(self, event: ConversationItemCreated) -> None:
        """Remember IDs assigned to a provider's replay burst so related events are suppressed."""
        if event.replayed:
            if event.item_id is not None:
                self._replayed_item_ids.add(event.item_id)
            if event.tool_call_id is not None:
                self._replayed_tool_call_ids.add(event.tool_call_id)

    def _handle_input_speech_end(self, event: RealtimeInputSpeechEndEvent) -> list[RealtimeEvent]:
        """Segment input audio and preserve a placeholder while transcription is pending."""
        self._provider_segments_input = True
        self._segment_input_audio(event.item_id)
        self._record_user_speech_span()
        events = self._finalize_untranscribed_user()
        if self._input_transcription_enabled:
            if event.item_id is None and self._anonymous_user_turn_finalized:
                # The transcript already closed this anonymous turn. This speech-end frame is its
                # boundary, not a new content-less turn; the next turn will clear the marker itself.
                return [*events, event]
            if event.item_id is not None and event.item_id in self._finalized_user_item_ids:
                return [*events, event]
            if event.item_id not in self._user_turns:
                self._claim_user_turn_anchor(event.item_id)
                part = SpeechPart(speaker='user', transcript='')
                self._user_turns[event.item_id] = _UserTurn(
                    part, '', self._take_part_index(), speech_ended=True, start_emitted=False
                )
            else:
                self._user_turns[event.item_id].speech_ended = True
        return [*events, event]

    def _translate_event(self, event: _TranslatableEvent) -> list[RealtimeEvent]:
        """Translate a low-level codec event into shared session events, building history as a side effect.

        Tool calls and usage are handled in `_handle_pump_event` (they interact with the queue and
        tool execution); everything else routes through here. `event` is typed as `_TranslatableEvent`
        (the pump-consumed variants narrowed out) so the final `assert_never` gives static exhaustiveness.
        """
        if isinstance(event, AudioDelta):
            if not self._accept_item(event.item_id):
                return []
            self._content_response_id = event.response_id or self._content_response_id
            self._session_instrumentation.set_output_type('speech')
            return self._handle_assistant_audio(event.data, item_id=event.item_id)
        if isinstance(event, OutputTranscript):
            if not self._accept_item(event.item_id):
                return []
            self._content_response_id = event.response_id or self._content_response_id
            self._session_instrumentation.set_output_type('text' if event.output_text else 'speech')
            # `is_final` doesn't end the part — the turn ends on `ResponseDone`; a final transcript just
            # carries the full text, which `_accumulate_transcript` reconciles against the deltas. Plain
            # text output (`output_text`) becomes a `TextPart`, an audio transcript a `SpeechPart`.
            return self._handle_assistant_transcript(event.text, output_text=event.output_text, item_id=event.item_id)
        if isinstance(event, InputTranscript):
            if not self._accept_item(event.item_id):
                return []
            return self._handle_input_transcript(
                event.text, event.is_final, item_id=event.item_id, cumulative=event.cumulative
            )
        if isinstance(event, RealtimeInputSpeechEndEvent):
            # The user's speech segment ended (server VAD). With transcription enabled and input audio
            # retained, cut the rolling buffer into this item's own segment so a later out-of-order
            # transcript still attaches its own audio; with transcription off there's no lagging transcript,
            # so `_finalize_untranscribed_user` consumes the rolling buffer synchronously here instead.
            return self._handle_input_speech_end(event)
        if isinstance(event, ResponseDone):
            return self._handle_turn_complete(event)
        if isinstance(event, (PartStartEvent, PartEndEvent)):
            return self._handle_native_part_event(event)
        if isinstance(event, RealtimeResponseInterruptedEvent):
            return [event]
        if isinstance(event, RealtimeInputTranscriptionErrorEvent):
            return [*self._finalize_failed_user_item(event.item_id), event]
        # The remaining control-plane events pass through unchanged. `assert_never` makes pyright flag
        # any new non-pump `RealtimeEvent` variant that isn't handled here.
        if isinstance(
            event,
            (
                RealtimeInputSpeechStartEvent,
                RealtimeSessionReconnectEvent,
                RealtimeOutputSpeechStartEvent,
                RealtimeOutputSpeechEndEvent,
            ),
        ):
            return self._handle_control_event(event)
        if isinstance(event, RealtimeSessionErrorEvent):
            if event.recoverable:
                # A recoverable error is mid-stream: the session keeps running, so surface the event to
                # the consumer (rather than swallowing it) for observability. Only a non-recoverable
                # error ends the session, by raising.
                return [event]
            raise RealtimeError(model_name=self._error_model_name, message=event.message)
        assert_never(event)

    # --- instrumentation --------------------------------------------------------------------------

    def _final_result_text(self) -> str | None:
        """The most recent assistant reply's text, for the session span's `final_result`.

        Concatenates the text/transcript of the last `ModelResponse` that carries any, so a response
        that only made a tool call falls through to the spoken reply that followed it.
        """
        for message in reversed(self.all_messages()):
            if isinstance(message, ModelResponse) and (text := message.text):
                return text
        return None

    async def _announce_deferred_requests(self, requests: DeferredToolRequests) -> None:
        """Surface a deferred call before a handler is asked to resolve it, as a run does.

        So a consumer can relay the request — e.g. to a person a handler is awaiting — while it's pending.
        """
        self._queue_put(DeferredToolRequestsEvent(requests))

    async def _execute_tool(
        self,
        call_part: ToolCallPart,
        *,
        validation_done: asyncio.Event,
        execution_prerequisites: tuple[asyncio.Event, ...],
        response_usage_follows: bool,
        run_step: int,
        reserved_budget: bool,
    ) -> _SettledToolResult:
        # No `execute_tool` span is created here: the `execute_tool` span is owned by the
        # `Instrumentation` capability's `wrap_tool_execute` hook, which `Agent.realtime`
        # injects into the tool runner's `ToolManager` (mirroring a classic run). That capability
        # span is the single, canonical source of tool spans; the pump task runs inside the session
        # span's OTel context, so the capability's tool span nests under the session span as a sibling
        # of the `chat` spans. The session-level `realtime` span and per-response `chat` spans below
        # stay hand-managed for now — they move onto exchange-level capability hooks when those land.
        async def on_validate(args_valid: bool) -> None:
            self._queue_put(FunctionToolCallEvent(part=call_part, args_valid=args_valid))
            validation_done.set()
            for prerequisite in execution_prerequisites:
                await prerequisite.wait()

        async def on_inline_deferred(requests: DeferredToolRequests, results: DeferredToolResults) -> None:
            self._queue_put(DeferredToolResultsEvent(results))

        try:
            async with self._tool_manager_lock:
                ctx = self._tool_manager.ctx
                if ctx is not None:  # pragma: no branch
                    # `RunContext.messages` is a live view of the conversation in a classic run, because
                    # the graph builds each tool's context from the history so far. A session's context is
                    # built once at connect, so without this a tool would always see the seed (usually
                    # nothing) no matter how long the call has been going. Update in place, so contexts
                    # already handed out — `replace()` below keeps the same list object — see the update
                    # too.
                    ctx.messages[:] = self._own_messages()
                    # A run step here is one model turn: `_tool_run_step` increments when a
                    # `ModelResponse` is finalized, so this re-prepares the *local* manager once per
                    # turn — refreshing prepare hooks, availability filters, and retry state exactly
                    # as the graph does per model request. It never re-advertises tools mid-call: the
                    # tool list the provider sees is fixed at connect (`session.update` is sent
                    # once), so a prepare filter changing here only affects whether a call the model
                    # makes is accepted or settled as unknown-tool.
                    if ctx.run_step < run_step:
                        self._tool_manager = await self._tool_manager.for_run_step(replace(ctx, run_step=run_step))
                # Pin the step-synchronized manager for this call: a concurrent tool task can swap
                # `self._tool_manager` (its own `for_run_step` advance) between here and the calls below,
                # so re-reading the attribute there could run against a different run-step's manager.
                tool_manager = self._tool_manager

            tool_result = await tool_manager.handle_call(
                call_part,
                on_validate=on_validate,
                on_deferred_requests=self._announce_deferred_requests,
                on_inline_deferred=on_inline_deferred,
            )
        except ToolRetryError as e:
            result_part = e.tool_retry
            user_content = None
        except ToolFailedError as e:
            # A tool that raised `ToolFailed` yields a `failed` result rather than a retry. Send it
            # back so the model sees the failure — error-key-wrapped below (via
            # `model_response_str_and_user_content`) for the string-only tool channel, since realtime
            # providers have no native failed-tool flag.
            result_part = e.tool_failed
            user_content = None
        except (ApprovalRequired, CallDeferred, RunCancelled) as e:
            result_part = _unsettled_call_return(call_part, e)
            user_content = None
        else:
            result_part, user_content = _build_session_tool_return(tool_result, call_part, tool_manager)
        finally:
            # The call has settled: on success `handle_call` has already recorded it on
            # `usage.tool_calls` in this same event-loop segment (so no limit check can observe the
            # reservation and the recorded call at once), and on failure or cancellation there is
            # nothing to count. Released only if it was claimed — a declaratively deferred call takes
            # no reservation, so decrementing here would drive the counter negative and under-project
            # every concurrent call.
            self._tool_calls_in_flight -= int(reserved_budget)

        if isinstance(result_part, RetryPromptPart):
            output = result_part.model_response()
            wire_content: list[UserContent] = []
        else:
            output, wire_content = result_part.model_response_str_and_user_content()
        if isinstance(user_content, str):
            wire_content.append(user_content)
        elif user_content:
            wire_content.extend(user_content)
        if self._closed:
            # The session closed while the tool ran: it hung up with `close()` and then swallowed the
            # `CancelledError`. Its call already has an interrupted return in history and there is no
            # provider left to send to, so the result goes nowhere (`_run_tool` drops it too).
            return result_part, user_content
        if not response_usage_follows:
            await self._drain_pending_messages('asap')
        await self._send_tool_result(call_part, output, wire_content)
        return result_part, user_content

    async def _send_tool_result(self, call_part: ToolCallPart, output: str, wire_content: list[UserContent]) -> None:
        result = ToolResult(tool_call_id=call_part.tool_call_id, output=output, content=wire_content or None)
        if (batch := self._tool_call_batches.get(call_part.tool_call_id)) is None:
            # A connection that answers each result (or a call dispatched outside the pump): the result is
            # a reply of its own, as it always has been.
            self._reserve_response_request()
            try:
                await self._send_frame(result)
            except BaseException:
                self._release_response_reservation()
                raise
            return
        batch.running.discard(call_part.tool_call_id)
        if batch.reply_due:
            # The last result: counted before it goes out, since a provider may answer on its arrival.
            self._count_tool_batch_reply(batch)
        elif not batch.abandoned:
            # Not known to be the last, so nothing is counted yet, but the reply it may complete is
            # checked against `request_limit` before the result goes out: once out, the connection asks
            # for that reply as soon as the calling response is done, before the session can refuse it.
            self._check_request_limit()
        batch.sending += 1
        try:
            await self._send_frame(result, reply_asked=not batch.abandoned)
        except BaseException:
            # A provider missing one of the batch's results won't answer it.
            batch.abandoned = True
            if batch.counted:
                batch.counted = False
                self._release_response_reservation()
            raise
        finally:
            batch.sending -= 1
            self._retire_tool_batch_if_settled(batch)

    def _count_tool_batch_reply(self, batch: _ToolBatch) -> None:
        batch.counted = True
        self._reserve_response_request()

    def _retire_tool_batch_if_settled(self, batch: _ToolBatch) -> None:
        """Forget a batch whose calls can no longer run or send, so nothing else can reach it."""
        if batch.settled:
            for call_id in batch.calls:
                self._tool_call_batches.pop(call_id, None)

    def _close_tool_batch(self) -> None:
        """Close the batch of the response just finalized: its calls are all in, so its reply may be due."""
        if (batch := self._open_tool_batch) is None:
            return
        self._open_tool_batch = None
        batch.closed = True
        self._closed_tool_batches.append(batch)

    def _count_closed_tool_batch_replies(self) -> None:
        """Count the reply of closed batches whose results all went out before they closed.

        Run by the pump once the event that closed them is fully handled: after that event's usage-limit
        checks, so a response over its limit doesn't count the next one.
        """
        while self._closed_tool_batches:
            batch = self._closed_tool_batches.pop(0)
            self._retire_tool_batch_if_settled(batch)
            if batch.reply_due:
                self._count_tool_batch_reply(batch)

    # --- streaming --------------------------------------------------------------------------------

    def _notify_pending_messages(self, priority: PendingMessagePriority) -> None:
        """Wake a pending-message drain from either an async tool or a sync-tool worker thread."""
        loop = self._loop
        if loop is not None and not self._closed:
            try:
                loop.call_soon_threadsafe(self._start_pending_message_drain, priority)
            except RuntimeError:
                pass

    def _start_pending_message_drain(self, priority: PendingMessagePriority) -> None:
        if self._closed:
            return
        task = asyncio.create_task(self._drain_pending_messages(priority))
        self._background_tasks.add(task)
        task.add_done_callback(self._pending_message_task_done)

    def _pending_message_task_done(self, task: asyncio.Task[None]) -> None:
        self._background_tasks.discard(task)
        if not task.cancelled() and (error := task.exception()) is not None:
            self._park_error(error)
        self._queue_put(self._queue_changed)

    async def _drain_pending_messages(self, priority: PendingMessagePriority) -> None:
        """Deliver queued text prompts of `priority` and record them as normal user turns."""
        async with self._pending_messages_lock:
            response_active = (
                self._active_assistant is not None
                or self._response_parts
                or self._native_tool_parts
                or self._tool_calls_awaiting_usage
                or (priority == 'when_idle' and self._response_limit_checked)
            )
            if response_active:
                if priority == 'asap':
                    self._asap_drain_deferred = True
                return
            if priority == 'when_idle' and self._pending_messages.has_priority('asap'):
                # `when_idle` follows every queued `asap` item: the `asap` drain delivers those and
                # starts a reply, and this priority is retried once that reply completes.
                return
            selected = self._pending_messages.pop_priority(priority)
            for pending in selected:
                request = await self._send_text(_pending_message_text(pending), respond=True)
                self._queue_put(EnqueuedMessagesEvent(enqueue_id=pending.enqueue_id, messages=(request,)))
            if priority == 'asap':
                self._asap_drain_deferred = False

    def _check_tool_call_limit(self) -> None:
        # Let `UsageLimitExceeded` propagate (caught by the pump and re-raised to the consumer), matching
        # how a regular `run`/`iter` surfaces a usage limit rather than wrapping it in another error.
        if self._usage_limits is None:
            return
        projected = dataclasses.replace(self.usage, tool_calls=self.usage.tool_calls + self._tool_calls_in_flight + 1)
        self._usage_limits.check_before_tool_call(projected)

    def _check_usage_limits(self, *, warn_if_cost_unavailable: bool = True) -> None:
        if self._usage_limits is None:
            return
        self._usage_limits.check_tokens(self.usage)
        self._usage_limits.check_cost(self.usage, warn_if_cost_unavailable=warn_if_cost_unavailable)

    def _reserve_response_request(self) -> None:
        """Claim the request budget for a response this session is about to solicit.

        `usage.requests` only counts responses already finalized, so a reservation covers the ones
        between: those solicited but not yet started, and the one in flight. Without them, sends
        issued back-to-back would each see the same count and oversubscribe the budget.
        """
        self._check_request_limit()
        self._pending_response_requests += 1

    def _check_request_limit(self) -> None:
        """Check `request_limit` against one more response than those finalized, reserved and in flight."""
        if self._usage_limits is not None and self._responses_are_requests:
            in_flight = 1 if self._response_limit_checked else 0
            self._usage_limits.check_before_request(
                self._usage_as_recorded(ahead=self._pending_response_requests + in_flight)
            )

    def _usage_as_recorded(self, *, ahead: int = 0) -> RunUsage:
        """`usage`, with its requests counted as this session records them, plus `ahead` more.

        The core counts a response into `usage.requests` as its terminal frame arrives, a moment before this
        session records it and releases what it reserved for it: counted by this session's clock instead, no
        request is counted twice in between.
        """
        counted_by_core = self._core.requests if self._core is not None else self._requests_recorded
        requests = self.usage.requests - counted_by_core + self._requests_recorded + ahead
        return dataclasses.replace(self.usage, requests=requests)

    def _begin_response(self) -> None:
        """Take the reservation for the response that's starting, or make the check now if it has none.

        With server-side voice activity detection the provider starts a response on its own, so there
        was no send to check ahead of: the check happens here instead, at the response's first event,
        before any of its content or usage is processed.
        """
        if self._response_limit_checked:
            return
        if self._pending_response_requests:
            self._pending_response_requests -= 1
        elif self._usage_limits is not None and self._responses_are_requests:
            self._usage_limits.check_before_request(self._usage_as_recorded())
        self._response_limit_checked = True
        self._response_active = True
        # A response that is starting is not the one whose terminal is still to come. Gemini finalizes a
        # tool-call response through its usage with no terminal following, and a stale flag would read
        # the next response's terminal as that one's.
        self._response_finalized_before_terminal = False

    def _accumulate_response_usage(self, event: SessionUsage) -> list[RealtimeEvent]:
        events: list[RealtimeEvent] = []
        self._pending_response_usage = self._pending_response_usage + event.usage
        self._pending_provider_response_id = event.provider_response_id or self._pending_provider_response_id
        self._pending_finish_reason = event.finish_reason or self._pending_finish_reason
        if event.provider_details:
            self._pending_provider_details = {**(self._pending_provider_details or {}), **event.provider_details}
        if self._tool_calls_awaiting_usage:
            events.extend(self._finalize_assistant_part())
            self._finalize_response(
                provider_response_id=event.provider_response_id,
                finish_reason=event.finish_reason,
            )
            # OpenAI emits this usage immediately before `response.done`; the response is complete
            # already, so that terminal must not append a second, empty `ModelResponse`.
            self._response_finalized_before_terminal = True
        return events

    async def _handle_usage_event(self, event: SessionUsage) -> list[RealtimeEvent]:
        events: list[RealtimeEvent] = []
        if event.context_window_used is not None:
            self._reported_context_window_used = event.context_window_used
        if event.response_scoped:
            self._begin_response()
            if not self._responses_are_requests and self._core is None:
                # Each report is a request the model has already made: it is recorded in full, and the
                # one past the limit ends the session below, once it is. (The core counts it otherwise.)
                self.usage.requests += 1  # usage-attribution: the session owns its spans; `wrap_run` opens none
        if self._core is None:
            # (The core counts it otherwise, into this same `RunUsage`.)
            self.usage.incr(event.usage)  # usage-attribution: the session owns its spans; `wrap_run` opens none
        self._span_usage.incr(event.usage)  # usage-attribution: what the session span reports
        if event.response_scoped:
            # Measured before accumulating: a tool-call response is finalized by the accumulation
            # itself, which resets the accumulator.
            response_input_tokens = (self._pending_response_usage + event.usage).input_tokens
            events.extend(self._accumulate_response_usage(event))
            if self._usage_limits is not None:
                self._usage_limits.check_per_request_input_tokens(response_input_tokens)
        # Response pricing happens at finalization, so cost is provisionally unavailable here.
        self._check_usage_limits(warn_if_cost_unavailable=False)
        if event.response_scoped and not self._responses_are_requests:
            self._check_reported_requests()
        self._count_closed_tool_batch_replies()
        if self._asap_drain_ready:
            self._asap_drain_ready = False
            await self._drain_pending_messages('asap')
        return events

    async def _run_tool(
        self,
        call_part: ToolCallPart,
        *,
        validation_done: asyncio.Event,
        execution_prerequisites: tuple[asyncio.Event, ...],
        completion: asyncio.Event,
        response_usage_follows: bool,
        run_step: int,
        reserved_budget: bool,
        order_index: int,
        ordered_events: bool,
    ) -> None:
        """Run a tool and feed its completion (or failure) back through the queue."""
        try:
            result_part, content = await self._execute_tool(
                call_part,
                validation_done=validation_done,
                execution_prerequisites=execution_prerequisites,
                response_usage_follows=response_usage_follows,
                run_step=run_step,
                reserved_budget=reserved_budget,
            )
        except asyncio.CancelledError:
            if (batch := self._tool_call_batches.get(call_part.tool_call_id)) is not None:
                batch.running.discard(call_part.tool_call_id)
                self._retire_tool_batch_if_settled(batch)
            raise
        except BaseException as e:
            if (batch := self._tool_call_batches.get(call_part.tool_call_id)) is not None:
                # Its result will never go out, so the batch won't be answered.
                batch.running.discard(call_part.tool_call_id)
                batch.abandoned = True
                self._retire_tool_batch_if_settled(batch)
            self._complete_tool_call(call_part, _unsettled_call_return(call_part, e))
            # Surface the failure through the queue so the consumer re-raises it, instead of letting it
            # vanish into `__aexit__`'s cleanup-only drain and hang the session on a completion that
            # never arrives.
            self._park_error(e)
            return
        finally:
            validation_done.set()
            completion.set()
            self._tool_completion_events.discard(completion)
            # Settled (completed, failed, or cancelled): no longer cancellable by `ToolCallCancelled`.
            self._pending_tool_calls.pop(call_part.tool_call_id, None)
        if self._closed:
            # The session closed while this tool ran, so its call already has an interrupted return
            # in history. Reached by a tool that hung up with `close()` and then swallowed the
            # `CancelledError`: recording its result too would leave two returns for one call.
            return
        events = self._complete_tool_call(call_part, result_part, content)
        if ordered_events:
            # Held until nothing is still running, then released in call order — the graph waits for a
            # whole segment (`ALL_COMPLETED`) and replays it by index for the same reason. The release
            # is driven from `_tool_task_done`, which runs even for a tool that raised or was
            # cancelled, so a failed sibling can't strand the batch.
            self._ordered_tool_events[order_index] = events
        else:
            for event in events:
                self._queue_put(event)
        if self._asap_drain_deferred and not self._tool_calls_awaiting_usage:
            await self._drain_pending_messages('asap')

    def _tool_task_done(self, task: asyncio.Task[None]) -> None:
        self._background_tasks.discard(task)
        # Surface any exception raised outside `_run_tool`'s own try/except — notably the post-`finally`
        # `asap` drain, whose `connection.send` can fail if the socket just dropped — mirroring
        # `_pending_message_task_done`. Otherwise it vanishes with only an "exception was never
        # retrieved" warning at GC, silently losing the enqueued message with no signal to the consumer.
        if not task.cancelled() and (error := task.exception()) is not None:
            self._park_error(error)
        self._release_ordered_tool_events()
        # Wake the queue reader so it can finish once both the pump and the last tool are done.
        self._queue_put(self._queue_changed)

    def _release_ordered_tool_events(self) -> None:
        """Emit `parallel_ordered_events` results in call order, once nothing is still running.

        Called from every tool task's done-callback, so the last one to settle — successful, failed, or
        cancelled — flushes the batch, and a tool that never produced events can't hold it back.
        """
        if self._tool_completion_events or not self._ordered_tool_events:
            return
        for order_index in sorted(self._ordered_tool_events):
            for event in self._ordered_tool_events[order_index]:
                self._queue_put(event)
        self._ordered_tool_events.clear()

    async def _handle_pump_event(
        self,
        event: RealtimeCodecEvent,
    ) -> bool:
        """Process one upstream event onto the queue; return `True` to stop the pump (a limit tripped)."""
        if isinstance(event, ToolCall):
            # The tool call a held response was waiting for joins it, so the hold is spent.
            self._deferred_response_finish_reason = None
            if self._accept_item(event.item_id, event.tool_call_id):
                try:
                    await self._dispatch_tool_call(event)
                except UsageLimitExceeded:
                    # Tripped before the call joined the response, so it never runs or reaches history.
                    self._apply_core(ToolCallRefused(tool_call_id=event.tool_call_id))
                    raise
            return False
        return await self._handle_non_tool_pump_event(event)

    async def _dispatch_tool_call(self, event: ToolCall) -> None:
        """Fold a tool call into the response and start its background task."""
        # A declaratively deferred call (`requires_approval=True`, an external tool) is resolved by
        # a handler or refused — it never reaches the tool body and so never increments
        # `usage.tool_calls`. The graph leaves those out of its own pre-check projection
        # (`_tool_execution` builds `function_indices` from `('function', 'unknown')`), so charging
        # the budget for one here could trip the limit over a call that costs nothing. An unknown
        # tool name *is* charged, exactly as `'unknown'` is projected there.
        tool_def = self._tool_manager.get_tool_def(event.tool_name)
        reserves_budget = tool_def is None or not tool_def.defer
        if reserves_budget:
            self._check_tool_call_limit()
            self._tool_calls_in_flight += 1
        # Joined before the call is folded into the response below, which finalizes a response whose
        # usage doesn't follow and so closes the batch with this call in it.
        if self._connection._answers_tool_calls_per_response:  # pyright: ignore[reportPrivateUsage]
            batch = self._open_tool_batch
            if batch is None:
                batch = self._open_tool_batch = _ToolBatch()
            batch.calls.add(event.tool_call_id)
            batch.running.add(event.tool_call_id)
            self._tool_call_batches[event.tool_call_id] = batch
        # Captured at dispatch so every call from one response runs at the step in effect when the
        # response produced them, the way a graph run's whole batch shares the step advanced before
        # its request. Read at execution time instead, a call held behind a `sequential` barrier
        # could observe a later response's advance and land a step ahead of its own batch.
        tool_run_step = self._tool_run_step
        call_part = ToolCallPart(
            tool_name=event.tool_name,
            args=event.args,
            tool_call_id=event.tool_call_id,
        )
        self._content_response_id = event.response_id or self._content_response_id
        for out in self._handle_tool_call_part(
            call_part,
            response_usage_follows=event.response_usage_follows,
        ):
            # Published as well as queued: folding the call in first ends the in-flight assistant part,
            # so a turn that speaks *and* calls a tool ("let me look that up") emits its
            # `PartEndEvent(SpeechPart)` here rather than on the translation path, and the transcript
            # views would otherwise miss exactly the turns where the assistant speaks and acts.
            self._publish_taps(out)
            self._queue_put(out)
        mode = self._tool_manager.get_parallel_execution_mode()
        is_barrier = mode == 'sequential' or self._tool_manager.is_sequential(call_part)
        # `parallel_ordered_events` keeps calls concurrent but hands their result events to the
        # consumer in the order the model asked for them. Claimed here, at dispatch, because that
        # is the order — the graph replays a segment's events by index for the same reason. Only
        # the events are held back: the provider still gets each result the moment it lands, and
        # history is already assembled in call order by `_insert_tool_return`, exactly as the graph
        # keeps `output_parts` in emission order whatever the mode.
        order_index = self._next_tool_order_index
        self._next_tool_order_index += 1
        completion = asyncio.Event()
        if is_barrier:
            execution_prerequisites = tuple(self._tool_completion_events)
            self._last_tool_barrier = completion
        elif self._last_tool_barrier is not None:
            execution_prerequisites = (self._last_tool_barrier,)
        else:
            execution_prerequisites = ()
        self._tool_completion_events.add(completion)
        validation_done = asyncio.Event()
        task = asyncio.create_task(
            self._run_tool(
                call_part,
                validation_done=validation_done,
                execution_prerequisites=execution_prerequisites,
                completion=completion,
                response_usage_follows=event.response_usage_follows,
                run_step=tool_run_step,
                reserved_budget=reserves_budget,
                order_index=order_index,
                ordered_events=mode == 'parallel_ordered_events',
            )
        )
        self._background_tasks.add(task)
        self._pending_tool_calls[call_part.tool_call_id] = (task, call_part)
        task.add_done_callback(self._tool_task_done)
        # Deliberate, bounded block: this waits for argument *validation* only — `on_validate` sets
        # the event before any execution prerequisite or the tool body runs, and `_run_tool`'s
        # `finally` sets it if validation itself raises — so `FunctionToolCallEvent` is enqueued
        # before the pump processes any later event, without the pump ever waiting on user tool code.
        await validation_done.wait()

    def _settle_deferred_response(self) -> None:
        """Record a response held open for a tool call that didn't come next, as the response it was.

        Only history is settled: the provider said the exchange continues, so the turn boundary and
        `wait_for_reply()` keep waiting for the terminal that ends it.
        """
        if (finish_reason := self._deferred_response_finish_reason) is None:
            return
        self._deferred_response_finish_reason = None
        self._finalize_response(finish_reason=finish_reason, response_occurred=True)

    async def _handle_non_tool_pump_event(self, event: RealtimeCodecEvent) -> bool:
        """Process an upstream event other than a tool call; return `True` to stop the pump."""
        # `_handle_pump_event` routes every `ToolCall` to `_dispatch_tool_call`, so the remaining union
        # is what `_translate_event` accepts; asserted rather than re-tested so a future codec event
        # that slips past the dispatcher fails loudly instead of reaching the wrong translator.
        assert not isinstance(event, ToolCall)
        self._settle_deferred_response()
        if isinstance(event, ConversationCreated):
            return False
        if isinstance(event, ConversationItemCreated):
            self._handle_conversation_item(event)
            return False
        if isinstance(event, InputRejected):
            self._handle_input_rejected(event)
            return False
        if isinstance(event, ToolCallCancelled):
            for tool_call_id in event.tool_call_ids:
                if (batch := self._tool_call_batches.get(tool_call_id)) is not None:
                    # A cancelled call means the model abandoned the turn (usually a barge-in): its
                    # siblings' results still go out, but no reply is counted for them, since the
                    # interruption starts the next one.
                    batch.abandoned = True
                    batch.running.discard(tool_call_id)
                    self._retire_tool_batch_if_settled(batch)
                if (pending := self._pending_tool_calls.pop(tool_call_id, None)) is None:
                    continue
                task, call_part = pending
                task.cancel()
                # Record a cancelled result so the call still has a matching return in history (kept
                # valid for a handoff), and deliberately don't send a `ToolResult` back to the model —
                # it abandoned the call.
                cancelled_part = ToolReturnPart(
                    tool_name=call_part.tool_name,
                    content=INTERRUPTED_TOOL_RETURN_CONTENT,
                    tool_call_id=call_part.tool_call_id,
                    outcome='interrupted',
                )
                for out in self._complete_tool_call(call_part, cancelled_part):
                    self._queue_put(out)
            return False
        if isinstance(event, SessionUsage):
            # Only part and response boundaries come out of a usage report, never a speech-start
            # or interruption signal, so there is nothing for `_auto_barge_in` to do here.
            for out in await self._handle_usage_event(event):
                self._publish_taps(out)
                self._queue_put(out)
            return False
        for out in self._translate_event(event):
            self._publish_taps(out)
            if self._handle_barge_in:
                # Before the event reaches the consumer, so the app observes an already-handled
                # barge-in rather than racing the session to handle it.
                await self._auto_barge_in(out)
            self._queue_put(out)
        self._count_closed_tool_batch_replies()
        if isinstance(event, ResponseDone):
            await self._drain_pending_messages('asap')
            await self._drain_pending_messages('when_idle')
        return False

    async def _pump(self, context: Context | None) -> None:
        """Drain the connection into the session queue under the explicit session-span context."""
        token = otel_context.attach(context) if context is not None else None
        core_events = self._core_events(self._core) if self._core is not None else None
        try:
            events = self._connection if core_events is None else core_events
            async for event in events:
                if merged := self._connection._take_merged_response_requests():  # pyright: ignore[reportPrivateUsage]
                    # Requests the connection answered with a response it was already asking for: none of
                    # them gets one of its own.
                    self._pending_response_requests = max(0, self._pending_response_requests - merged)
                    self._exchange_progress.set()
                if await self._handle_pump_event(event):
                    return  # a usage limit tripped: stop reading the upstream
                self._count_closed_tool_batch_replies()
                self._drop_audio_the_core_keeps()
        except Exception as e:
            self._pump_error = e
        finally:
            if core_events is not None:
                # Closed here rather than whenever it is collected, so what it settles is settled before receiving ends.
                await core_events.aclose()
            self._pump_finished = True
            self._apply_core(ReceiveEnded())
            self._exchange_progress.set()
            if not self._closed:
                self._finish_taps()
            self._queue_put(self._queue_changed)
            if token is not None:
                otel_context.detach(token)

    def _apply_core(self, item: CoreInput) -> None:
        """Hand the core an event or a command, if it runs, and wake whoever waits on what it owes."""
        if self._core is None:
            return
        self._core.apply(item)
        if isinstance(item, AudioSent):
            # A microphone chunk: it neither settles anything owed nor changes what history holds back.
            return
        self._core_advanced(self._core)

    def _core_advanced(self, core: SessionCore) -> None:
        """Wake whoever waits on what the core owes, and bound how long a missing transcript holds history back."""
        self._exchange_progress.set()
        if (turn_id := core.transcript_holding_history()) is not None and turn_id not in self._transcript_watchdogs:
            self._transcript_watchdogs[turn_id] = asyncio.get_running_loop().call_later(
                _TRANSCRIPT_HOLD_SECONDS, self._transcript_overdue, turn_id
            )

    def _transcript_overdue(self, turn_id: str) -> None:
        del self._transcript_watchdogs[turn_id]
        self._apply_core(TranscriptOverdue(turn_id=turn_id))

    async def _core_events(self, core: SessionCore) -> AsyncGenerator[RealtimeCodecEvent]:
        """The connection's codec events, feeding the core its lifecycle stream on the way."""
        async for frame in self._connection._tagged_frames():  # pyright: ignore[reportPrivateUsage]  # pragma: no branch
            # Applied a whole frame at a time, before this session handles any of it: a consumer reacting
            # to one of its events (and reading the history, say) must find the core as far along as this one.
            for event, stale in frame:
                if not stale:
                    core.apply(event)
            self._core_advanced(core)
            codec = [event for event, _ in frame if not isinstance(event, LIFECYCLE_EVENT_TYPES)]
            handled = 0
            try:
                for event in codec:
                    handled += 1
                    yield event
            finally:
                # Receiving stopped (a limit tripped, or the session closed) before this session got to the rest of
                # the frame: a tool call in it never runs. It is refused, so it is left out of history, or given an
                # interrupted return if its response is recorded already (Gemini ends a tool-call response in the
                # message that makes the calls).
                for event in codec[handled:]:
                    if isinstance(event, ToolCall):
                        self._apply_core(ToolCallRefused(tool_call_id=event.tool_call_id))

    def _ensure_streamable(self) -> None:
        if not self._entered:
            raise UserError('Enter the realtime session with `async with` before streaming it.')
        if self._closed:
            raise UserError('This realtime session is closed and cannot be streamed.')

    def _start_pump(self) -> None:
        # Only once the session owns its context: before `__aenter__` there is no session span to
        # attach the loop to, and teardown has nothing tracking the task.
        if self._entered and self._pump_task is None:
            self._pump_task = asyncio.create_task(self._pump(self._session_instrumentation.context))

    def _publish_taps(self, event: RealtimeEvent) -> None:
        if isinstance(event, PartDeltaEvent) and isinstance(delta := event.delta, SpeechPartDelta):
            if delta.audio_chunk:
                if event.index == self._interrupted_audio_part_index:
                    # A straggler from a barge-in-flushed part, generated before the provider
                    # processed the cancel: erased from the taps and their accounting alike, so it
                    # neither plays as stale audio nor skews the next playback-position mapping.
                    pass
                else:
                    if event.index != self._audio_part_index:
                        # First audio of a new part: when a playback position is attributed,
                        # everything before this offset belongs to earlier turns.
                        self._audio_part_index = event.index
                        self._turn_audio_start_bytes = self._emitted_audio_bytes
                        item_id = (
                            self._active_assistant_item_id if event.index == self._active_assistant_index else None
                        )
                        self._audio_items.append((self._emitted_audio_bytes, item_id))
                    self._emitted_audio_bytes += len(delta.audio_chunk)
                    for tap in self._audio_taps:
                        self._audio_tap_drops += tap.put(delta.audio_chunk)
            if delta.transcript is not None and delta.speaker is not None:
                # Keyed on the running transcript, not on the added text: a revision adds nothing, and
                # gating on that would drop the very correction a caption UI needs.
                text = delta.transcript_delta or ''
                transcript = delta.transcript or self._transcript_so_far.get(event.index, '') + text
                self._transcript_so_far[event.index] = transcript
                if self._transcript_delta_taps:
                    update = TranscriptUpdate(
                        index=event.index, speaker=delta.speaker, delta=text, transcript=transcript
                    )
                    for queue in self._transcript_delta_taps:
                        if _put_tap(queue, update) is not None:
                            self._transcript_tap_drops += 1
        elif isinstance(event, PartEndEvent) and isinstance(part := event.part, SpeechPart):
            self._transcript_so_far.pop(event.index, None)
            if part.transcript:
                for queue in self._transcript_taps:
                    if _put_tap(queue, part) is not None:
                        self._transcript_tap_drops += 1

    def _finish_taps(self, *, discard_pending: bool = False) -> None:
        if discard_pending:
            for tap in self._audio_taps:
                tap.finish()
        audio_queues = (tap.queue for tap in self._audio_taps)
        for queue in (*audio_queues, *self._transcript_taps, *self._transcript_delta_taps):
            if discard_pending:
                while not queue.empty():
                    queue.get_nowait()
            queue.put_nowait(self._tap_finished)

    async def __aiter__(self) -> AsyncIterator[RealtimeEvent]:
        """Read translated events from the session queue without owning session resources."""
        if not self._entered:
            raise UserError('Enter the realtime session with `async with` before iterating it.')
        if self._closed:
            raise UserError('This realtime session is closed and cannot be iterated.')
        if self._iterator_active:
            raise UserError('This realtime session is already being iterated.')
        if self._stream_exhausted:
            raise UserError('This realtime session event stream has already ended.')

        self._iterator_active = True
        self._start_pump()

        async def queue_events() -> AsyncIterator[RealtimeEvent]:
            while True:
                item = await self._queue_get()
                if item is self._queue_changed:
                    # A pump error takes priority over stuck background tools. Their cancellation and
                    # drain belong to `__aexit__`, which runs as this exception leaves the owner block.
                    if self._pump_error is not None:
                        self._stream_exhausted = True
                        if not self._error_was_delivered(self._pump_error):
                            self._raise_delivered(self._pump_error)
                    if self._pump_finished and not self._background_tasks and not self._queue:
                        self._stream_exhausted = True
                        return
                    continue
                if isinstance(item, BaseException):
                    if self._error_was_delivered(item):
                        continue
                    self._raise_delivered(item)
                yield cast('RealtimeEvent', item)

        source = queue_events()
        stream: AsyncIterable[RealtimeEvent] = source
        if self._wrap_event_stream is not None:
            # The wrapper vocabulary is the `AgentStreamEvent` superset, but a wrapper applied to a
            # realtime stream must yield the `RealtimeEvent` subset exposed by the session.
            stream = cast('AsyncIterable[RealtimeEvent]', self._wrap_event_stream(source))
        stream_iterator = aiter(stream)
        try:
            async for event in stream_iterator:  # pragma: no branch
                yield event
        finally:
            # Nobody reads the queue past this point, so the bound applies again before the wrapper's
            # cleanup runs, however long that takes.
            self._iterator_active = False
            self._trim_queue()
            await aclose_all((stream_iterator, stream, source))
