from __future__ import annotations

from phoenix.client.utils.server_requirements import (
    ParameterRequirement,
    RouteRequirement,
    Version,
)

GET_SESSION = RouteRequirement(
    method="GET",
    path="/v1/sessions/{session_id}",
    min_server_version=Version(13, 5, 0),
)

DELETE_SESSION = RouteRequirement(
    method="DELETE",
    path="/v1/sessions/{session_id}",
    min_server_version=Version(13, 13, 0),
)

DELETE_SESSIONS = RouteRequirement(
    method="POST",
    path="/v1/sessions/delete",
    min_server_version=Version(13, 13, 0),
)

LIST_PROJECT_SESSIONS = RouteRequirement(
    method="GET",
    path="/v1/projects/{project_id}/sessions",
    min_server_version=Version(13, 5, 0),
)

ANNOTATE_SESSIONS = RouteRequirement(
    method="POST",
    path="/v1/session_annotations",
    min_server_version=Version(12, 0, 0),
)

GET_SPANS_TRACE_IDS = ParameterRequirement(
    parameter_name="trace_id",
    parameter_location="query",
    route="GET /v1/projects/{id}/spans",
    min_server_version=Version(13, 9, 0),
)

GET_SPANS_SPAN_IDS = ParameterRequirement(
    parameter_name="span_id",
    parameter_location="query",
    route="GET /v1/projects/{id}/spans",
    min_server_version=Version(19, 6, 0),
)

GET_SPANS_FILTERS = ParameterRequirement(
    parameter_name="span_kind",
    parameter_location="query",
    route="GET /v1/projects/{id}/spans",
    min_server_version=Version(13, 15, 0),
)

GET_SPANS_BY_ATTRIBUTE = ParameterRequirement(
    parameter_name="attribute",
    parameter_location="query",
    route="GET /v1/projects/{id}/spans",
    min_server_version=Version(14, 9, 0),
)

LIST_PROJECT_TRACES = RouteRequirement(
    method="GET",
    path="/v1/projects/{project_identifier}/traces",
    min_server_version=Version(13, 15, 0),
)

GET_TRACES_FILTERS = ParameterRequirement(
    parameter_name="error",
    parameter_location="query",
    route="GET /v1/projects/{id}/traces",
    min_server_version=Version(20, 8, 0),
    description=(
        "The 'error', 'min_latency_ms', and 'max_latency_ms' query parameters "
        "on GET /v1/projects/{id}/traces"
    ),
)

DATASET_UPLOAD_EXAMPLE_IDS = ParameterRequirement(
    parameter_name="example_ids",
    parameter_location="body",
    route="POST /v1/datasets/upload",
    min_server_version=Version(15, 0, 0),
)

DATASET_UPLOAD_EXAMPLE_ID_KEY = ParameterRequirement(
    parameter_name="example_id_key",
    parameter_location="form",
    route="POST /v1/datasets/upload",
    min_server_version=Version(15, 0, 0),
)

DATASET_UPLOAD_SPLIT_KEY = ParameterRequirement(
    parameter_name="split_key",
    parameter_location="form",
    route="POST /v1/datasets/upload",
    min_server_version=Version(15, 0, 0),
)

PATCH_PROMPT = RouteRequirement(
    method="PATCH",
    path="/v1/prompts/{prompt_identifier}",
    min_server_version=Version(19, 18, 0),
)

DELETE_PROMPT = RouteRequirement(
    method="DELETE",
    path="/v1/prompts/{prompt_identifier}",
    min_server_version=Version(13, 20, 0),
)
