import inspect
from functools import partial, wraps
from typing import (
    Any,
    AsyncGenerator,
    Awaitable,
    Callable,
    Dict,
    Generator,
    Iterator,
    List,
    Optional,
    Tuple,
    Type,
    TypeVar,
    cast,
)

from opentelemetry.context import (
    Context,
    attach,
    detach,
    get_current,
    get_value,
    set_value,
)
from typing_extensions import Self

from openinference.semconv.trace import SpanAttributes

from ._types import AttributeValue
from .helpers import safe_json_dumps

DecoratedCallable = TypeVar("DecoratedCallable", bound=Callable[..., Any])

CONTEXT_ATTRIBUTES = (
    SpanAttributes.SESSION_ID,
    SpanAttributes.USER_ID,
    SpanAttributes.METADATA,
    SpanAttributes.TAG_TAGS,
    SpanAttributes.LLM_PROMPT_TEMPLATE,
    SpanAttributes.LLM_PROMPT_TEMPLATE_VERSION,
    SpanAttributes.LLM_PROMPT_TEMPLATE_VARIABLES,
)


class _RollingOtelContext:
    __slots__ = ("_body_context",)

    def __init__(self, initial_body_context: Context) -> None:
        self._body_context = initial_body_context

    def run_sync(self, step: Callable[..., Any], /, *args: Any, **kwargs: Any) -> Any:
        token = attach(self._body_context)
        try:
            result = step(*args, **kwargs)
            self._body_context = get_current()
            return result
        finally:
            detach(token)

    async def run_async(
        self, step: Callable[..., Awaitable[Any]], /, *args: Any, **kwargs: Any
    ) -> Any:
        token = attach(self._body_context)
        try:
            result = await step(*args, **kwargs)
            self._body_context = get_current()
            return result
        finally:
            detach(token)


def _drive_sync_generator_in_rolling_otel(
    rolling: _RollingOtelContext,
    body: Generator[Any, Any, Any],
) -> Generator[Any, Any, Any]:
    try:
        item = rolling.run_sync(body.send, None)
        while True:
            try:
                received = yield item
            except GeneratorExit:
                rolling.run_sync(body.close)
                raise
            except BaseException as exc:
                item = rolling.run_sync(body.throw, exc)
            else:
                item = rolling.run_sync(body.send, received)
    except StopIteration as stop:
        return stop.value


class _AwaitRollingOtelStep:
    __slots__ = ("_rolling", "_awaitable")

    def __init__(self, rolling: _RollingOtelContext, awaitable: Awaitable[Any]) -> None:
        self._rolling = rolling
        self._awaitable = awaitable

    def __await__(self) -> Generator[Any, Any, Any]:
        return self._run().__await__()

    async def _run(self) -> Any:
        async def step() -> Any:
            return await self._awaitable

        return await self._rolling.run_async(step)


class _UsingAttributesContextManager:
    def __init__(
        self,
        *,
        session_id: str = "",
        user_id: str = "",
        metadata: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
        prompt_template: str = "",
        prompt_template_version: str = "",
        prompt_template_variables: Optional[Dict[str, Any]] = None,
    ) -> None:
        self._session_id = session_id
        self._user_id = user_id
        self._metadata = metadata
        self._tags = tags
        self._prompt_template = prompt_template
        self._prompt_template_version = prompt_template_version
        self._prompt_template_variables = prompt_template_variables

    def _context_with_attributes(self) -> Context:
        ctx = get_current()
        if self._session_id:
            ctx = set_value(SpanAttributes.SESSION_ID, self._session_id, ctx)
        if self._user_id:
            ctx = set_value(SpanAttributes.USER_ID, self._user_id, ctx)
        if self._metadata:
            ctx = set_value(SpanAttributes.METADATA, safe_json_dumps(self._metadata), ctx)
        if self._tags:
            ctx = set_value(SpanAttributes.TAG_TAGS, self._tags, ctx)
        if self._prompt_template:
            ctx = set_value(SpanAttributes.LLM_PROMPT_TEMPLATE, self._prompt_template, ctx)
        if self._prompt_template_version:
            ctx = set_value(
                SpanAttributes.LLM_PROMPT_TEMPLATE_VERSION, self._prompt_template_version, ctx
            )
        if self._prompt_template_variables:
            ctx = set_value(
                SpanAttributes.LLM_PROMPT_TEMPLATE_VARIABLES,
                safe_json_dumps(self._prompt_template_variables),
                ctx,
            )
        return ctx

    def attach_context(self) -> None:
        self._token = attach(self._context_with_attributes())

    def __enter__(self) -> Self:
        self.attach_context()
        return self

    async def __aenter__(self) -> Self:
        self.attach_context()
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_value: Optional[BaseException],
        traceback: Optional[Any],
    ) -> None:
        detach(self._token)

    async def __aexit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_value: Optional[BaseException],
        traceback: Optional[Any],
    ) -> None:
        detach(self._token)

    def __call__(self, decorated_function: DecoratedCallable) -> DecoratedCallable:
        if inspect.isasyncgenfunction(decorated_function):

            @wraps(decorated_function)
            async def async_generator_wrapper(
                *args: Any, **kwargs: Any
            ) -> AsyncGenerator[Any, Any]:
                rolling = _RollingOtelContext(self._context_with_attributes())
                body: AsyncGenerator[Any, Any] = decorated_function(*args, **kwargs)
                step = partial(_AwaitRollingOtelStep, rolling)
                try:
                    item = await step(body.asend(None))
                    while True:
                        try:
                            received = yield item
                        except GeneratorExit:
                            await step(body.aclose())
                            raise
                        except BaseException as exception:
                            item = await step(body.athrow(exception))
                        else:
                            item = await step(body.asend(received))
                except StopAsyncIteration:
                    return

            return cast(DecoratedCallable, async_generator_wrapper)

        if inspect.isgeneratorfunction(decorated_function):

            @wraps(decorated_function)
            def generator_wrapper(*args: Any, **kwargs: Any) -> Generator[Any, Any, Any]:
                rolling = _RollingOtelContext(self._context_with_attributes())
                return_value = yield from _drive_sync_generator_in_rolling_otel(
                    rolling, decorated_function(*args, **kwargs)
                )
                return return_value

            return cast(DecoratedCallable, generator_wrapper)

        if inspect.iscoroutinefunction(decorated_function):

            @wraps(decorated_function)
            async def coroutine_wrapper(*args: Any, **kwargs: Any) -> Any:
                token = attach(self._context_with_attributes())
                try:
                    return await decorated_function(*args, **kwargs)
                finally:
                    detach(token)

            return cast(DecoratedCallable, coroutine_wrapper)

        @wraps(decorated_function)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            token = attach(self._context_with_attributes())
            try:
                return decorated_function(*args, **kwargs)
            finally:
                detach(token)

        return cast(DecoratedCallable, sync_wrapper)


class using_session(_UsingAttributesContextManager):
    """
    Context manager to add session id to the current OpenTelemetry Context. OpenInference
    instrumentations will read this Context and pass the session id as a span attribute,
    following the OpenInference semantic conventions.

    Also usable as a decorator on plain, ``async def``, generator and async generator
    functions; the attributes then apply for the whole call.

    Examples:
        with using_session("my-session-id"):
            # Tracing within this block will include the span attribute:
            # "session.id" = "my-session-id"
            ...
    """

    def __init__(self, session_id: str) -> None:
        super().__init__(session_id=session_id)


class using_user(_UsingAttributesContextManager):
    """
    Context manager to add user id to the current OpenTelemetry Context. OpenInference
    instrumentations will read this Context and pass the user id as a span attribute,
    following the OpenInference semantic conventions.

    Also usable as a decorator on plain, ``async def``, generator and async generator
    functions; the attributes then apply for the whole call.

    Examples:
        with using_user("my-user-id"):
            # Tracing within this block will include the span attribute:
            # "user.id" = "my-user-id"
            ...
    """

    def __init__(self, user_id: str) -> None:
        super().__init__(user_id=user_id)


class using_metadata(_UsingAttributesContextManager):
    """
    Context manager to add metadata to the current OpenTelemetry Context. OpenInference
    instrumentations will read this Context and pass the metadata as a span attribute,
    following the OpenInference semantic conventions.

    Also usable as a decorator on plain, ``async def``, generator and async generator
    functions; the attributes then apply for the whole call.

    Examples:
        metadata = {
            "key-1": value_1,
            "key-2": value_2,
            ...
        }
        with using_metadata(metadata):
            # Tracing within this block will include the span attribute:
            # "metadata" = "{\"key-1\": value_1, \"key-2\": value_2, ... }"
            ...
    """

    def __init__(self, metadata: Dict[str, Any]) -> None:
        super().__init__(metadata=metadata)


class using_tags(_UsingAttributesContextManager):
    """
    Context manager to add tags to the current OpenTelemetry Context. OpenInference
    instrumentations will read this Context and pass the tags as a span attribute,
    following the OpenInference semantic conventions.

    Also usable as a decorator on plain, ``async def``, generator and async generator
    functions; the attributes then apply for the whole call.

    Examples:
        tags = [
            "tag_1",
            "tag_2",
            ...
        ]
        with using_tags(tags):
            # Tracing within this block will include the span attribute:
            # "tag.tags" = "["tag_1","tag_2",...]"
            ...
    """

    def __init__(self, tags: List[str]) -> None:
        super().__init__(tags=tags)


class using_prompt_template(_UsingAttributesContextManager):
    """
    Context manager to add prompt template, with its version and variables a to the
    current OpenTelemetry Context. OpenInference instrumentations will read this
    Context and pass the prompt template as a span attribute, following the
    OpenInference semantic conventions.

    Also usable as a decorator on plain, ``async def``, generator and async generator
    functions; the attributes then apply for the whole call.

    Examples:
        prompt_template = "Please describe the weather forecast for {city} on {date}"
        prompt_template_variables = {"city": "Johannesburg", date:"July 11"}
        with using_prompt_template(
            template=prompt_template,
            version="v1.0",
            variables=prompt_template_variables,
        ):
            # Tracing within this block will include the span attribute:
            # "llm.prompt_template.template" = "Please describe the weather
            forecast for {city} on {date}"
            # "llm.prompt_template.version" = "v1.0"
            # "llm.prompt_template.variables" = "{\"city\": \"Johannesburg\",
            \"date\": \"July 11\"}"
            ...
    """

    def __init__(
        self,
        *,
        template: str = "",
        version: str = "",
        variables: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(
            prompt_template=template,
            prompt_template_version=version,
            prompt_template_variables=variables,
        )


class using_attributes(_UsingAttributesContextManager):
    """
    Context manager to add attributes to the current OpenTelemetry Context. OpenInference
    instrumentations will read this Context and pass the attributes to the traced span,
    following the OpenInference semantic conventions.

    Also usable as a decorator on plain, ``async def``, generator and async generator
    functions; the attributes then apply for the whole call.

    It is a convenient context manager to use if you find yourself using many others, provided
    by this package, combined.

    Example:
        tags = [
            "tag_1",
            "tag_2",
            ...
        ]
        metadata = {
            "key-1": value_1,
            "key-2": value_2,
            ...
        }
        prompt_template = "Please describe the weather forecast for {city} on {date}"
        prompt_template_variables = {"city": "Johannesburg", date:"July 11"}
        prompt_template_version = "v1.0"
        with using_attributes(
            session_id="my-session-id",
            user_id="my-user-id",
            metadata=metadata,
            tags=tags,
            prompt_template=prompt_template,
            prompt_template_version=prompt_template_version,
            prompt_template_variables=prompt_template_variables,
        ):
            # Tracing within this block will include the span attribute:
            # "session.id" = "my-session-id"
            # "user.id" = "my-user-id"
            # "metadata" = "{\"key-1\": value_1, \"key-2\": value_2, ... }"
            # "tag.tags" = "["tag_1","tag_2",...]"
            # "llm.prompt_template.template" = "Please describe the weather forecast
            for {city} on {date}"
            # "llm.prompt_template.variables" = "{\"city\": \"Johannesburg\",
            \"date\": \"July 11\"}"
            # "llm.prompt_template.version " = "v1.0"



            ...

    The previous example is equivalent to doing:
        with (
            using_session("my-session-id"),
            using_user("my-user-id"),
            using_metadata(metadata),
            using_tags(tags),
            using_prompt_template(
                template=prompt_template,
                version=prompt_template_version,
                variables=prompt_template_variables,
            ),
        ):
            ...

    """

    def __init__(
        self,
        *,
        session_id: str = "",
        user_id: str = "",
        metadata: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
        prompt_template: str = "",
        prompt_template_version: str = "",
        prompt_template_variables: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(
            session_id=session_id,
            user_id=user_id,
            metadata=metadata,
            tags=tags,
            prompt_template=prompt_template,
            prompt_template_version=prompt_template_version,
            prompt_template_variables=prompt_template_variables,
        )


def get_attributes_from_context() -> Iterator[Tuple[str, AttributeValue]]:
    """
    Yield the OpenInference context attributes currently attached to the OpenTelemetry
    context. ``OITracer`` calls this when a span starts to copy them onto the span.
    """
    for ctx_attr in CONTEXT_ATTRIBUTES:
        if (val := get_value(ctx_attr)) is not None:
            yield ctx_attr, cast(AttributeValue, val)
