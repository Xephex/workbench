from __future__ import annotations


class PydanticAIDeprecationWarning(UserWarning):
    """Warning emitted when a deprecated Pydantic AI API is used.

    Inherits from `UserWarning` instead of `DeprecationWarning` so that
    deprecations are visible by default at runtime, following the approach
    described in https://sethmlarson.dev/deprecations-via-warnings-dont-work-for-python-libraries.
    """


class CostCalculationFailedWarning(Warning):
    """Warning raised when cost calculation fails."""


class UsageExtractionFailedWarning(Warning):
    """Warning raised when usage extraction fails."""


class CostNotFoundWarning(Warning):
    """Warning raised when cost is not found."""
