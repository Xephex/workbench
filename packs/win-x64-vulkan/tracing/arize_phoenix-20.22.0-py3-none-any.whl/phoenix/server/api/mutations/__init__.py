import strawberry

from phoenix.server.api.mutations.agent_session_mutations import AgentSessionMutationMixin
from phoenix.server.api.mutations.annotation_config_mutations import AnnotationConfigMutationMixin
from phoenix.server.api.mutations.api_key_mutations import ApiKeyMutationMixin
from phoenix.server.api.mutations.chat_mutations import (
    ChatCompletionMutationMixin,
)
from phoenix.server.api.mutations.dataset_label_mutations import DatasetLabelMutationMixin
from phoenix.server.api.mutations.dataset_mutations import DatasetMutationMixin
from phoenix.server.api.mutations.dataset_split_mutations import DatasetSplitMutationMixin
from phoenix.server.api.mutations.document_annotations_mutations import (
    DocumentAnnotationMutationMixin,
)
from phoenix.server.api.mutations.evaluator_mutations import EvaluatorMutationMixin
from phoenix.server.api.mutations.experiment_mutations import ExperimentMutationMixin
from phoenix.server.api.mutations.generative_model_custom_provider_mutations import (
    GenerativeModelCustomProviderMutationMixin,
)
from phoenix.server.api.mutations.model_mutations import ModelMutationMixin
from phoenix.server.api.mutations.oauth2_grant_mutations import OAuth2GrantMutationMixin
from phoenix.server.api.mutations.project_annotations_mutations import (
    ProjectAnnotationMutationMixin,
)
from phoenix.server.api.mutations.project_mutations import ProjectMutationMixin
from phoenix.server.api.mutations.project_session_annotations_mutations import (
    ProjectSessionAnnotationMutationMixin,
)
from phoenix.server.api.mutations.project_trace_retention_policy_mutations import (
    ProjectTraceRetentionPolicyMutationMixin,
)
from phoenix.server.api.mutations.prompt_label_mutations import PromptLabelMutationMixin
from phoenix.server.api.mutations.prompt_mutations import PromptMutationMixin
from phoenix.server.api.mutations.prompt_version_tag_mutations import PromptVersionTagMutationMixin
from phoenix.server.api.mutations.sandbox_config_mutations import SandboxConfigMutationMixin
from phoenix.server.api.mutations.secret_mutations import SecretMutationMixin
from phoenix.server.api.mutations.span_annotations_mutations import SpanAnnotationMutationMixin
from phoenix.server.api.mutations.system_settings_mutations import SystemSettingsMutationMixin
from phoenix.server.api.mutations.trace_annotations_mutations import TraceAnnotationMutationMixin
from phoenix.server.api.mutations.trace_mutations import TraceMutationMixin
from phoenix.server.api.mutations.user_mutations import UserMutationMixin


@strawberry.type
class Mutation(
    AgentSessionMutationMixin,
    AnnotationConfigMutationMixin,
    ApiKeyMutationMixin,
    ChatCompletionMutationMixin,
    DatasetLabelMutationMixin,
    DatasetMutationMixin,
    DatasetSplitMutationMixin,
    DocumentAnnotationMutationMixin,
    EvaluatorMutationMixin,
    ExperimentMutationMixin,
    GenerativeModelCustomProviderMutationMixin,
    ModelMutationMixin,
    OAuth2GrantMutationMixin,
    ProjectAnnotationMutationMixin,
    ProjectMutationMixin,
    ProjectTraceRetentionPolicyMutationMixin,
    PromptMutationMixin,
    PromptVersionTagMutationMixin,
    PromptLabelMutationMixin,
    SandboxConfigMutationMixin,
    SecretMutationMixin,
    SpanAnnotationMutationMixin,
    SystemSettingsMutationMixin,
    ProjectSessionAnnotationMutationMixin,
    TraceAnnotationMutationMixin,
    TraceMutationMixin,
    UserMutationMixin,
):
    pass
