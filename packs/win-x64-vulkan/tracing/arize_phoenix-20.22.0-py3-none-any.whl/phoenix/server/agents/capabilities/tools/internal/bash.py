from __future__ import annotations

import asyncio
import itertools
import json
import posixpath
import re
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Generic, Mapping, Optional, Sequence

import strawberry
from bashkit import Bash, BuiltinContext, BuiltinResult
from graphql import OperationType as GraphQLOperationType
from jinja2 import Template
from pydantic_ai import RunContext, Tool
from pydantic_ai.capabilities import AbstractCapability
from pydantic_ai.exceptions import ApprovalRequired
from pydantic_ai.tools import AgentDepsT
from pydantic_ai.toolsets import AgentToolset, FunctionToolset
from typing_extensions import TypedDict

from phoenix.server.api.context import Context
from phoenix.server.api.graphql_execute import (
    MAX_QUERY_BYTES,
    GraphQLRefusal,
    execute_operation,
    operation_count,
    operation_types,
)
from phoenix.server.api.schema_search import cached_index, describe

BASH_TOOL_NAME = "bash"
WORKSPACE_ROOT = "/home/user/workspace"
TMP_ROOT = "/tmp"


@dataclass
class GraphQLMutationPolicy:
    """Mutation-execution policy"""

    allow_mutations: bool
    require_approval: bool = False
    approved: bool = False

    @property
    def mutations_allowed(self) -> bool:
        return self.allow_mutations and (not self.require_approval or self.approved)


_BASH_TOOL_DESCRIPTION = """\
Run a shell command inside a server-side virtual shell to run built-in utilities and \
operate on a scratch filesystem.

- Runs inside an in-process virtual shell, not a host machine or container.
- Write scratch files only under /home/user/workspace.
- General-purpose network access is disabled, so curl/wget and remote package installs \
should not be assumed to work.
- Built-in shell commands are available; do not assume apt, brew, pnpm, uv, git, or \
other host binaries exist.
- Language runtimes such as python, python3, and node are not available.
- awk's postfix increment on an array element returns the new value, so the \
`!seen[$1]++` dedupe idiom prints nothing; use `sort -u`, jq's `unique_by` / \
`group_by`, or `!($1 in seen) {seen[$1]=1; print}`.
- phoenix-gql is available for GraphQL operations against the Phoenix GraphQL API. \
`phoenix-gql schema --search <text>` finds the types and fields to query and \
`--names <A,B>` prints named ones in full; run `phoenix-gql --help` for usage \
and current permissions. Pass filter strings such as `name == 'X'` through \
a `--vars-file` written with a quoted heredoc rather than inlining them, so their \
quotes never nest inside shell quotes.
- Dataset reads go through here. `Query.datasets(filter: {col: name, value: "..."}, \
first, after)` lists datasets (names are unique — check before a `ui.dataset.create`). \
`node(id: <datasetId>) { ... on Dataset { examples(first, after) { edges { node { id \
revision { input output metadata } } } } splits { id name } labels { id name } } }` \
reads a dataset's rows, splits, and labels — row content lives under `revision`. \
`Query.datasetSplits` / `Query.datasetLabels` list the instance-wide split/label \
vocabularies. The dataset in view's node id is advertised in your context.
- Keep read results compact: request only the fields you need and paginate with small \
pages (`first: 10` is usually enough to learn a dataset's row shape) instead of \
dumping whole connections.

Args:
    summary: Short, user-facing description of what this command does. Shown as the
        collapsed preview in the UI.
    command: The shell command to execute.
    mutation_description: Provide if and only if the command invokes a GraphQL \
mutation via phoenix-gql: a concise, user-facing, one-sentence description of the \
change the mutation will make, starting with "This command will ...". This is the \
entire approval prompt the user reads before the command runs, so describe the \
actual change, not your goal. Omitting it on a mutating command does not skip \
approval — the mutation is refused and you must re-issue the call with it.

Returns a dict with the command's `stdout`, `stderr`, and `exitCode`.\
"""


def _resolve_path(cwd: str, path: str) -> str:
    """Resolve ``path`` against ``cwd``.resolvePath`` does.

    Relative paths are joined onto ``cwd``; absolute paths ignore it. The result is
    normalized, collapsing ``.`` and ``..`` segments.

    >>> _resolve_path("/home/user/workspace", "out.json")
    '/home/user/workspace/out.json'
    >>> _resolve_path("/home/user/workspace", "/etc/passwd")
    '/etc/passwd'
    >>> _resolve_path("/home/user/workspace", "../shared/q.graphql")
    '/home/user/shared/q.graphql'
    """
    if path.startswith("/"):
        return posixpath.normpath(path)
    return posixpath.normpath(posixpath.join(cwd, path))


def _format_graphql_errors(errors: Sequence[Mapping[str, Any]]) -> str:
    """One line per error, led by its ``line:column`` and closed by its path.

    >>> _format_graphql_errors([{"message": "bad", "locations": [{"line": 3, "column": 5}],
    ...     "path": ["a", 0, "b"]}])
    'GraphQL errors:\\n- [3:5] bad (at a.0.b)\\n'
    """
    lines = []
    for error in errors:
        where = "".join(f"[{loc['line']}:{loc['column']}] " for loc in error.get("locations") or [])
        path = error.get("path")
        at = f" (at {'.'.join(map(str, path))})" if path else ""
        lines.append(f"- {where}{error.get('message', '')}{at}")
    return "GraphQL errors:\n" + "\n".join(lines) + "\n"


# Annotated because jinja2's `Template.__new__` returns `t.Any`, which would
# make the instance (and `.render()`) untyped under mypy.
_HELP_TEXT_TEMPLATE: Template = Template(
    """\
Usage: phoenix-gql [query] [options] [query-or-file]
       phoenix-gql schema [--search <text>]... [--names <A,B>]...

Execute GraphQL operations against Phoenix, or search its schema.

{% if not mutations_enabled -%}
Permissions: queries only (mutations are disabled).
{% elif approval_required -%}
Permissions: queries and mutations are enabled, but a command that runs a \
mutation must pass mutation_description to the bash tool, and the user approves \
it before the command runs. There is no dry run: once approved, the command \
executes for real, exactly once.
{% else -%}
Permissions: queries and mutations are ENABLED.
{% endif %}
Size: a document may be at most {{ max_query_kib }} KiB of UTF-8. Values passed with --vars or --vars-file do not count toward it, so put large inputs there.

Recommended flow:
  1. `phoenix-gql schema --search <text>` to find the types and fields you
     need, and `--names <Type,Type.field>` to see each in full with how to
     reach it; both repeat, and both fit in one call, so batch what you
     already know you need. With no flags it prints the query root. Narrow a
     noisy search to one type with `--search "Span.cost"`. Name the return
     types and input types you see rather than repeating the same terms
{%- if mutations_enabled %}. Add
     the word "mutations" to a search to see only mutations, and pass a
     mutation's name to `--names` to see the inputs it takes
{%- endif %}
  2. add filters, sorting, and deeper fields only after the base query works
{%- if approval_required %}
  3. keep mutations in their own bash call, separate from the queries that
     shaped them, so the user approves one clear change at a time
{%- endif %}

Options:
  --vars <json>         JSON object of GraphQL variables
  --variables <json>    Alias for --vars
  --vars-file <path>    Read GraphQL variables from a file
  --operation-name <n>  Operation to run when the document declares several
  --output <path>       Write JSON response to a file instead of stdout
  --data-only           Print only the .data payload
  --help                Show this help text

Examples:
  phoenix-gql schema --search "span cost"
  phoenix-gql schema --names Experiment
  phoenix-gql schema --search "trace by otel id" --names TimeRange,TimeBinConfig
  phoenix-gql '{ projects { edges { node { name } } } }'
  cat query.graphql | phoenix-gql --vars '{"id":"abc"}'
  phoenix-gql query.graphql --vars-file vars.json | jq '.data'
  cat > vars.json <<'EOF'
  {"f": "name == 'X' and status_code == 'ERROR'"}
  EOF
  phoenix-gql 'query($f: String!) { node(id: "UHJvamVjdDox") { ... on Project { recordCount(filterCondition: $f) } } }' --vars-file vars.json
"""
)


def _get_help_text(mutations_enabled: bool, approval_required: bool = False) -> str:
    return _HELP_TEXT_TEMPLATE.render(
        mutations_enabled=mutations_enabled,
        approval_required=approval_required,
        max_query_kib=MAX_QUERY_BYTES // 1024,
    )


# The query root alone needs most of this, and a root cut short hides entry
# points; the MCP tool uses the same figure.
_SCHEMA_BUDGET = 4000


_MAX_VALUE_CHARS = 2000
_MAX_ARGS = 64


def _parse_schema_args(args: Sequence[str]) -> tuple[list[str], list[str]]:
    """``(searches, names)`` from the flags after ``schema``.

    ``--search TEXT`` adds a search and ``--names A,B`` adds exact names; both
    repeat. Nothing else is accepted.
    """
    searches: list[str] = []
    names: list[str] = []
    it = iter(args[:_MAX_ARGS])
    for arg in it:
        arg = arg[: _MAX_VALUE_CHARS + len("--search=")]
        flag, has_value, inline = arg.partition("=")
        if flag not in ("--search", "--names"):
            raise ValueError(f"unexpected argument {arg!r}: use --search <text> and --names <A,B>")
        value = inline if has_value else next(it, None)
        value = value[:_MAX_VALUE_CHARS] if value is not None else None
        if value is None or not value.strip():
            raise ValueError(f"{flag} needs a value")
        if flag == "--search":
            searches.append(value.strip())
        else:
            names.extend(n for n in re.split(r"[,\s]+", value) if n)
    return searches, names


@dataclass
class _ParsedArgs:
    query_source: Optional[str]
    variables_text: Optional[str]
    variables_file_path: Optional[str]
    operation_name: Optional[str]
    output_path: Optional[str]
    data_only: bool
    show_help: bool


def _normalize_args(args: list[str]) -> list[str]:
    if args and args[0] == "query":
        args = args[1:]
    return ["--vars" if arg == "--variables" else arg for arg in args]


def _parse_args(args: list[str]) -> _ParsedArgs:
    args = _normalize_args(args)
    query_source: Optional[str] = None
    variables_text: Optional[str] = None
    variables_file_path: Optional[str] = None
    operation_name: Optional[str] = None
    output_path: Optional[str] = None
    data_only = False
    show_help = False

    index = 0
    while index < len(args):
        arg = args[index]
        if arg == "--help":
            show_help = True
        elif arg == "--data-only":
            data_only = True
        elif arg == "--vars":
            variables_text = args[index + 1] if index + 1 < len(args) else None
            index += 1
        elif arg == "--vars-file":
            variables_file_path = args[index + 1] if index + 1 < len(args) else None
            index += 1
        elif arg == "--operation-name":
            operation_name = args[index + 1] if index + 1 < len(args) else None
            index += 1
        elif arg == "--output":
            output_path = args[index + 1] if index + 1 < len(args) else None
            index += 1
        elif arg.startswith("--"):
            raise ValueError(f"Unknown option: {arg}")
        elif query_source is not None:
            raise ValueError("Expected a single query string or query file path")
        else:
            query_source = arg
        index += 1

    return _ParsedArgs(
        query_source=query_source,
        variables_text=variables_text,
        variables_file_path=variables_file_path,
        operation_name=operation_name,
        output_path=output_path,
        data_only=data_only,
        show_help=show_help,
    )


def _could_be_file_path(query_source: str) -> bool:
    """Whether ``query_source`` could plausibly name a file.

    Inline GraphQL always contains ``{`` (and often newlines), neither of which
    appears in a real file path. Skipping the filesystem probe for such values
    matters beyond aesthetics: sandbox filesystems raise on over-long path
    components, so probing a multi-hundred-byte inline query as if it were a
    path fails the whole command instead of executing the query.
    """
    return "{" not in query_source and "\n" not in query_source


def _resolve_query_text(parsed: _ParsedArgs, ctx: BuiltinContext) -> str:
    """Return the GraphQL query text selected by ``parsed``.

    A ``query_source`` that could name a file and resolves to an existing file
    under ``ctx.cwd`` is read from the filesystem; otherwise it is taken as a
    literal inline query. With no ``query_source``, the stripped piped stdin is
    used, and an empty stdin is an error.
    """
    if parsed.query_source:
        if _could_be_file_path(parsed.query_source):
            resolved_path = _resolve_path(ctx.cwd, parsed.query_source)
            try:
                is_file = ctx.fs.exists(resolved_path)
            except Exception:
                # A probe the filesystem refuses (e.g. over-long path) cannot
                # be an existing file; fall through to the inline query.
                is_file = False
            if is_file:
                return ctx.fs.read_file(resolved_path).decode("utf-8")
            if _names_a_file(parsed.query_source):
                raise ValueError(f"File not found: {parsed.query_source}")
        return parsed.query_source

    piped_query = (ctx.stdin or "").strip()
    if not piped_query:
        raise ValueError("Provide a GraphQL query string, file path, or stdin")
    return piped_query


def _names_a_file(query_source: str) -> bool:
    """Whether ``query_source`` is unmistakably a path rather than an inline document."""
    return query_source.endswith((".graphql", ".gql")) or "/" in query_source


def _resolve_variables(parsed: _ParsedArgs, ctx: BuiltinContext) -> Optional[dict[str, Any]]:
    if parsed.variables_file_path:
        resolved = _resolve_path(ctx.cwd, parsed.variables_file_path)
        variables_text: Optional[str] = ctx.fs.read_file(resolved).decode("utf-8")
    else:
        variables_text = parsed.variables_text

    if not variables_text:
        return None

    try:
        parsed_variables = json.loads(variables_text)
    except json.JSONDecodeError as error:
        raise ValueError(
            f"GraphQL variables are not valid JSON: {error}. Shell quoting often "
            "mangles inline JSON; --vars-file <path> avoids it."
        ) from error
    if not isinstance(parsed_variables, dict):
        raise ValueError("GraphQL variables must be a JSON object")
    return parsed_variables


def _write_file(ctx: BuiltinContext, path: str, content: str) -> None:
    parent = path[: path.rfind("/")] or "/"
    if not ctx.fs.exists(parent):
        ctx.fs.mkdir(parent, recursive=True)
    ctx.fs.write_file(path, content.encode("utf-8"))


def create_phoenix_gql_builtin(
    *,
    schema: strawberry.Schema,
    build_graphql_context: Callable[[], Context],
    mutation_policy: GraphQLMutationPolicy,
) -> Callable[[BuiltinContext], Awaitable[BuiltinResult]]:
    """Build the ``phoenix-gql`` custom shell command."""
    # The compiled graphql-core schema carries the descriptions and
    # deprecations the index renders; strawberry exposes it only as ``_schema``.
    index = cached_index(schema._schema, include_mutations=mutation_policy.allow_mutations)

    async def phoenix_gql(ctx: BuiltinContext) -> BuiltinResult:
        try:
            if ctx.argv and ctx.argv[0] == "schema":
                flags = list(itertools.islice(ctx.argv, 1, _MAX_ARGS + 1))
                searches, names = _parse_schema_args(flags)
                text = describe(index, search=searches, names=names, budget=_SCHEMA_BUDGET)
                return BuiltinResult(stdout=text + "\n", stderr="", exit_code=0)
            parsed = _parse_args(list(ctx.argv))

            if parsed.show_help:
                return BuiltinResult(
                    stdout=_get_help_text(
                        mutation_policy.allow_mutations,
                        mutation_policy.require_approval,
                    ),
                    stderr="",
                    exit_code=0,
                )

            query = _resolve_query_text(parsed, ctx)

            # Approval asks whether a person sanctioned this call. Only this
            # transport can answer that, so the shared core does not.
            if (
                GraphQLOperationType.MUTATION in operation_types(query)
                and mutation_policy.allow_mutations
                and not mutation_policy.mutations_allowed
            ):
                raise ValueError(
                    "This mutation requires the user's approval, which this "
                    "command did not request. Re-issue the bash call with a "
                    "mutation_description describing the change, so the user "
                    "can approve it before the command runs."
                )

            if parsed.operation_name is None and operation_count(query) > 1:
                raise ValueError(
                    "The document declares several operations; pick one with --operation-name"
                )

            variables = _resolve_variables(parsed, ctx)

            outcome = await execute_operation(
                schema,
                query=query,
                variables=variables,
                context=build_graphql_context(),
                allow_mutations=mutation_policy.allow_mutations,
                operation_name=parsed.operation_name,
            )

            payload: dict[str, Any] = {"data": outcome.data}
            if outcome.errors:
                payload["errors"] = list(outcome.errors)
            graphql_error_text = _format_graphql_errors(outcome.errors) if outcome.errors else ""
            has_only_errors = outcome.failed_outright

            output_payload: Any = outcome.data if parsed.data_only else payload
            serialized_output = json.dumps(output_payload, indent=2, ensure_ascii=False) + "\n"

            if parsed.output_path:
                output_path = _resolve_path(ctx.cwd, parsed.output_path)
                _write_file(ctx, output_path, serialized_output)
                return BuiltinResult(
                    stdout=f"{output_path}\n",
                    stderr=(
                        f"{graphql_error_text}Response written to {output_path}\n"
                        if outcome.errors
                        else ""
                    ),
                    exit_code=1 if has_only_errors else 0,
                )

            return BuiltinResult(
                stdout=serialized_output,
                stderr=graphql_error_text,
                exit_code=1 if has_only_errors else 0,
            )
        except GraphQLRefusal as refusal:
            return BuiltinResult(stdout="", stderr=f"{refusal.message}\n", exit_code=1)
        except Exception as error:
            return BuiltinResult(stdout="", stderr=f"{error}\n", exit_code=1)

    return phoenix_gql


class BashToolResult(TypedDict):
    """Result returned by the ``bash`` tool."""

    command: str
    stdout: str
    stderr: str
    exitCode: int
    durationMs: int
    startedAt: str
    completedAt: str
    stdoutBytes: int
    stderrBytes: int
    stdoutTruncated: bool
    stderrTruncated: bool


def get_bash_tool_error(result: BashToolResult) -> Optional[str]:
    """Returns a span error description for a bash command that exited non-zero."""
    exit_code = result["exitCode"]
    return f"exit code {exit_code}" if exit_code != 0 else None


def _make_custom_builtins(
    *,
    schema: strawberry.Schema,
    build_graphql_context: Callable[[], Context],
    mutation_policy: GraphQLMutationPolicy,
) -> dict[str, Callable[[BuiltinContext], Awaitable[BuiltinResult]]]:
    """Build the custom shell commands installed into every shell instance."""
    return {
        "phoenix-gql": create_phoenix_gql_builtin(
            schema=schema,
            build_graphql_context=build_graphql_context,
            mutation_policy=mutation_policy,
        ),
    }


def _build_shell(
    *,
    schema: strawberry.Schema,
    build_graphql_context: Callable[[], Context],
    mutation_policy: GraphQLMutationPolicy,
    initial_snapshot: Optional[bytes],
) -> Bash:
    """Build the virtual shell, restoring prior session state when available."""
    if initial_snapshot is not None:
        return Bash.from_snapshot(
            initial_snapshot,
            python=False,
            network=None,
            custom_builtins=_make_custom_builtins(
                schema=schema,
                build_graphql_context=build_graphql_context,
                mutation_policy=mutation_policy,
            ),
        )
    shell = Bash(
        python=False,
        network=None,  # network is disabled so curl/wget/http cannot reach the internet
        custom_builtins=_make_custom_builtins(
            schema=schema,
            build_graphql_context=build_graphql_context,
            mutation_policy=mutation_policy,
        ),
    )
    shell.execute_sync_or_throw(f"mkdir -p {WORKSPACE_ROOT} {TMP_ROOT} && cd {WORKSPACE_ROOT}")
    return shell


class BashToolset(FunctionToolset[AgentDepsT], Generic[AgentDepsT]):
    """Toolset exposing a ``bash`` tool backed by a virtual shell."""

    def __init__(
        self,
        *,
        schema: strawberry.Schema,
        build_graphql_context: Callable[[], Context],
        allow_mutations: bool,
        require_mutation_approval: bool,
        initial_snapshot: Optional[bytes] = None,
        on_snapshot: Optional[Callable[[bytes], None]] = None,
    ) -> None:
        mutation_policy = GraphQLMutationPolicy(
            allow_mutations=allow_mutations,
            require_approval=allow_mutations and require_mutation_approval,
        )
        shell = _build_shell(
            schema=schema,
            build_graphql_context=build_graphql_context,
            mutation_policy=mutation_policy,
            initial_snapshot=initial_snapshot,
        )
        # pydantic-ai executes same-turn tool calls concurrently, so multiple
        # bash calls from one model response can enter the closure below at
        # once while sharing the shell and the mutation policy. Each call
        # stamps its own require_approval/approved onto that shared policy, so
        # without this lock one call's approval could be live while another
        # call's unapproved mutation executes. The lock is what makes the
        # policy's enforcement per-call.
        execution_lock = asyncio.Lock()

        async def bash(
            ctx: RunContext[AgentDepsT],
            summary: str,
            command: str,
            mutation_description: Optional[str] = None,
        ) -> BashToolResult:
            async with execution_lock:
                mutation_policy.approved = ctx.tool_call_approved
                if (
                    mutation_description
                    and mutation_policy.require_approval
                    and not ctx.tool_call_approved
                ):
                    raise ApprovalRequired()
                started_at = datetime.now(timezone.utc)
                start = time.monotonic()
                result = await shell.execute(command)
                completed_at = datetime.now(timezone.utc)
                duration_ms = round((time.monotonic() - start) * 1000)
                if on_snapshot is not None:
                    on_snapshot(shell.snapshot())
                result_dict = result.to_dict()
                return {
                    "command": command,
                    "stdout": result.stdout,
                    "stderr": result.stderr,
                    "exitCode": result.exit_code,
                    "durationMs": duration_ms,
                    "startedAt": started_at.isoformat(),
                    "completedAt": completed_at.isoformat(),
                    "stdoutBytes": len(result.stdout.encode("utf-8")),
                    "stderrBytes": len(result.stderr.encode("utf-8")),
                    "stdoutTruncated": result_dict["stdout_truncated"],
                    "stderrTruncated": result_dict["stderr_truncated"],
                }

        super().__init__(
            tools=[
                Tool(
                    bash,
                    takes_ctx=True,
                    name=BASH_TOOL_NAME,
                    description=_BASH_TOOL_DESCRIPTION,
                )
            ]
        )


@dataclass
class BashCapability(AbstractCapability[AgentDepsT], Generic[AgentDepsT]):
    """Capability that adds a ``bash`` toolset."""

    schema: strawberry.Schema
    build_graphql_context: Callable[[], Context]
    allow_mutations: bool = False
    require_mutation_approval: bool = True
    initial_snapshot: Optional[bytes] = None
    on_snapshot: Optional[Callable[[bytes], None]] = None

    def get_toolset(self) -> AgentToolset[AgentDepsT] | None:
        return BashToolset[AgentDepsT](
            schema=self.schema,
            build_graphql_context=self.build_graphql_context,
            allow_mutations=self.allow_mutations,
            require_mutation_approval=self.require_mutation_approval,
            initial_snapshot=self.initial_snapshot,
            on_snapshot=self.on_snapshot,
        )
