"""The conformance suite for Pydantic AI workspace backends.

Subclass `WorkspaceBackendSuite` in a pytest module and provide a `backend` fixture: each test checks
one rule of the `WorkspaceBackend` contract, the same rules the built-in and provider backends pass.
Requires pytest and the anyio pytest plugin.
"""

from __future__ import annotations

import posixpath
import uuid
from collections.abc import AsyncGenerator, AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager, suppress

import anyio
import pytest

from .protocol import (
    SupportsCommands,
    SupportsRealpath,
    WorkspaceBackend,
    WorkspaceRef,
    WorkspaceTimeoutError,
    WorkspaceUnavailableError,
)
from .workspace import Workspace

__all__ = ('WorkspaceBackendSuite',)


def _commands(backend: WorkspaceBackend) -> SupportsCommands:
    if not isinstance(backend, SupportsCommands):
        pytest.skip('backend does not implement SupportsCommands')
    return backend


@asynccontextmanager
async def _scratch_dir(workspace: Workspace) -> AsyncGenerator[str]:
    """A fresh directory under the working directory, removed afterwards."""
    root = posixpath.join(await workspace.working_dir(), f'.pydantic-ai-conformance-{uuid.uuid4().hex}')
    await workspace.make_dir(root)
    try:
        yield root
    finally:
        await workspace.remove(root)


class WorkspaceBackendSuite:
    """Subclass in your test suite and provide the `backend` fixture.

    Each test checks one rule of the backend contract. Command rules skip for a backend without
    `SupportsCommands`; filesystem rules run through [`Workspace`][pydantic_ai.workspaces.Workspace], so a
    command-only backend is checked on the file operations derived through its shell. The reattach
    rules need the optional fixtures below and skip without them.
    """

    pytestmark = pytest.mark.anyio

    @pytest.fixture
    def backend(self) -> WorkspaceBackend | AsyncIterator[WorkspaceBackend]:
        raise NotImplementedError('provide a `backend` fixture')

    @pytest.fixture
    def fresh_backend(self) -> Callable[[], WorkspaceBackend] | None:
        """Build an uninitialized backend to check concurrent first use, if supported."""
        return None

    @pytest.fixture
    def destructive_backend(
        self, fresh_backend: Callable[[], WorkspaceBackend] | None
    ) -> Callable[[], WorkspaceBackend] | None:
        """Build an independent environment for destruction; defaults to `fresh_backend`."""
        return fresh_backend

    @pytest.fixture
    def attach_backend(self) -> Callable[[WorkspaceRef], WorkspaceBackend] | None:
        """Build a second backend that attaches to `ref`. Enables the reattach rules."""
        return None

    @pytest.fixture
    def destroy_environment(self) -> Callable[[WorkspaceBackend], Awaitable[None]] | None:
        """Destroy the environment behind `backend`. Enables the reattach-after-destroy rule."""
        return None

    async def test_has_the_required_members(self, backend: WorkspaceBackend) -> None:
        assert isinstance(backend, WorkspaceBackend)

    async def test_command_form_must_match_shell(self, backend: WorkspaceBackend) -> None:
        """A string needs `shell=True` and an argv sequence needs `shell=False`; a mismatch is a `TypeError`."""
        commands = _commands(backend)
        with pytest.raises(TypeError):
            await commands.run('true')
        with pytest.raises(TypeError):
            await commands.run(['true'], shell=True)

    async def test_stdin_is_at_eof(self, backend: WorkspaceBackend) -> None:
        """Noninteractive commands never wait for input from the caller."""
        # This is a command deadline, not a latency assertion on remote dispatch.
        result = await _commands(backend).run(['sh', '-c', 'read value || printf eof'], timeout=30)
        assert (result.exit_code, result.stdout) == (0, 'eof')

    async def test_undecodable_command_bytes_are_replaced(
        self, backend: WorkspaceBackend, has_real_posix_shell: bool
    ) -> None:
        if not has_real_posix_shell:
            pytest.skip('fake has no command byte stream')
        result = await _commands(backend).run(['sh', '-c', "printf '\\377'; printf '\\376' >&2"])
        assert (result.stdout, result.stderr) == ('\ufffd', '\ufffd')

    async def test_command_output_is_complete(self, backend: WorkspaceBackend) -> None:
        """If output cannot be collected in full, the backend must raise rather than return a truncated success."""
        output = 'workspace' * 1024
        result = await _commands(backend).run(
            ['sh', '-c', 'i=0; while [ "$i" -lt 1024 ]; do printf workspace; printf workspace >&2; i=$((i+1)); done']
        )
        assert (result.exit_code, result.stdout, result.stderr) == (0, output, output)

    @pytest.fixture
    def can_detect_exit_with_inherited_output_pipes(self) -> bool:
        """Override only if the SDK cannot report exit independently of pipe EOF (E2B currently cannot)."""
        return True

    async def test_background_child_does_not_hold_up_completed_command(
        self, backend: WorkspaceBackend, has_real_posix_shell: bool, can_detect_exit_with_inherited_output_pipes: bool
    ) -> None:
        if not has_real_posix_shell or not can_detect_exit_with_inherited_output_pipes:
            pytest.skip('backend cannot observe the direct command exit independently of inherited output pipes')
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            release = posixpath.join(root, 'release')
            finished = posixpath.join(root, 'finished')
            # The background child holds stdout open until released. A backend waiting for
            # pipe EOF cannot complete this run, regardless of control-plane latency.
            command = 'while [ ! -f "$1" ]; do sleep 0.1; done; printf finished > "$2"'
            try:
                with anyio.fail_after(60):  # Hang guard, not an assertion about remote speed.
                    result = await _commands(backend).run(
                        ['sh', '-c', f'({command}) & printf done', 'sh', release, finished]
                    )
                assert (result.exit_code, result.stdout) == (0, 'done')
                assert not await workspace.exists(finished)
            finally:
                # Release the child even if the hang guard cancelled the command.
                with anyio.move_on_after(30, shield=True):
                    await workspace.write_bytes(release, b'go')
                    while not await workspace.exists(finished):
                        await anyio.sleep(0.1)

    async def test_result_reports_exit_code_stdout_and_stderr(self, backend: WorkspaceBackend) -> None:
        """A non-zero exit is a normal result, not an error."""
        result = await _commands(backend).run('printf out; printf err >&2; exit 7', shell=True)
        assert (result.exit_code, result.stdout, result.stderr) == (7, 'out', 'err')

    async def test_a_missing_program_exits_127(self, backend: WorkspaceBackend) -> None:
        """Like `sh`, a program that doesn't exist is a normal result with exit code 127, not an error."""
        result = await _commands(backend).run(['pydantic-ai-conformance-missing-program'])
        assert result.exit_code == 127

    async def test_argv_items_are_literal(self, backend: WorkspaceBackend) -> None:
        payload = ' literal $() `quoted`; && '
        result = await _commands(backend).run(['sh', '-c', 'printf "%s" "$1"', 'sh', payload])
        assert (result.exit_code, result.stdout) == (0, payload)

    async def test_working_dir_is_canonical(self, backend: WorkspaceBackend) -> None:
        """Absolute, symlinks resolved, no `.`/`..`: the directory commands actually start in."""
        working_dir = await backend.working_dir()
        assert posixpath.isabs(working_dir) and posixpath.normpath(working_dir) == working_dir
        if isinstance(backend, SupportsCommands):
            assert (await backend.run(['sh', '-c', 'pwd -P'])).stdout == f'{working_dir}\n'

    async def test_timeout_raises_workspace_timeout_error(self, backend: WorkspaceBackend) -> None:
        with pytest.raises(WorkspaceTimeoutError):
            await _commands(backend).run(['sh', '-c', 'sleep 3600'], timeout=1.0)

    async def test_cancellation_stops_foreground_work(
        self, backend: WorkspaceBackend, has_real_posix_shell: bool
    ) -> None:
        if not has_real_posix_shell:
            pytest.skip('fake has no foreground process to cancel')
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            pid_file = posixpath.join(root, 'pid')

            async def command() -> None:
                await _commands(backend).run(['sh', '-c', 'echo $$ > "$1"; exec sleep 3600', 'sh', pid_file])

            async with anyio.create_task_group() as tg:
                tg.start_soon(command)
                with anyio.fail_after(30):
                    while not await workspace.exists(pid_file):
                        await anyio.sleep(0.05)
                tg.cancel_scope.cancel()
            pid = (await workspace.read_text(pid_file)).strip()
            with anyio.fail_after(60):
                while (await _commands(backend).run(['sh', '-c', 'kill -0 "$1"', 'sh', pid])).exit_code == 0:
                    await anyio.sleep(0.05)  # pragma: lax no cover - depends on how fast the process dies

    async def test_env_is_added(self, backend: WorkspaceBackend) -> None:
        result = await _commands(backend).run(['sh', '-c', 'printf %s "$CONFORMANCE"'], env={'CONFORMANCE': 'value'})
        assert result.stdout == 'value'

    async def test_ref_exists_after_the_first_operation_and_is_stable(self, backend: WorkspaceBackend) -> None:
        before = backend.ref
        await backend.working_dir()
        created = backend.ref
        await backend.working_dir()
        assert isinstance(created, WorkspaceRef) and backend.ref == created
        assert before in (None, created)

    async def test_concurrent_first_use_shares_one_environment(
        self, fresh_backend: Callable[[], WorkspaceBackend] | None
    ) -> None:
        if fresh_backend is None:
            pytest.skip('backend does not provide a fresh_backend factory')
        backend = fresh_backend()
        assert backend.ref is None
        workspace = Workspace(backend)
        paths = [f'concurrent-{uuid.uuid4().hex}' for _ in range(5)]

        async def write(path: str) -> None:
            await workspace.write_bytes(path, path.encode())

        try:
            async with anyio.create_task_group() as group:
                for path in paths:
                    group.start_soon(write, path)
            ref = backend.ref
            assert isinstance(ref, WorkspaceRef)
            for path in paths:
                assert await workspace.read_bytes(path) == path.encode()
                assert backend.ref == ref
        finally:
            for path in paths:
                with suppress(FileNotFoundError):
                    await workspace.remove(path)

    async def test_large_file_round_trip(self, backend: WorkspaceBackend) -> None:
        """A shell-derived filesystem must page reads rather than hit a command-output cap."""
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            path = posixpath.join(root, 'large.bin')
            data = b'x' * (8 * 1024 * 1024)
            await workspace.write_bytes(path, data)
            assert await workspace.read_bytes(path) == data

    async def test_bytes_round_trip_and_write_creates_parents(self, backend: WorkspaceBackend) -> None:
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            path = posixpath.join(root, 'nested', 'data.bin')
            await workspace.write_bytes(path, b'\x00workspace\xff')
            assert await workspace.read_bytes(path) == b'\x00workspace\xff'
            await workspace.write_bytes(path, b'replaced')
            assert await workspace.read_bytes(path) == b'replaced'

    async def test_exists(self, backend: WorkspaceBackend) -> None:
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            await workspace.write_bytes(posixpath.join(root, 'file'), b'data')
            assert await workspace.exists(posixpath.join(root, 'file'))
            assert await workspace.exists(root)
            assert not await workspace.exists(posixpath.join(root, 'absent'))

    async def test_stat_and_list_dir(self, backend: WorkspaceBackend) -> None:
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            child = posixpath.join(root, 'child')
            path = posixpath.join(child, 'data.bin')
            await workspace.write_bytes(path, b'data')
            file_entry = await workspace.stat(path)
            assert (file_entry.name, file_entry.path, file_entry.is_dir) == ('data.bin', path, False)
            assert file_entry.size in (None, 4)
            dir_entry = await workspace.stat(child)
            assert (dir_entry.name, dir_entry.path, dir_entry.is_dir) == ('child', child, True)
            entries = await workspace.list_dir(root)
            assert [(entry.name, entry.path, entry.is_dir) for entry in entries] == [('child', child, True)]

    async def test_make_dir_creates_parents_and_is_idempotent(self, backend: WorkspaceBackend) -> None:
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            path = posixpath.join(root, 'a', 'b')
            await workspace.make_dir(path)
            await workspace.make_dir(path)
            assert (await workspace.stat(path)).is_dir

    async def test_commands_and_files_share_one_environment(self, backend: WorkspaceBackend) -> None:
        commands = _commands(backend)
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            path = posixpath.join(root, 'shared.txt')
            await workspace.write_bytes(path, b'in\n')
            script = 'IFS= read -r value < "$1" && [ "$value" = in ] && printf "out\\n" > "$1"'
            assert (await commands.run(['sh', '-c', script, 'sh', path])).exit_code == 0
            assert await workspace.read_bytes(path) == b'out\n'

    async def test_missing_paths_raise_file_not_found(self, backend: WorkspaceBackend) -> None:
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            missing = posixpath.join(root, 'missing')
            for operation in (workspace.read_bytes, workspace.stat, workspace.list_dir, workspace.remove):
                with pytest.raises(FileNotFoundError):
                    await operation(missing)

    async def test_reading_a_directory_raises_is_a_directory(self, backend: WorkspaceBackend) -> None:
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            with pytest.raises(IsADirectoryError):
                await workspace.read_bytes(root)

    async def test_listing_a_file_raises_not_a_directory(self, backend: WorkspaceBackend) -> None:
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            file = posixpath.join(root, 'file')
            await workspace.write_bytes(file, b'x')
            with pytest.raises(NotADirectoryError):
                await workspace.list_dir(file)

    async def test_writing_to_a_directory_raises_is_a_directory(self, backend: WorkspaceBackend) -> None:
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            with pytest.raises(IsADirectoryError):
                await workspace.write_bytes(root, b'data')

    @pytest.fixture
    def has_real_posix_shell(self) -> bool:
        """Only a test double with no POSIX process/filesystem can opt out."""
        return True

    async def test_symlink_loop_does_not_break_listing(
        self, backend: WorkspaceBackend, has_real_posix_shell: bool
    ) -> None:
        if not has_real_posix_shell:
            pytest.skip('in-memory fake cannot create symlinks')
        commands = _commands(backend)
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            loop = posixpath.join(root, 'loop')
            if (await commands.run(['ln', '-s', 'loop', loop])).exit_code != 0:
                pytest.skip('the environment cannot create symlinks with `ln -s`')  # pragma: no cover
            entries = await workspace.list_dir(root)
            assert [(entry.name, entry.is_dir) for entry in entries] == [('loop', False)]

    async def test_fifo_read_does_not_wait_for_writer(
        self, backend: WorkspaceBackend, has_real_posix_shell: bool
    ) -> None:
        if not has_real_posix_shell:
            pytest.skip('in-memory fake cannot create FIFOs')
        commands = _commands(backend)
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            fifo = posixpath.join(root, 'fifo')
            if (await commands.run(['mkfifo', fifo])).exit_code != 0:
                pytest.skip('the environment does not provide `mkfifo`')  # pragma: no cover
            with anyio.fail_after(30):
                with pytest.raises(OSError):
                    await workspace.read_bytes(fifo)

    @pytest.fixture
    def enforces_parent_file_errors(self) -> bool:
        """Opt out only for an in-memory test double without real path traversal."""
        return True

    @pytest.fixture
    def filesystem_honors_shell_permissions(self) -> bool:
        """Override only for provider file APIs that bypass the command user's permissions (e.g. E2B envd)."""
        return True

    async def test_permission_denied_uses_builtin_error(
        self, backend: WorkspaceBackend, has_real_posix_shell: bool, filesystem_honors_shell_permissions: bool
    ) -> None:
        if not has_real_posix_shell or not filesystem_honors_shell_permissions:
            pytest.skip('in-memory fake has no permissions')
        commands = _commands(backend)
        if (await commands.run(['id', '-u'])).stdout.strip() == '0':
            pytest.skip('root bypasses filesystem permissions')  # pragma: no cover
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            file = posixpath.join(root, 'unreadable')
            await workspace.write_bytes(file, b'data')
            assert (await commands.run(['chmod', '000', file])).exit_code == 0
            with pytest.raises(PermissionError):
                await workspace.read_bytes(file)
            with pytest.raises(PermissionError):
                await workspace.write_bytes(file, b'changed')

    async def test_file_as_parent_raises_not_a_directory(
        self, backend: WorkspaceBackend, enforces_parent_file_errors: bool
    ) -> None:
        if not enforces_parent_file_errors:
            pytest.skip('in-memory fake has no real path traversal')
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            file = posixpath.join(root, 'file')
            await workspace.write_bytes(file, b'data')
            with pytest.raises(NotADirectoryError):
                await workspace.write_bytes(posixpath.join(file, 'child'), b'data')
            with pytest.raises(NotADirectoryError):
                await workspace.make_dir(posixpath.join(file, 'child'))

    async def test_making_a_directory_over_a_file_raises_file_exists(self, backend: WorkspaceBackend) -> None:
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            path = posixpath.join(root, 'file')
            await workspace.write_bytes(path, b'data')
            with pytest.raises(FileExistsError):
                await workspace.make_dir(path)

    async def test_remove_deletes_a_file_or_a_tree(self, backend: WorkspaceBackend) -> None:
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            file, tree = posixpath.join(root, 'file'), posixpath.join(root, 'tree')
            await workspace.write_bytes(file, b'x')
            await workspace.write_bytes(posixpath.join(tree, 'nested', 'file'), b'x')
            await workspace.remove(file)
            await workspace.remove(tree)
            assert not await workspace.exists(file) and not await workspace.exists(tree)

    async def test_remove_refuses_the_working_dir_and_its_ancestors(self, backend: WorkspaceBackend) -> None:
        # A model asking to remove `.` must not wipe the environment it works in.
        workspace = Workspace(backend)
        working_dir = await workspace.working_dir()
        for path in ('.', working_dir, posixpath.dirname(working_dir), '/'):
            with pytest.raises(ValueError):
                await workspace.remove(path)
        assert await workspace.exists(working_dir)

    async def test_realpath_and_entries_follow_symlinks(self, backend: WorkspaceBackend) -> None:
        commands = _commands(backend)
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            target, link = posixpath.join(root, 'target'), posixpath.join(root, 'link')
            await workspace.make_dir(target)
            if (await commands.run(['ln', '-s', target, link])).exit_code != 0 or not await workspace.exists(link):
                pytest.skip('the environment cannot create symlinks with `ln -s`')  # pragma: no cover
            assert await workspace.realpath(posixpath.join(link, 'missing')) == posixpath.join(target, 'missing')
            a = posixpath.join(root, 'a')
            await workspace.make_dir(a)
            await workspace.make_dir(posixpath.join(a, 'b'))
            for name, target_name in (('rel', 'b'), ('up', '../out'), ('loop1', 'loop2'), ('loop2', 'loop1')):
                result = await commands.run(['ln', '-s', target_name, posixpath.join(a, name)])
                assert result.exit_code == 0
            assert await workspace.realpath(posixpath.join(a, 'rel', 'missing')) == posixpath.join(a, 'b', 'missing')
            assert await workspace.realpath(posixpath.join(a, 'up', 'missing')) == posixpath.join(
                root, 'out', 'missing'
            )
            assert await workspace.realpath(posixpath.join(a, 'rel', '..')) == a
            assert await workspace.realpath(posixpath.join(a, 'up', '..')) == root
            with anyio.fail_after(30):
                try:
                    loop_path = await workspace.realpath(posixpath.join(a, 'loop1', 'q'))
                except OSError:
                    pass
                else:
                    assert loop_path.startswith(a + '/')
            assert (await workspace.stat(link)).is_dir
            assert {entry.name: entry.is_dir for entry in await workspace.list_dir(root)} == {
                'a': True,
                'link': True,
                'target': True,
            }

    async def test_writes_go_through_a_symlink(self, backend: WorkspaceBackend) -> None:
        commands = _commands(backend)
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            target, link = posixpath.join(root, 'target'), posixpath.join(root, 'link')
            await workspace.write_bytes(target, b'old')
            if (await commands.run(['ln', '-s', target, link])).exit_code != 0 or not await workspace.exists(link):
                pytest.skip('the environment cannot create symlinks with `ln -s`')  # pragma: no cover
            await workspace.write_bytes(link, b'new')
            assert await workspace.read_bytes(target) == b'new'
            assert await workspace.realpath(link) == target

    async def test_native_realpath_keeps_the_working_dir_and_missing_names(self, backend: WorkspaceBackend) -> None:
        """Checked without commands, so a filesystem-only backend's `realpath` is covered too."""
        if not isinstance(backend, SupportsRealpath):
            pytest.skip('backend does not implement SupportsRealpath')
        working_dir = await backend.working_dir()
        assert await backend.realpath(working_dir) == working_dir
        missing = posixpath.join(working_dir, f'.pydantic-ai-conformance-missing-{uuid.uuid4().hex}')
        assert await backend.realpath(missing) == missing

    async def test_a_backend_attached_by_ref_reaches_the_same_environment(
        self, backend: WorkspaceBackend, attach_backend: Callable[[WorkspaceRef], WorkspaceBackend] | None
    ) -> None:
        """Durable execution rebuilds the backend from its ref for every call, so this is what it relies on."""
        if attach_backend is None:
            pytest.skip('provide the `attach_backend` fixture to enable this rule')
        workspace = Workspace(backend)
        async with _scratch_dir(workspace) as root:
            path = posixpath.join(root, 'file')
            await workspace.write_bytes(path, b'reattached')
            ref = backend.ref
            assert ref is not None
            attached = attach_backend(ref)
            assert await Workspace(attached).read_bytes(path) == b'reattached'
            if isinstance(attached, SupportsCommands):
                assert (await attached.run(['cat', path])).stdout == 'reattached'
            # Attaching never replaces the environment it names.
            assert attached.ref == ref

    async def test_destroying_environment_during_command_raises_unavailable(
        self,
        destructive_backend: Callable[[], WorkspaceBackend] | None,
        destroy_environment: Callable[[WorkspaceBackend], Awaitable[None]] | None,
        has_real_posix_shell: bool,
    ) -> None:
        if destructive_backend is None or destroy_environment is None:
            pytest.skip('provide `destructive_backend` and `destroy_environment` to enable this rule')
        if not has_real_posix_shell:
            pytest.skip('backend has no running POSIX command to interrupt')
        backend = destructive_backend()
        commands = _commands(backend)
        workspace = Workspace(backend)
        root = await backend.working_dir()
        started = posixpath.join(root, f'.pydantic-ai-started-{uuid.uuid4().hex}')

        async def run_command() -> None:
            with pytest.raises(WorkspaceUnavailableError):
                # A local directory deletion does not kill a process already inside it; exit when
                # the directory disappears so the rule also checks the result classification.
                await commands.run(
                    ['sh', '-c', 'printf ready > "$1"; while [ -d "$2" ]; do sleep 0.1; done', 'sh', started, root],
                    timeout=30,
                )

        async with anyio.create_task_group() as group:
            group.start_soon(run_command)
            with anyio.fail_after(30):
                while not await workspace.exists(started):
                    await anyio.sleep(0.05)
            await destroy_environment(backend)

    async def test_attaching_to_a_destroyed_environment_raises_unavailable(
        self,
        destructive_backend: Callable[[], WorkspaceBackend] | None,
        attach_backend: Callable[[WorkspaceRef], WorkspaceBackend] | None,
        destroy_environment: Callable[[WorkspaceBackend], Awaitable[None]] | None,
    ) -> None:
        if destructive_backend is None or attach_backend is None or destroy_environment is None:
            pytest.skip('provide `destructive_backend`, `attach_backend` and `destroy_environment` to enable this rule')
        # Never destroy the shared backend fixture: other rules may run after this one.
        backend = destructive_backend()
        await backend.working_dir()
        assert backend.ref is not None
        await destroy_environment(backend)
        with pytest.raises(WorkspaceUnavailableError):
            await attach_backend(backend.ref).working_dir()
