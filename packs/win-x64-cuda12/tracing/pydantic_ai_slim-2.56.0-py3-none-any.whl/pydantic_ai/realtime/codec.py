"""Low-level *codec* vocabulary for realtime providers.

Most users only need the session-level API in [`pydantic_ai.realtime`][pydantic_ai.realtime]
([`AgentRealtime.session`][pydantic_ai.agent.AgentRealtime.session], the events a session yields,
and the content passed to [`RealtimeSession.send`][pydantic_ai.realtime.RealtimeSession.send]). This
submodule holds the lower-level vocabulary used when *implementing* a realtime provider or consuming a
[`RealtimeConnection`][pydantic_ai.realtime.codec.RealtimeConnection] directly: the raw codec events a
connection yields to the session, the turn-control verbs and inputs a connection accepts, and the
model-profile merge helpers.
"""

from __future__ import annotations as _annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator, Callable, Sequence
from dataclasses import KW_ONLY, dataclass
from typing import Any, ClassVar, Literal

from typing_extensions import TypeAliasType

from .. import _utils
from ..messages import (
    BinaryAudio,
    BinaryContent,
    BinaryImage,
    FinishReason,
    ModelMessage,
    PartEndEvent,
    PartStartEvent,
    RealtimeInputSpeechEndEvent,
    RealtimeInputSpeechStartEvent,
    RealtimeInputTranscriptionErrorEvent,
    RealtimeOutputSpeechEndEvent,
    RealtimeOutputSpeechStartEvent,
    RealtimeResponseInterruptedEvent,
    RealtimeSessionErrorEvent,
    RealtimeSessionReconnectEvent,
    UserContent,
)
from ..usage import RequestUsage
from ._lifecycle import LifecycleEvent, TaggedEvent
from .profiles import DEFAULT_AUDIO_SAMPLE_RATE, DEFAULT_REALTIME_PROFILE, merge_realtime_profile

# Input content types (fed into the connection via `send`). Session content reuses the shared message
# vocabulary — `str` for a text turn, `BinaryAudio`/`BinaryImage` from `pydantic_ai.messages` for
# audio and image frames — so only the wire-level `ToolResult` and the turn-control verbs are
# codec-specific types.


@dataclass(repr=False)
class ToolResult:
    """The result of a tool call, rendered for the wire and sent back to the model.

    Built and sent by [`RealtimeSession`][pydantic_ai.realtime.RealtimeSession] after it settles a
    call: the string-only realtime tool channel and the retry/failure error-key wrapping mean the
    session renders the [`ToolReturnPart`][pydantic_ai.messages.ToolReturnPart] or
    [`RetryPromptPart`][pydantic_ai.messages.RetryPromptPart] it records in history down to this flat
    shape, so every provider sends exactly the same rendering.
    """

    tool_call_id: str
    """Identifier of the `ToolCall` this result answers."""
    _: KW_ONLY
    output: str
    """The tool's output, rendered as a string."""
    content: Sequence[UserContent] | None = None
    """Additional user content to send after the tool output when the provider supports it."""

    __repr__ = _utils.dataclasses_no_defaults_repr


@dataclass
class TextContext:
    """A text item added to the conversation as context, without asking the model to respond (like an image)."""

    text: str


@dataclass
class CommitAudio:
    """Commit the buffered input audio as a user turn (manual turn-taking / push-to-talk).

    Only needed when automatic voice activity detection is disabled; with server-side VAD the
    provider commits audio and triggers a response automatically.
    """


@dataclass
class ClearAudio:
    """Discard any buffered, uncommitted input audio."""


@dataclass
class CreateResponse:
    """Ask the model to generate a response now (manual turn-taking, after `CommitAudio`)."""


@dataclass
class CancelResponse:
    """Cancel the model's in-progress response (maps to the provider's response-cancel)."""


@dataclass(repr=False)
class TruncateOutput:
    """Truncate the model's current audio output at `audio_end_ms`.

    After a barge-in the user only heard part of the model's audio. Truncating tells the provider how
    much was actually played, so its stored transcript matches and the conversation context stays
    consistent. The provider resolves which output item to truncate from its own state unless
    `item_id` names one.
    """

    audio_end_ms: int
    """Milliseconds of the output audio that were actually played before the interruption."""

    _: KW_ONLY
    item_id: str | None = None
    """The output item to truncate, when it isn't the provider's current one — a reply the listener was
    still hearing after a newer one was generated. `None` truncates the current output item."""

    __repr__ = _utils.dataclasses_no_defaults_repr


RealtimeSessionInput = TypeAliasType('RealtimeSessionInput', 'str | BinaryContent')
"""The content types a caller feeds into [`RealtimeSession.send`][pydantic_ai.realtime.RealtimeSession.send].

Session content only, in the shared message vocabulary: a `str` is a complete text turn, and
[`BinaryContent`][pydantic_ai.messages.BinaryContent] carries an image frame, WAV audio (unwrapped to
raw PCM before it is streamed, matching the history-seeding path), or a raw PCM chunk
(`media_type='audio/pcm'`). The session normalizes these before forwarding them to the connection.
Turn-control verbs (`CommitAudio`, `ClearAudio`, `CreateResponse`, `CancelResponse`,
`TruncateOutput`) are connection-level vocabulary driven through the dedicated `RealtimeSession`
methods (`commit_audio()`, `clear_audio()`, `create_response()`, `interrupt()`), and
[`ToolResult`][pydantic_ai.realtime.codec.ToolResult] is sent by the session itself when a tool
completes — neither is accepted by `send()`.
"""

RealtimeInput = TypeAliasType(
    'RealtimeInput',
    'str | TextContext | BinaryAudio | BinaryImage | CommitAudio | ClearAudio | CreateResponse | CancelResponse | TruncateOutput | ToolResult',
)
"""Union of content types accepted by [`RealtimeConnection.send`][pydantic_ai.realtime.codec.RealtimeConnection.send].

The connection-level counterpart of [`RealtimeSessionInput`][pydantic_ai.realtime.RealtimeSessionInput],
already normalized: a `str` is a complete text turn that solicits a response,
[`TextContext`][pydantic_ai.realtime.codec.TextContext] is text added without soliciting a response, a
[`BinaryAudio`][pydantic_ai.messages.BinaryAudio] carries a raw mono PCM16 chunk at the model's
[`audio_input_sample_rate`][pydantic_ai.realtime.RealtimeSession.audio_input_sample_rate]
(`media_type='audio/pcm'`), and a [`BinaryImage`][pydantic_ai.messages.BinaryImage] an image frame.
The connection additionally accepts the turn-control verbs and
[`ToolResult`][pydantic_ai.realtime.codec.ToolResult], which
[`RealtimeSession`][pydantic_ai.realtime.RealtimeSession] sends on the caller's behalf.
"""


# Connection-level events (yielded by `RealtimeConnection.__aiter__`).


@dataclass(repr=False)
class AudioDelta:
    """A chunk of audio output from the model."""

    data: bytes
    """Raw PCM audio bytes. The sample rate is provider-specific."""
    _: KW_ONLY
    item_id: str | None = None
    """Provider item ID for the spoken output this chunk belongs to, when available."""
    response_id: str | None = None
    """Provider ID of the response this belongs to, when available.

    Lets the session name a reply that never gets the terminal that would otherwise carry its ID, such
    as one cut off by a dropped connection or by closing the session.
    """

    __repr__ = _utils.dataclasses_no_defaults_repr


@dataclass(repr=False)
class OutputTranscript:
    """The model's textual output (partial or final): an audio transcript, or plain text output."""

    text: str
    """Transcript text. A partial event carries the incremental delta; a final event the full turn."""
    _: KW_ONLY
    is_final: bool = False
    """Whether this is the final transcript for the turn."""
    output_text: bool = False
    """Whether this is the model's plain text output (`output_modalities=('text',)`) rather than a
    transcription of spoken audio. Text output becomes a [`TextPart`][pydantic_ai.messages.TextPart];
    an audio transcript becomes a [`SpeechPart`][pydantic_ai.messages.SpeechPart]."""
    item_id: str | None = None
    """Provider item ID for the spoken output, when available."""
    response_id: str | None = None
    """Provider ID of the response this belongs to, when available.

    Lets the session name a reply that never gets the terminal that would otherwise carry its ID, such
    as one cut off by a dropped connection or by closing the session.
    """

    __repr__ = _utils.dataclasses_no_defaults_repr


@dataclass(repr=False)
class InputTranscript:
    """A transcription of the user's audio input (partial or final).

    Providers with per-item IDs use `item_id` to associate interleaved transcripts with the correct
    user turn. Providers without them retain arrival-order association.
    """

    text: str
    """Transcript text."""
    _: KW_ONLY
    is_final: bool = False
    """Whether this is the final transcript for the user's turn."""
    item_id: str | None = None
    """Provider item ID for the user's turn, when available."""
    cumulative: bool = False
    """Whether `text` is the whole transcript so far rather than an incremental piece.

    Speech recognition is revisable, and a provider that streams cumulative snapshots may correct
    what it already transcribed instead of only extending it. Setting this lets the session adopt
    each snapshot as authoritative rather than guessing from prefixes whether the text appends;
    it surfaces the difference to callers as a
    [`SpeechPartDelta.transcript`][pydantic_ai.messages.SpeechPartDelta.transcript] carrying the
    corrected whole. Leave `False` for incremental deltas.
    """

    __repr__ = _utils.dataclasses_no_defaults_repr


@dataclass(repr=False)
class ToolCall:
    """The model is requesting a tool call."""

    tool_call_id: str
    """Provider-assigned identifier for this call."""
    _: KW_ONLY
    tool_name: str
    """Name of the tool to invoke."""
    args: str
    """Raw JSON-encoded arguments. May be an empty string if the model sent no arguments."""
    response_usage_follows: bool = False
    """Whether per-response [`SessionUsage`][pydantic_ai.realtime.codec.SessionUsage] will follow
    this call before the provider's response is complete.

    OpenAI-protocol providers report calls before `response.done`, which carries usage; the session
    uses this signal to keep all calls and their usage on the same `ModelResponse`."""
    item_id: str | None = None
    """Provider conversation-item ID for this call, when available."""
    response_id: str | None = None
    """Provider ID of the response this belongs to, when available.

    Lets the session name a reply that never gets the terminal that would otherwise carry its ID, such
    as one cut off by a dropped connection or by closing the session.
    """

    __repr__ = _utils.dataclasses_no_defaults_repr


@dataclass(repr=False)
class ToolCallCancelled:
    """The model cancelled in-flight tool calls (e.g. the user barged in before they finished).

    Gemini Live sends this as `toolCallCancellation`; the session cancels the matching running tool
    tasks so their now-unwanted results are never sent back to the model.
    """

    tool_call_ids: list[str]
    """Identifiers of the [`ToolCall`][pydantic_ai.realtime.codec.ToolCall]s that were cancelled."""

    __repr__ = _utils.dataclasses_no_defaults_repr


@dataclass(repr=False)
class ResponseDone:
    """The provider reported that its current response is done.

    This codec event is consumed by the session to finalize a
    [`ModelResponse`][pydantic_ai.messages.ModelResponse]. Providers do not necessarily report a
    terminal for every model response the session records in history.
    """

    _: KW_ONLY
    interrupted: bool = False
    """Whether the response ended because it was cancelled (e.g. the user barged in)."""

    provider_response_id: str | None = None
    """Provider-assigned ID for the completed response, when available."""

    finish_reason: FinishReason | None = None
    """Normalized reason the provider finished the response, when available."""

    provider_details: dict[str, Any] | None = None
    """Raw provider terminal status details retained on the finalized response, when available."""

    more_expected: bool = False
    """Whether the provider said this response is *not* the last of the exchange.

    The session works out for itself that a response calling a tool will be followed by another, but a
    model that reasons in the background can finish a response, keep working, and speak again with no
    tool call in between: `gemini-3.8-live-extended-thinking` speaks a filler ("Let me check those
    flights"), ends the turn, and only then issues the tool call. Left unsaid, that filler would
    synthesize a [`RealtimeTurnCompleteEvent`][pydantic_ai.messages.RealtimeTurnCompleteEvent] claiming
    the exchange was over while the model was still working on it.
    """

    event_kind: Literal['response_done'] = 'response_done'
    """Event type identifier, used as a discriminator."""

    __repr__ = _utils.dataclasses_no_defaults_repr


@dataclass(repr=False)
class SessionUsage:
    """Usage reported by the provider for a model response or another run-level operation."""

    usage: RequestUsage
    """Normalized usage ready to accumulate into a `RunUsage`."""

    _: KW_ONLY
    provider_response_id: str | None = None
    """Provider-assigned ID for the response this usage belongs to, when available."""

    finish_reason: FinishReason | None = None
    """Normalized completion reason for the response this usage belongs to, when available."""

    provider_details: dict[str, Any] | None = None
    """Provider-specific details about how this usage was incurred, merged into the response's
    `ModelResponse.provider_details`. Only applies to response-scoped usage."""

    response_scoped: bool = True
    """Whether this usage belongs to a specific model response.

    `True`, the default, accumulates it both into the run total and the response's
    `ModelResponse.usage`. `False` is run-level only, e.g. input audio transcription usage,
    which is billed on a separate model/meter and is accumulated into the run's `RunUsage`
    but attributed to no `ModelResponse`.
    """

    context_window_used: float | None = None
    """The fraction of the model's context window in use, when the provider reports it.

    A snapshot rather than an amount to accumulate: the session keeps the latest reported value and
    exposes it as [`RealtimeSession.context_window_used`][pydantic_ai.realtime.RealtimeSession.context_window_used].
    It can go down after the provider compacts or truncates the conversation. `None`, the default,
    means this report says nothing about the context window.
    """

    event_kind: Literal['session_usage'] = 'session_usage'
    """Event type identifier, used as a discriminator."""

    __repr__ = _utils.dataclasses_no_defaults_repr


@dataclass(repr=False)
class ConversationCreated:
    """An OpenAI-protocol server assigned a conversation ID.

    This is a codec-level control event. Providers consume it during their handshake when possible;
    the session silently consumes any instance that reaches the live stream.
    """

    conversation_id: str
    """Provider-assigned conversation ID."""

    __repr__ = _utils.dataclasses_no_defaults_repr


@dataclass(repr=False)
class ConversationItemCreated:
    """An OpenAI-protocol server reported a conversation item.

    A connection that resumes a provider-side conversation marks the items the provider replays into it
    with `replayed=True`. The session consumes those items and remembers their newly assigned IDs so any
    follow-on content or tool events aren't appended or executed again.
    """

    _: KW_ONLY
    item_id: str | None = None
    """Provider-assigned conversation-item ID, when present."""
    tool_call_id: str | None = None
    """Provider-assigned tool-call ID, for function call and result items."""
    replayed: bool = False
    """Whether the provider identified this item as part of a resumption replay."""

    __repr__ = _utils.dataclasses_no_defaults_repr


@dataclass(repr=False)
class InputRejected:
    """The provider refused part of an input this connection was sent, so it had no effect.

    Yielded just ahead of the [`RealtimeSessionErrorEvent`][pydantic_ai.realtime.RealtimeSessionErrorEvent]
    that explains the refusal, and only when the provider's error identifies the frame it refused (the
    OpenAI protocol echoes the client `event_id`). A connection that can't tell which input an error was
    about yields the error alone. A reconnect whose new session no longer has an input (Gemini resumes
    from a handle that can predate a typed turn) yields it too, ahead of the
    [`RealtimeSessionReconnectEvent`][pydantic_ai.realtime.RealtimeSessionReconnectEvent]. The session
    uses it to take back what it assumed the input did: a
    refused request for a response releases the reply
    [`wait_for_reply()`][pydantic_ai.realtime.RealtimeSession.wait_for_reply] would otherwise wait for
    forever, and refused content is removed from history.
    """

    input_index: int
    """Zero-based position of the refused input among every [`send`][pydantic_ai.realtime.codec.RealtimeConnection.send] call made on this connection, including calls that raised."""
    _: KW_ONLY
    refused: Literal['content', 'response']
    """What was refused: `'content'` when the input never joined the conversation, `'response'` when the response it asked for will never come."""

    __repr__ = _utils.dataclasses_no_defaults_repr


RealtimeCodecEvent = TypeAliasType(
    'RealtimeCodecEvent',
    AudioDelta
    | OutputTranscript
    | InputTranscript
    | ToolCall
    | ToolCallCancelled
    | ResponseDone
    | RealtimeInputSpeechStartEvent
    | RealtimeResponseInterruptedEvent
    | RealtimeInputSpeechEndEvent
    | RealtimeOutputSpeechStartEvent
    | RealtimeOutputSpeechEndEvent
    | RealtimeInputTranscriptionErrorEvent
    | SessionUsage
    | RealtimeSessionReconnectEvent
    | ConversationCreated
    | ConversationItemCreated
    | InputRejected
    | PartStartEvent
    | PartEndEvent
    | RealtimeSessionErrorEvent,
)
"""Union of the low-level codec events yielded by [`RealtimeConnection`][pydantic_ai.realtime.codec.RealtimeConnection].

This is the provider-facing vocabulary: providers translate their wire protocol into these events, and
[`RealtimeSession`][pydantic_ai.realtime.RealtimeSession] translates them again into the shared
[`RealtimeEvent`][pydantic_ai.realtime.RealtimeEvent] vocabulary while building
[`ModelMessage`][pydantic_ai.messages.ModelMessage] history.
"""


class RealtimeConnection(ABC):
    """A live connection to a realtime model.

    Providers implement this to handle protocol-specific framing (WebSocket frames,
    HTTP/2 messages, etc.). Content is fed in via [`send`][pydantic_ai.realtime.codec.RealtimeConnection.send]
    and events are consumed by iterating the connection.
    """

    transport_errors: ClassVar[tuple[type[Exception], ...]] = ()
    """The exception types this connection's transport raises when the link to the provider fails.

    A [`RealtimeSession`][pydantic_ai.realtime.RealtimeSession] maps these to
    [`RealtimeError`][pydantic_ai.realtime.RealtimeError] so a failed send surfaces as the same typed
    error as a failed receive, instead of leaking a `websockets` or provider-SDK exception the caller
    has no reason to expect from a model call. Leave empty if `send` already raises typed errors.

    The mapping covers the whole of [`send`][pydantic_ai.realtime.codec.RealtimeConnection.send], so
    anything it does *besides* writing to the transport — converting content, downloading media —
    must not raise these types, or a local failure would be reported as a lost connection. Do that
    work before the first frame goes out.
    """

    @abstractmethod
    async def send(self, content: RealtimeInput) -> None:
        """Feed content into the session.

        Concrete connections accept provider-specific data and control inputs. OpenAI accepts audio,
        text, images, tool results, manual turn controls, cancellation, and truncation; Gemini accepts
        audio, text, images, and tool results. A high-level
        [`RealtimeSession`][pydantic_ai.realtime.RealtimeSession] checks profile-gated operations and
        raises [`UserError`][pydantic_ai.exceptions.UserError], as does a connection handed an input it
        can't send.
        """
        raise NotImplementedError

    @abstractmethod
    def __aiter__(self) -> AsyncIterator[RealtimeCodecEvent]:
        """Iterate over events received from the model."""
        raise NotImplementedError

    _lifecycle_version: ClassVar[int] = 1
    """Which version of the lifecycle contract this connection's events follow (see `_lifecycle.py`).

    Version 1 is the codec vocabulary alone. A connection on version 2 also yields identified lifecycle
    events from `_lifecycle_events()`.
    """

    async def _tagged_frames(self) -> AsyncIterator[list[TaggedEvent]]:
        """Every event, codec and lifecycle alike, a frame at a time, each with whether it is stale.

        A frame is what one provider message (or one transition of the connection's own, such as a
        reconnect) makes, so a consumer can apply it whole. A stale event is a codec event about a response
        that has already ended (a repeated or late terminal, content trailing it): the codec stream
        (`__aiter__`) carries it, the lifecycle stream (`_lifecycle_events()`) leaves it out. A version 1
        connection has no lifecycle events and no stale ones: each codec event is a frame of its own.
        """
        async for event in self:
            yield [(event, False)]

    async def _lifecycle_events(self) -> AsyncIterator[RealtimeCodecEvent | LifecycleEvent]:
        """Iterate over the codec events together with the lifecycle events, on a version 2 connection."""
        async for frame in self._tagged_frames():
            for event, stale in frame:
                if not stale:
                    yield event

    async def _end_session(self) -> AsyncIterator[SessionUsage]:
        """End the provider session, yielding the usage the provider reports only as it ends.

        A private seam until the realtime session refactor gives closing a lifecycle of its own.

        The session iterates this once while closing, after
        it has stopped reading the connection and before it reports the session's usage, whenever the
        session owns the provider session (not on a WebRTC sideband, where ending it would end the browser's
        call). A provider that already ended the session, or went away, has nothing more to ask: yield what
        it reported that the session hasn't taken yet, if anything. Only session-scoped usage belongs here:
        there is no response left to attribute anything else to.

        The session bounds how long it iterates, and stops at a transport error; everything yielded until
        then is recorded. It skips this when the session is closing because it was cancelled.

        The default yields nothing, for providers that report all usage as it happens or that end the
        session by closing the transport.
        """
        return
        yield  # pragma: no cover

    @property
    def model_name(self) -> str | None:
        """The model id the server reported serving this session, when the provider reports one.

        Captured from the connect handshake (e.g. the OpenAI protocol's `session.created`). It can
        differ from the requested model id: xAI accepts any model slug and silently substitutes its
        current default, reporting the actually-served model only here. `None` when the provider
        doesn't report one (e.g. Gemini Live). The session stamps this on each
        [`ModelResponse.model_name`][pydantic_ai.messages.ModelResponse.model_name], mirroring how
        request-response models record the response's reported model rather than the requested one.
        """
        return None

    def set_message_history(self, message_history: Callable[[], Sequence[ModelMessage]]) -> None:
        """Tell the connection how to read the message history as it currently stands.

        A [`RealtimeSession`][pydantic_ai.realtime.RealtimeSession] calls this when it takes ownership of
        the connection, so a provider that loses server-side state on
        [reconnect][pydantic_ai.realtime.ReconnectPolicy] can replay the conversation into the new
        session instead of resuming with total amnesia. The session's history grows as the call goes on,
        hence a callable rather than a snapshot.

        A no-op by default: a provider with native session resumption (Gemini Live) has nothing to
        replay, and one that can't seed a session at all has nowhere to put it.
        """

    @property
    def input_transcription_enabled(self) -> bool:
        """Whether this connection will emit [`InputTranscript`][pydantic_ai.realtime.codec.InputTranscript] events for the user's audio.

        Providers that transcribe the user's input (the default) leave this `True`. When it is `False`,
        no transcript arrives, so [`RealtimeSession`][pydantic_ai.realtime.RealtimeSession] finalizes a
        user turn from retained input audio instead (see `audio_retention`). Defaults to `True` so a
        connection that doesn't override it never triggers the audio-only path (which would risk a
        duplicate turn if transcripts did arrive).
        """
        return True

    @property
    def interrupts_response_on_speech(self) -> bool:
        """Whether the configured turn detection makes the *server* cancel the active response when user speech starts.

        OpenAI-protocol server VAD with `interrupt_response` enabled (the default) cancels the
        in-progress response on speech onset by itself. A client cancel sent at that same moment can
        race the server's own cancellation and be applied to the *next* response instead, silencing
        the reply to the barge-in — so the session's automatic barge-in handling sends only the
        truncation when this is `True`. Defaults to `False`, which keeps the client-side cancel.
        """
        return False

    @property
    def _can_reconnect(self) -> bool:
        """Whether this connection will still re-dial if its link drops.

        Private while send retries across a reconnect are being redesigned. `False` without a reconnect
        policy, once its `max_reconnects` budget is spent, and once a reconnect has failed for good.
        While it is `True`, a [`RealtimeSession`][pydantic_ai.realtime.RealtimeSession] drops an audio
        chunk that hits the dropped link instead of raising, so a microphone task survives the reconnect.
        """
        return False

    @property
    def _answers_tool_calls_per_response(self) -> bool:
        """Whether one reply answers all the tool results of a model response, rather than one per result.

        For the session's reply accounting only. The built-in connections make it so (Gemini Live answers
        a tool-call frame once; the OpenAI-protocol connection asks for one response per calling
        response), and the session then counts one reply per tool-calling response. Defaults to `False`,
        which counts one per result, as a connection that asks for a response after each one needs.
        """
        return False

    def _take_merged_response_requests(self) -> int:
        """How many requests for a response sent since the last call were answered by another one's response.

        For the session's reply accounting only: a connection that holds a request made during an
        active response, and answers any further ones with the same response, reports them here so
        the session stops waiting for a response of their own.
        """
        return 0

    @property
    def reconnect_restores_in_flight_state(self) -> bool:
        """Whether a reconnect continues the response and tool calls that were in flight when the socket dropped.

        Otherwise it only brings back the finalized conversation. Gemini Live settles the cut turn in the
        connection before its
        [`RealtimeSessionReconnectEvent`][pydantic_ai.messages.RealtimeSessionReconnectEvent], so the
        [`RealtimeSession`][pydantic_ai.realtime.RealtimeSession] must not settle again and trusts
        `state_restored`. Local replay (OpenAI, Azure OpenAI, xAI) restores only finalized turns, so
        the session settles the interrupted turn itself and reports `state_restored=False`. Defaults to
        `True`; the OpenAI connection overrides it.
        """
        return True

    @property
    def _defers_audio_commit(self) -> bool:
        """Whether committed audio joins the conversation only when the connection sends the commit later.

        For the session's history placement only. A connection may hold a `CommitAudio` back, for instance
        until a response is asked for, when its provider answers a commit by itself, and input sent in the
        meantime then reaches the provider first. The session records the spoken turn where the provider
        has it, once the connection reports sending the commit to the listener passed to
        `_set_audio_commit_listener`. Internal until the session's lifecycle events, which track provider
        items per input, replace it. Defaults to `False`.
        """
        return False

    def _set_audio_commit_listener(self, listener: Callable[[], None]) -> None:
        """Register what to call as a held commit goes out, on a connection that `_defers_audio_commit`.

        The listener is called just before the commit is sent, and before anything the provider sends in
        answer. Internal, like `_defers_audio_commit`. A no-op by default.
        """


__all__ = (
    # Connection ABC and the event/input unions it exchanges with a session.
    'RealtimeConnection',
    'RealtimeCodecEvent',
    'RealtimeInput',
    # Codec events a connection yields.
    'AudioDelta',
    'OutputTranscript',
    'InputTranscript',
    'ToolCall',
    'ToolResult',
    'ToolCallCancelled',
    'ResponseDone',
    'ConversationCreated',
    'ConversationItemCreated',
    'InputRejected',
    'SessionUsage',
    # Turn-control verbs a connection accepts.
    'CommitAudio',
    'ClearAudio',
    'CreateResponse',
    'TextContext',
    'CancelResponse',
    'TruncateOutput',
    # Model-profile helpers for provider implementations.
    'merge_realtime_profile',
    'DEFAULT_AUDIO_SAMPLE_RATE',
    'DEFAULT_REALTIME_PROFILE',
)
