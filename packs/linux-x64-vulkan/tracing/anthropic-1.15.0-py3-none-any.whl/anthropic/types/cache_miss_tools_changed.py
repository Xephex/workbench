from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["CacheMissToolsChanged"]


class CacheMissToolsChanged(BaseModel):
    cache_missed_input_tokens: int
    """
    Approximate number of input tokens that would have been read from cache had the
    prefix matched the previous request.
    """

    type: Literal["tools_changed"]
